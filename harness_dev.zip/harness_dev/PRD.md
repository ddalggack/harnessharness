# PRD — CTF Run Harness

## 1. 제품 한 문장

허가된 로컬 CTFd URL을 넣고 버튼을 누르면, 하나의 Main Codex가 문제를 분류하고 최대 3개의 독립 Worker 프로그램에 JSON 작업을 배정하며 결과와 제출 상태를 한 화면에서 감독하는 CTF 실행 하네스다.

## 2. 해결하려는 문제

CTF 문제를 AI에 한 번씩 붙여 넣는 방식은 여러 문제의 상태, 실패 근거, 작업 이력과 제출 권한을 관리하기 어렵다. 또한 여러 LLM을 동시에 경쟁시키면 비용과 노트북 부하가 커지고 Main이 Worker를 감독하기도 어렵다.

이 제품은 다음을 분리한다.

- 판단: 지속되는 Main Codex 하나
- 실행: LLM이 없는 Worker 프로그램 최대 3개
- 전달: 버전이 있는 JSON 파일
- 제출: 별도 Submission Broker
- 관찰: 버튼식 Dashboard와 Event Log

## 3. 목표 사용자와 사용 장면

- 3~4명의 보안 교육 팀
- 로컬 CTFd에 pwn/rev/web 문제를 올려 하네스 구조를 시연하려는 발표자
- 실행 근거와 실패 원인을 JSON artifact로 남기려는 개발자

대표 흐름:

1. 사용자가 Demo 또는 로컬 CTFd를 고른다.
2. 환경 확인 버튼으로 문제 목록과 권한을 검증한다.
3. 자동 풀이 시작 버튼을 누른다.
4. Main이 Worker Profile과 작업을 결정한다.
5. Worker 최대 3개가 별도 프로세스로 JSON Job을 수행한다.
6. Broker가 후보를 검증/제출한다.
7. 사용자는 Worker 상태, 문제 상태, 이벤트, 실행 보고서를 확인한다.

## 4. 제품 원칙

- Main AI는 하나다.
- Worker는 프로그램이지 Agent/LLM이 아니다.
- 같은 문제에 여러 모델을 경쟁시키지 않는다.
- “성공”은 Demo의 명시적 가상 승인 또는 실제 CTFd의 `correct`로만 표시한다.
- 실제 도구가 없는 기능은 `needs_tooling`으로 표시하고 완성된 solve처럼 보이지 않는다.
- 수업 PC의 시스템 Node.js를 변경하지 않는다.

## 5. MVP 기능 요구사항

### FR-01 버튼식 Dashboard

- 브라우저가 필요 없는 Windows 네이티브 WinForms 프로그램을 제공한다.
- 동일 기능의 웹 Dashboard도 보조 실행 화면으로 제공한다.
- Demo/CTFd 모드, 분야, Worker 수를 선택할 수 있다.
- 환경 확인, 실행, 중지, 초기화, 보고서 저장 버튼이 있다.
- 총 문제, solved, 활성 Worker, 진행률을 표시한다.
- 문제 Queue, Worker Rack, Event Log를 한 화면에 표시한다.
- Worker의 `checkpoint`, `completed`, `failed` 전이를 실행 기록에 실시간 표시한다.
- 문제 목록의 `진행 보기`에서 해당 문제의 Worker 기록만 확인할 수 있다.
- 320px 이상 화면과 키보드 조작을 지원한다.

### FR-02 Demo

- 외부 서버 없이 pwn/rev/web 각 3개를 제공한다.
- Decision, Job, Result, Broker까지 실제 Core 경로를 사용한다.
- Worker는 별도 OS 프로세스로 실행된다.
- 9개 문제 완료 시 공개 상태에는 9 solved, 0 failed가 표시된다.

### FR-03 CTFd Adapter

- `/api/v1/challenges`를 통해 문제를 조회한다.
- `/api/v1/challenges/attempt`를 통해 Broker가 후보를 제출한다.
- localhost, `.local`, RFC1918 사설 IPv4만 허용한다.
- Token은 메모리에만 보관한다.
- 사용자가 허가 확인란을 체크하지 않으면 연결하지 않는다.

### FR-04 Main Coordinator

- Demo는 deterministic coordinator를 사용한다.
- 실제 모드는 선택적으로 Codex SDK를 사용한다.
- Main Codex service는 실행 중 계속 살아 있으며 같은 Thread를 재사용한다.
- Decision은 structured output JSON이고 action은 최대 3개다.
- Core Node 16에서 SDK를 사용할 수 없으면 Core를 중단하지 않고 기능만 비활성화한다.

### FR-05 Worker Scheduler

- 1~3개의 Worker slot을 제공하고 3을 넘지 못하게 한다.
- 각 Worker에 별도 `job.json`과 `result.json`을 배정한다.
- shell 문자열 없이 executable과 args 배열로 프로세스를 실행한다.
- 한 Worker 실패가 다른 Worker를 중단시키지 않는다.
- 사용자 중지 요청을 처리한다.

### FR-06 JSON 계약

- Decision, Job, Result에 `schemaVersion`, Run/Job/Challenge ID를 포함한다.
- Worker Profile은 `pwn`, `rev`, `web`만 허용한다.
- operation은 MVP allowlist 안의 값만 허용한다.
- Result ID는 원본 Job과 정확히 일치해야 한다.
- WorkerEvent는 Job/Run/Challenge/Worker ID, 순번, 단계와 진행률을 포함한다.
- Schema는 `contracts/`에 버전 관리한다.

### FR-07 Submission과 감사 추적

- 후보 중복은 `challengeId + flag hash`로 차단한다.
- 공개 API와 Event Log에 원문 flag를 표시하지 않는다.
- Run마다 Decision/Job/Result/Event/State를 `_runtime/runs/<run-id>/`에 저장한다.
- JSON 보고서 저장은 공개 state만 포함한다.

## 6. 비기능 요구사항

### 호환성

- Core는 Windows의 기존 Node.js 16.20 이상에서 무설치로 실행한다.
- 네이티브 UI는 Windows 기본 PowerShell 5.1과 .NET WinForms로 실행한다.
- Python/PyQt/Tkinter를 요구하거나 자동 설치하지 않는다.
- 시스템 Node, PATH, 전역 npm을 변경하지 않는다.
- SDK는 별도 Node 18+ 경로를 명시한 경우에만 실행한다.

### 안전

- 무허가 공개 대상에 연결하지 않는다.
- Token과 원문 flag는 로그/Git/API 응답에서 제외한다.
- Worker에는 CTFd Token을 전달하지 않는다.
- 임의 shell 명령을 허용하지 않는다.

### 관찰 가능성

- 모든 중요한 전이는 ID와 시간으로 기록한다.
- Demo, 실제, 부분 완료, 실패, 중지를 구분한다.
- 빌드 성공과 실제 서비스 통합 성공을 구분해 보고한다.

## 7. MVP 인수 조건

- [x] Node 16.20에서 Dashboard/API 기동
- [x] 브라우저 없는 Windows 네이티브 Push-button UI 기동
- [x] Desktop UI에서 Demo/API 상태 표시
- [x] Demo 문제 9개 조회
- [x] Worker 별도 프로세스와 JSON Job/Result 생성
- [x] 활성 Worker 최대 3개 검증
- [x] Decision 파일당 action 최대 3개
- [x] Demo 9 solved E2E
- [x] 공개 state/Event Log 원문 flag 비노출
- [x] Worker checkpoint/completed/failed 실행 기록
- [x] Desktop/Web 문제별 Worker 진행상황 보기
- [x] 사설망 CTFd host allowlist
- [x] CTFd 조회/제출 Adapter 구현
- [x] 선택형 지속 Main Codex service 구현
- [ ] 실제 로컬 CTFd API 통합 시험
- [ ] 실제 Codex 인증/Thread 통합 시험
- [ ] pwn/rev/web Docker tool image와 실제 solve vertical slice

## 8. 명시적 비목표

- 공개 CTF 사이트 범용 자동 공격
- 다중 Agent team이나 모델 경주
- Worker의 LLM 호출
- 모든 CTF 문제 자동 해결 보장
- 첫 MVP의 Kubernetes/Temporal/PostgreSQL/NATS

## 9. 성공 지표

- Demo E2E 성공률 100%
- 최대 활성 Worker 3 이하
- 공개 flag/token 유출 0건
- invalid host 실행 0건
- JSON Job 대비 Result ID 일치율 100%
- 발표 Demo 시작부터 완료까지 30초 이내
