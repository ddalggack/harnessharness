const http = require("http");
const https = require("https");

function isPrivateHost(hostname) {
  const host = String(hostname || "").toLowerCase();
  if (["localhost", "127.0.0.1", "::1", "host.docker.internal"].includes(host)) return true;
  if (host.endsWith(".local")) return true;
  const octets = host.split(".").map(Number);
  if (octets.length !== 4 || octets.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) return false;
  return octets[0] === 10 ||
    (octets[0] === 192 && octets[1] === 168) ||
    (octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31);
}

function normalizeBaseUrl(value) {
  let url;
  try {
    url = new URL(String(value || ""));
  } catch {
    throw new Error("CTFd URL 형식이 올바르지 않습니다.");
  }
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("CTFd URL은 http 또는 https만 허용합니다.");
  if (!isPrivateHost(url.hostname)) throw new Error("안전을 위해 localhost 또는 사설망 CTFd만 연결할 수 있습니다.");
  url.pathname = url.pathname.replace(/\/$/, "");
  return url;
}

function requestJson(baseUrl, pathname, token, options = {}) {
  const target = new URL(pathname, `${baseUrl.origin}${baseUrl.pathname}/`);
  const transport = target.protocol === "https:" ? https : http;
  const body = options.body ? Buffer.from(JSON.stringify(options.body)) : null;

  return new Promise((resolve, reject) => {
    const request = transport.request(target, {
      method: options.method || "GET",
      timeout: options.timeout || 7000,
      headers: {
        Accept: "application/json",
        ...(body ? { "Content-Type": "application/json", "Content-Length": body.length } : {}),
        ...(token ? { Authorization: `Token ${token}` } : {}),
      },
    }, (response) => {
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        const raw = Buffer.concat(chunks).toString("utf8");
        let parsed;
        try {
          parsed = raw ? JSON.parse(raw) : {};
        } catch {
          reject(new Error(`CTFd가 JSON이 아닌 응답을 반환했습니다. (HTTP ${response.statusCode})`));
          return;
        }
        if (response.statusCode < 200 || response.statusCode >= 300 || parsed.success === false) {
          reject(new Error(parsed.message || `CTFd 요청 실패 (HTTP ${response.statusCode})`));
          return;
        }
        resolve(parsed);
      });
    });
    request.on("timeout", () => request.destroy(new Error("CTFd 연결 시간이 초과되었습니다.")));
    request.on("error", reject);
    if (body) request.write(body);
    request.end();
  });
}

function inferCategory(challenge) {
  const text = [challenge.category, challenge.name, ...(challenge.tags || []).map((tag) => tag.value || tag)].join(" ").toLowerCase();
  if (/pwn|binary exploit|포너블/.test(text)) return "pwn";
  if (/rev|revers|리버싱/.test(text)) return "rev";
  if (/web|웹/.test(text)) return "web";
  return "web";
}

async function listChallenges(baseUrl, token) {
  const url = normalizeBaseUrl(baseUrl);
  const response = await requestJson(url, "/api/v1/challenges", token);
  return (response.data || []).map((challenge) => ({
    id: String(challenge.id),
    name: challenge.name || `challenge-${challenge.id}`,
    category: inferCategory(challenge),
    points: Number(challenge.value || 0),
    source: "ctfd",
  }));
}

async function submitFlag(baseUrl, token, challengeId, flag) {
  const url = normalizeBaseUrl(baseUrl);
  const response = await requestJson(url, "/api/v1/challenges/attempt", token, {
    method: "POST",
    body: { challenge_id: Number(challengeId), submission: flag },
  });
  return {
    accepted: response.data && response.data.status === "correct",
    status: response.data ? response.data.status : "unknown",
    message: response.data ? response.data.message : "",
  };
}

module.exports = { isPrivateHost, listChallenges, normalizeBaseUrl, submitFlag };
