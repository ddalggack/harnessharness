const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const { spawn } = require("child_process");
const ctfd = require("./ctfd.cjs");
const { CodexBridge } = require("./codex-bridge.cjs");

const CATEGORIES = ["pwn", "rev", "web"];
const DEMO_CHALLENGES = [
  ["pwn-01", "Warm-up Stack", "pwn", 100],
  ["pwn-02", "Tiny ROP", "pwn", 200],
  ["pwn-03", "Echo Chamber", "pwn", 300],
  ["rev-01", "Lost Password", "rev", 100],
  ["rev-02", "Switch Maze", "rev", 200],
  ["rev-03", "Packed Note", "rev", 300],
  ["web-01", "Cookie Jar", "web", 100],
  ["web-02", "Hidden Admin", "web", 200],
  ["web-03", "Memo API", "web", 300],
].map(([id, name, category, points]) => ({ id, name, category, points, source: "demo" }));

function isoNow() {
  return new Date().toISOString();
}

function uid(prefix) {
  const value = crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString("hex");
  return `${prefix}-${value}`;
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function createWorkers(limit) {
  return [1, 2, 3].map((number) => ({
    id: `worker-${number}`,
    name: `Worker ${String(number).padStart(2, "0")}`,
    enabled: number <= limit,
    status: number <= limit ? "idle" : "disabled",
    profile: null,
    challengeId: null,
    challengeName: null,
    phase: number <= limit ? "대기" : "비활성",
    progress: 0,
    completed: 0,
  }));
}

function initialState() {
  return {
    version: "0.1.0",
    connection: {
      connected: false,
      mode: "demo",
      label: "연결 전",
      baseUrl: "",
      tokenConfigured: false,
      checkedAt: null,
    },
    config: {
      workerLimit: 3,
      categories: [...CATEGORIES],
      autoSubmit: true,
      useCodex: false,
      authorized: false,
    },
    environment: {
      nodeVersion: process.versions.node,
      coreCompatible: Number(process.versions.node.split(".")[0]) >= 16,
      codexSdkAvailable: Number(process.versions.node.split(".")[0]) >= 18 || Boolean(process.env.HARNESS_CODEX_NODE),
      codexRuntime: process.env.HARNESS_CODEX_NODE ? "separate" : "current",
      workerIsolation: "process + JSON files",
    },
    run: {
      id: null,
      status: "idle",
      progress: 0,
      message: "환경을 연결하면 실행할 수 있습니다.",
      startedAt: null,
      completedAt: null,
      total: 0,
      solved: 0,
      failed: 0,
    },
    challenges: [],
    workers: createWorkers(3),
    events: [],
  };
}

class Harness {
  constructor(projectRoot) {
    this.projectRoot = projectRoot;
    this.runtimeRoot = path.join(projectRoot, "_runtime");
    this.state = initialState();
    this.secret = { token: "" };
    this.runToken = null;
    this.children = new Map();
    this.submissionHashes = new Set();
    this.codex = new CodexBridge(this.runtimeRoot);
    fs.mkdirSync(this.runtimeRoot, { recursive: true });
    this.addEvent("info", "system", "Harness API가 준비되었습니다.");
  }

  publicState() {
    return clone(this.state);
  }

  addEvent(level, type, message, extra = {}) {
    const event = {
      id: uid("event"),
      time: isoNow(),
      level,
      type,
      message,
      ...extra,
    };
    this.state.events.unshift(event);
    this.state.events = this.state.events.slice(0, 250);
    if (this.state.run.id) {
      const runDirectory = path.join(this.runtimeRoot, "runs", this.state.run.id);
      fs.mkdirSync(runDirectory, { recursive: true });
      fs.appendFileSync(path.join(runDirectory, "events.jsonl"), `${JSON.stringify(event)}\n`, "utf8");
    }
    return event;
  }

  persistState() {
    if (!this.state.run.id) return;
    const runDirectory = path.join(this.runtimeRoot, "runs", this.state.run.id);
    fs.mkdirSync(runDirectory, { recursive: true });
    fs.writeFileSync(path.join(runDirectory, "state.json"), JSON.stringify(this.publicState(), null, 2), "utf8");
  }

  async connect(input = {}) {
    if (this.state.run.status === "running") throw new Error("실행 중에는 연결 설정을 바꿀 수 없습니다.");
    const mode = input.mode === "ctfd" ? "ctfd" : "demo";
    const workerLimit = Math.max(1, Math.min(3, Number(input.workerLimit) || 3));
    const categories = Array.isArray(input.categories)
      ? input.categories.filter((value) => CATEGORIES.includes(value))
      : [...CATEGORIES];
    if (categories.length === 0) throw new Error("최소 한 개의 문제 분야를 선택하세요.");

    let challenges;
    let baseUrl = "";
    if (mode === "ctfd") {
      if (!input.authorized) throw new Error("본인 소유 또는 명시적으로 허가된 로컬 CTFd인지 확인해야 합니다.");
      baseUrl = ctfd.normalizeBaseUrl(input.baseUrl).toString().replace(/\/$/, "");
      challenges = await ctfd.listChallenges(baseUrl, String(input.apiToken || ""));
      this.secret.token = String(input.apiToken || "");
    } else {
      challenges = clone(DEMO_CHALLENGES);
      this.secret.token = "";
    }

    this.state.config = {
      workerLimit,
      categories,
      autoSubmit: mode === "demo" ? true : Boolean(input.autoSubmit),
      useCodex: mode === "ctfd" && Boolean(input.useCodex),
      authorized: mode === "demo" ? true : Boolean(input.authorized),
    };
    this.state.connection = {
      connected: true,
      mode,
      label: mode === "demo" ? "내장 Demo CTF" : new URL(baseUrl).host,
      baseUrl,
      tokenConfigured: Boolean(this.secret.token),
      checkedAt: isoNow(),
    };
    this.state.challenges = challenges
      .filter((challenge) => categories.includes(challenge.category))
      .map((challenge) => ({ ...challenge, status: "queued", workerId: null, phase: "대기", progress: 0, attempts: 0 }));
    this.state.workers = createWorkers(workerLimit);
    this.state.run = {
      id: null,
      status: "ready",
      progress: 0,
      message: `${this.state.challenges.length}개 문제를 불러왔습니다.`,
      startedAt: null,
      completedAt: null,
      total: this.state.challenges.length,
      solved: 0,
      failed: 0,
    };
    this.addEvent("success", "connection", `${this.state.connection.label} 연결 확인 · 문제 ${this.state.challenges.length}개`);
    return this.publicState();
  }

  startRun() {
    if (!this.state.connection.connected) throw new Error("먼저 환경 확인 버튼을 눌러주세요.");
    if (this.state.run.status === "running") throw new Error("이미 실행 중입니다.");
    if (this.state.challenges.length === 0) throw new Error("실행할 문제가 없습니다.");

    const runId = uid("run");
    this.runToken = uid("token");
    this.submissionHashes.clear();
    this.state.challenges = this.state.challenges.map((challenge) => ({
      ...challenge,
      status: "queued",
      workerId: null,
      phase: "배정 대기",
      progress: 0,
      attempts: 0,
    }));
    this.state.workers = createWorkers(this.state.config.workerLimit);
    this.state.run = {
      id: runId,
      status: "running",
      progress: 0,
      message: "Main Coordinator가 작업을 준비 중입니다.",
      startedAt: isoNow(),
      completedAt: null,
      total: this.state.challenges.length,
      solved: 0,
      failed: 0,
    };
    this.addEvent("info", "run", `Run 시작 · 동시 Worker ${this.state.config.workerLimit}개`, { runId });
    this.persistState();
    const token = this.runToken;
    this.orchestrate(token).catch((error) => this.failRun(token, error));
    return this.publicState();
  }

  async orchestrate(token) {
    let selected = this.state.challenges;
    if (this.state.connection.mode === "ctfd" && this.state.config.useCodex) {
      this.state.run.message = "Main Codex가 Worker Job을 계획하고 있습니다.";
      this.addEvent("info", "coordinator", "Main Codex thread에 문제 요약을 전달했습니다.");
      const planned = await this.codex.plan(this.state.challenges.map(({ id, name, category, points }) => ({ id, name, category, points })));
      const ids = new Set(planned.decision.actions.map((action) => String(action.challengeId)));
      selected = this.state.challenges.filter((challenge) => ids.has(String(challenge.id)));
      const decision = {
        schemaVersion: "1.0",
        decisionId: uid("decision"),
        runId: this.state.run.id,
        threadId: planned.threadId,
        ...planned.decision,
      };
      this.writeDecision(decision, 1);
      this.addEvent("success", "coordinator", `Codex Decision 수신 · action ${selected.length}개`);
    } else {
      const batches = [];
      for (let offset = 0; offset < selected.length; offset += 3) batches.push(selected.slice(offset, offset + 3));
      batches.forEach((batch, index) => this.writeDecision({
        schemaVersion: "1.0",
        decisionId: uid("decision"),
        runId: this.state.run.id,
        summary: this.state.connection.mode === "demo" ? "Deterministic demo coordinator" : "Category based fallback coordinator",
        actions: batch.map((challenge) => ({
          challengeId: String(challenge.id),
          workerProfile: challenge.category,
          operation: this.state.connection.mode === "demo" ? "demo_solve" : "inspect",
          objective: `${challenge.name} 분석`,
          reason: `${challenge.category} category mapping`,
        })),
      }, index + 1));
      this.addEvent("success", "coordinator", `Decision JSON ${batches.length}개 생성 · Worker 경쟁 없음`);
    }

    if (token !== this.runToken) return;
    const queue = [...selected];
    this.state.run.total = selected.length;
    this.state.run.message = "Worker 프로그램이 JSON Job을 처리 중입니다.";
    const consumers = this.state.workers
      .filter((worker) => worker.enabled)
      .map((worker) => this.consumeQueue(queue, worker, token));
    await Promise.all(consumers);
    if (token !== this.runToken) return;

    const terminal = this.state.challenges.filter((challenge) => ["solved", "needs_tooling", "failed"].includes(challenge.status));
    this.state.run.solved = terminal.filter((challenge) => challenge.status === "solved").length;
    this.state.run.failed = terminal.filter((challenge) => challenge.status !== "solved").length;
    this.state.run.progress = 100;
    this.state.run.status = this.state.run.failed === 0 ? "completed" : "partial";
    this.state.run.completedAt = isoNow();
    this.state.run.message = this.state.run.status === "completed"
      ? "모든 제출이 검증되었습니다."
      : "오케스트레이션은 완료됐지만 실제 도구 연결이 필요한 항목이 있습니다.";
    this.state.workers.forEach((worker) => {
      if (worker.enabled) Object.assign(worker, { status: "idle", phase: "완료", progress: 100, challengeId: null, challengeName: null });
    });
    this.addEvent(this.state.run.status === "completed" ? "success" : "warning", "run", this.state.run.message);
    this.persistState();
  }

  writeDecision(decision, index) {
    if (!Array.isArray(decision.actions) || decision.actions.length > 3) throw new Error("Decision action은 최대 3개입니다.");
    const directory = path.join(this.runtimeRoot, "runs", this.state.run.id, "decisions");
    fs.mkdirSync(directory, { recursive: true });
    fs.writeFileSync(path.join(directory, `decision-${String(index).padStart(3, "0")}.json`), JSON.stringify(decision, null, 2), "utf8");
  }

  async consumeQueue(queue, worker, token) {
    while (queue.length > 0 && token === this.runToken) {
      const challenge = queue.shift();
      await this.executeChallenge(challenge, worker, token);
    }
  }

  async executeChallenge(challenge, worker, token) {
    const jobId = uid("job");
    const runDirectory = path.join(this.runtimeRoot, "runs", this.state.run.id);
    const jobPath = path.join(runDirectory, "jobs", `${jobId}.json`);
    const resultPath = path.join(runDirectory, "results", `${jobId}.json`);
    fs.mkdirSync(path.dirname(jobPath), { recursive: true });

    const operation = this.state.connection.mode === "demo" ? "demo_solve" : "inspect";
    const job = {
      schemaVersion: "1.0",
      jobId,
      runId: this.state.run.id,
      workerId: worker.id,
      workerProfile: challenge.category,
      operation,
      challenge: { id: String(challenge.id), name: challenge.name, category: challenge.category, points: challenge.points },
      limits: { timeoutMs: 30000, maxOutputBytes: 65536 },
      createdAt: isoNow(),
    };
    fs.writeFileSync(jobPath, JSON.stringify(job, null, 2), "utf8");

    challenge.status = "running";
    challenge.workerId = worker.id;
    challenge.phase = "Job 전달";
    challenge.progress = 4;
    challenge.attempts += 1;
    Object.assign(worker, {
      status: "running",
      profile: challenge.category,
      challengeId: String(challenge.id),
      challengeName: challenge.name,
      phase: "Job 읽기",
      progress: 4,
    });
    this.addEvent("info", "dispatch", `${worker.name} ← ${challenge.name}`, { workerId: worker.id, challengeId: String(challenge.id) });
    this.persistState();

    const child = spawn(process.execPath, [path.join(__dirname, "worker.cjs"), jobPath, resultPath], {
      cwd: this.projectRoot,
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true,
    });
    this.children.set(jobId, child);
    let stderr = "";
    child.stderr.on("data", (chunk) => { stderr = `${stderr}${chunk}`.slice(-2048); });
    const lines = readline.createInterface({ input: child.stdout });
    lines.on("line", (line) => {
      if (token !== this.runToken) return;
      let update;
      try { update = JSON.parse(line); } catch { return; }
      if (update.type !== "progress") return;
      challenge.phase = update.phase;
      challenge.progress = update.progress;
      worker.phase = update.phase;
      worker.progress = update.progress;
      this.state.run.progress = this.calculateProgress();
    });

    const exitCode = await new Promise((resolve) => child.on("exit", (code) => resolve(code)));
    this.children.delete(jobId);
    if (token !== this.runToken) return;
    if (exitCode !== 0 || !fs.existsSync(resultPath)) {
      challenge.status = "failed";
      challenge.phase = "Worker 오류";
      challenge.progress = 100;
      this.addEvent("error", "worker", `${worker.name} 실패 · ${stderr.trim() || `exit ${exitCode}`}`, { workerId: worker.id, challengeId: String(challenge.id) });
    } else {
      const result = JSON.parse(fs.readFileSync(resultPath, "utf8"));
      this.validateResult(job, result);
      if (result.flagCandidates.length > 0) {
        const submission = await this.submitCandidate(challenge, result.flagCandidates[0]);
        challenge.status = submission.accepted ? "solved" : "failed";
        challenge.phase = submission.accepted ? "정답 승인" : "제출 거절";
        this.addEvent(submission.accepted ? "success" : "error", "submission", `${challenge.name} · ${submission.status}`, {
          workerId: worker.id,
          challengeId: String(challenge.id),
        });
      } else {
        challenge.status = result.status === "needs_tooling" ? "needs_tooling" : "failed";
        challenge.phase = result.status === "needs_tooling" ? "도구 연결 필요" : "후보 없음";
        this.addEvent("warning", "worker", `${challenge.name} · 실제 ${challenge.category} 도구 이미지 연결 필요`, {
          workerId: worker.id,
          challengeId: String(challenge.id),
        });
      }
      challenge.progress = 100;
    }

    worker.completed += 1;
    Object.assign(worker, { status: "idle", profile: null, challengeId: null, challengeName: null, phase: "다음 Job 대기", progress: 0 });
    this.state.run.progress = this.calculateProgress();
    this.state.run.solved = this.state.challenges.filter((item) => item.status === "solved").length;
    this.state.run.failed = this.state.challenges.filter((item) => ["failed", "needs_tooling"].includes(item.status)).length;
    this.persistState();
  }

  validateResult(job, result) {
    if (!result || result.schemaVersion !== "1.0") throw new Error("Worker Result Schema가 올바르지 않습니다.");
    if (result.jobId !== job.jobId || result.runId !== job.runId || String(result.challengeId) !== String(job.challenge.id)) {
      throw new Error("Worker Result 식별자가 원본 Job과 일치하지 않습니다.");
    }
    if (!Array.isArray(result.flagCandidates) || !Array.isArray(result.observations)) throw new Error("Worker Result 배열 필드가 누락되었습니다.");
  }

  async submitCandidate(challenge, flag) {
    const flagHash = crypto.createHash("sha256").update(flag).digest("hex");
    const dedupKey = `${challenge.id}:${flagHash}`;
    if (this.submissionHashes.has(dedupKey)) return { accepted: false, status: "duplicate" };
    this.submissionHashes.add(dedupKey);
    if (this.state.connection.mode === "demo") return { accepted: true, status: "correct (demo)" };
    if (!this.state.config.autoSubmit) return { accepted: false, status: "candidate held (auto-submit off)" };
    return ctfd.submitFlag(this.state.connection.baseUrl, this.secret.token, challenge.id, flag);
  }

  calculateProgress() {
    if (this.state.run.total === 0) return 0;
    const sum = this.state.challenges.reduce((total, challenge) => total + (challenge.progress || 0), 0);
    return Math.min(99, Math.round(sum / this.state.run.total));
  }

  failRun(token, error) {
    if (token !== this.runToken) return;
    this.state.run.status = "failed";
    this.state.run.message = error.message;
    this.state.run.completedAt = isoNow();
    this.addEvent("error", "run", error.message);
    this.persistState();
  }

  stopRun() {
    if (this.state.run.status !== "running") return this.publicState();
    this.runToken = null;
    for (const child of this.children.values()) child.kill();
    this.children.clear();
    this.state.run.status = "stopped";
    this.state.run.message = "사용자가 실행을 중지했습니다.";
    this.state.run.completedAt = isoNow();
    this.state.workers.forEach((worker) => {
      if (worker.enabled) Object.assign(worker, { status: "idle", phase: "중지됨", progress: 0, challengeId: null, challengeName: null });
    });
    this.addEvent("warning", "run", "Run을 안전하게 중지했습니다.");
    this.persistState();
    return this.publicState();
  }

  reset() {
    this.stopRun();
    this.secret.token = "";
    this.state = initialState();
    this.addEvent("info", "system", "초기 상태로 되돌렸습니다.");
    return this.publicState();
  }

  shutdown() {
    this.stopRun();
    this.codex.stop();
  }
}

module.exports = { Harness, initialState, DEMO_CHALLENGES };
