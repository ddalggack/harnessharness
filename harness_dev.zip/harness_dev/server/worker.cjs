const fs = require("fs");
const path = require("path");

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

let eventSequence = 0;
let activeJob = null;

function emit(job, kind, phase, progress, message) {
  eventSequence += 1;
  process.stdout.write(`${JSON.stringify({
    schemaVersion: "1.0",
    type: "worker_event",
    kind,
    jobId: job.jobId,
    runId: job.runId,
    challengeId: String(job.challenge.id),
    workerId: job.workerId,
    sequence: eventSequence,
    phase,
    progress,
    message,
    occurredAt: new Date().toISOString(),
  })}\n`);
}

function validateJob(job) {
  const profiles = ["pwn", "rev", "web"];
  if (!job || job.schemaVersion !== "1.0") throw new Error("지원하지 않는 Job Schema입니다.");
  if (!job.jobId || !job.runId || !job.challenge || !job.challenge.id) throw new Error("Job 식별자가 누락되었습니다.");
  if (!profiles.includes(job.workerProfile)) throw new Error("허용되지 않은 Worker Profile입니다.");
  if (job.operation !== "demo_solve" && job.operation !== "inspect") throw new Error("허용되지 않은 operation입니다.");
}

async function main() {
  const [jobPath, resultPath] = process.argv.slice(2);
  if (!jobPath || !resultPath) throw new Error("jobPath와 resultPath가 필요합니다.");
  const job = JSON.parse(fs.readFileSync(path.resolve(jobPath), "utf8"));
  validateJob(job);
  activeJob = job;

  const startedAt = new Date().toISOString();
  emit(job, "checkpoint", "분석", 18, `${job.workerProfile.toUpperCase()} 프로필로 입력을 분류했습니다.`);
  await sleep(260);
  emit(job, "checkpoint", "도구 실행", 46, "허용된 도구 계획을 순서대로 실행 중입니다.");
  await sleep(340);
  emit(job, "checkpoint", "근거 정리", 72, "관찰 결과와 artifact 참조를 구성했습니다.");
  await sleep(280);

  const demo = job.operation === "demo_solve";
  if (demo) emit(job, "checkpoint", "후보 검증", 90, "플래그 후보 형식과 중복 여부를 검사했습니다.");
  else emit(job, "checkpoint", "실행 대기", 90, "실제 도구 컨테이너가 연결되지 않아 계획까지만 완료했습니다.");
  await sleep(180);

  const result = {
    schemaVersion: "1.0",
    jobId: job.jobId,
    runId: job.runId,
    challengeId: String(job.challenge.id),
    workerId: job.workerId,
    status: demo ? "succeeded" : "needs_tooling",
    observations: demo
      ? [`${job.challenge.name} 분석 완료`, `${job.workerProfile} 데모 도구 체인 정상 종료`]
      : ["JSON Job 전달과 Worker 격리는 정상", "실제 pwn/rev/web 도구 이미지는 아직 연결되지 않음"],
    flagCandidates: demo ? [`DEMO{${String(job.challenge.id).replace(/[^a-zA-Z0-9_-]/g, "_")}}`] : [],
    artifactRefs: [{ key: `runs/${job.runId}/results/${job.jobId}.json`, kind: "worker-result" }],
    startedAt,
    completedAt: new Date().toISOString(),
  };
  fs.mkdirSync(path.dirname(path.resolve(resultPath)), { recursive: true });
  fs.writeFileSync(path.resolve(resultPath), JSON.stringify(result, null, 2), "utf8");
  emit(job, "completed", "완료", 100, demo ? "Worker Result JSON을 반환했습니다." : "계획 결과를 반환했습니다.");
}

main().catch((error) => {
  if (activeJob) emit(activeJob, "failed", "실패", 100, error.message);
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
});
