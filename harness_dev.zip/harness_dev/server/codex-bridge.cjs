const { spawn } = require("child_process");
const path = require("path");
const readline = require("readline");

function nodeMajor(executable) {
  if (executable !== process.execPath) return null;
  return Number(process.versions.node.split(".")[0]);
}

class CodexBridge {
  constructor(runtimeRoot) {
    this.runtimeRoot = runtimeRoot;
    this.child = null;
    this.pending = new Map();
    this.sequence = 0;
  }

  available() {
    const executable = process.env.HARNESS_CODEX_NODE || process.execPath;
    const major = nodeMajor(executable);
    return Boolean(process.env.HARNESS_CODEX_NODE) || (major !== null && major >= 18);
  }

  start() {
    if (this.child) return;
    if (!this.available()) {
      throw new Error("Codex SDK에는 Node 18+ 런타임이 필요합니다. 시스템 Node는 변경하지 말고 HARNESS_CODEX_NODE에 별도 런타임 경로를 지정하세요.");
    }
    const executable = process.env.HARNESS_CODEX_NODE || process.execPath;
    this.child = spawn(executable, [path.join(this.runtimeRoot, "..", "codex-sdk", "service.mjs")], {
      cwd: this.runtimeRoot,
      stdio: ["pipe", "pipe", "pipe"],
      windowsHide: true,
      env: process.env,
    });
    const lines = readline.createInterface({ input: this.child.stdout });
    lines.on("line", (line) => {
      let message;
      try { message = JSON.parse(line); } catch { return; }
      const request = this.pending.get(message.id);
      if (!request) return;
      this.pending.delete(message.id);
      if (message.ok) request.resolve(message);
      else request.reject(new Error(message.error || "Codex planner 오류"));
    });
    this.child.stderr.on("data", () => {});
    this.child.on("exit", () => {
      for (const request of this.pending.values()) request.reject(new Error("Codex coordinator가 종료되었습니다."));
      this.pending.clear();
      this.child = null;
    });
  }

  plan(challenges) {
    this.start();
    const id = `plan-${Date.now()}-${++this.sequence}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error("Codex planning 제한 시간(90초)을 초과했습니다."));
      }, 90000);
      this.pending.set(id, {
        resolve: (value) => { clearTimeout(timer); resolve(value); },
        reject: (error) => { clearTimeout(timer); reject(error); },
      });
      this.child.stdin.write(`${JSON.stringify({ id, type: "plan", challenges })}\n`);
    });
  }

  stop() {
    if (this.child) this.child.kill();
  }
}

module.exports = { CodexBridge };
