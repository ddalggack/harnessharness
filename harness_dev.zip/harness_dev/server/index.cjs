const fs = require("fs");
const http = require("http");
const path = require("path");
const { Harness } = require("./harness.cjs");

const projectRoot = path.resolve(__dirname, "..");
const consoleRoot = path.join(projectRoot, "console");
const port = Number(process.env.HARNESS_PORT || 8788);
const host = "127.0.0.1";
const harness = new Harness(projectRoot);

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

function sendJson(response, status, value) {
  const body = JSON.stringify(value);
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
  });
  response.end(body);
}

function readJson(request) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    request.on("data", (chunk) => {
      size += chunk.length;
      if (size > 1024 * 1024) {
        reject(new Error("요청 본문이 너무 큽니다."));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on("end", () => {
      if (chunks.length === 0) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8"))); }
      catch { reject(new Error("JSON 요청 형식이 올바르지 않습니다.")); }
    });
    request.on("error", reject);
  });
}

function serveStatic(requestPath, response) {
  const relative = requestPath === "/" ? "index.html" : decodeURIComponent(requestPath.replace(/^\//, ""));
  const target = path.resolve(consoleRoot, relative);
  if (!target.startsWith(`${consoleRoot}${path.sep}`) && target !== path.join(consoleRoot, "index.html")) {
    sendJson(response, 403, { error: "허용되지 않은 경로입니다." });
    return;
  }
  fs.readFile(target, (error, data) => {
    if (error) {
      sendJson(response, 404, { error: "파일을 찾을 수 없습니다." });
      return;
    }
    response.writeHead(200, {
      "Content-Type": mimeTypes[path.extname(target)] || "application/octet-stream",
      "Content-Length": data.length,
      "Cache-Control": "no-cache",
    });
    response.end(data);
  });
}

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url, `http://${request.headers.host || `${host}:${port}`}`);
  try {
    if (request.method === "GET" && url.pathname === "/api/health") {
      sendJson(response, 200, { ok: true, nodeVersion: process.versions.node, pid: process.pid });
      return;
    }
    if (request.method === "GET" && url.pathname === "/api/state") {
      sendJson(response, 200, harness.publicState());
      return;
    }
    if (request.method === "POST" && url.pathname === "/api/connect") {
      sendJson(response, 200, await harness.connect(await readJson(request)));
      return;
    }
    if (request.method === "POST" && url.pathname === "/api/run") {
      sendJson(response, 202, harness.startRun());
      return;
    }
    if (request.method === "POST" && url.pathname === "/api/stop") {
      sendJson(response, 200, harness.stopRun());
      return;
    }
    if (request.method === "POST" && url.pathname === "/api/reset") {
      sendJson(response, 200, harness.reset());
      return;
    }
    if (request.method === "GET") {
      serveStatic(url.pathname, response);
      return;
    }
    sendJson(response, 404, { error: "API 경로를 찾을 수 없습니다." });
  } catch (error) {
    sendJson(response, 400, { error: error.message || "요청 처리 중 오류가 발생했습니다." });
  }
});

server.listen(port, host, () => {
  process.stdout.write(`\nCTF Run Harness is ready\n`);
  process.stdout.write(`Open: http://${host}:${port}\n`);
  process.stdout.write(`Node: ${process.versions.node} (system installation was not modified)\n\n`);
});

function shutdown() {
  harness.shutdown();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 2000).unref();
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
