# AGENTS.md — CTF Run Harness 개발 규칙

## 1. 절대 조건

1. 추론 주체는 지속되는 **Main Codex 하나**뿐이다.
2. Worker는 Codex subagent나 별도 LLM이 아니라 JSON Job을 실행하는 독립 프로그램이다.
3. 여러 모델이 같은 문제를 경쟁하는 Swarm/Racing을 만들지 않는다.
4. 활성 Worker는 어떤 설정에서도 최대 3개다.
5. Main/Worker 사이에는 버전이 명시된 JSON 파일만 전달한다.
6. Worker는 플래그를 직접 제출하지 않는다. Submission Broker만 제출한다.
7. CTFd의 `correct` 응답만 최종 solve 근거다.
8. 시스템 Node.js, PATH, 전역 패키지를 자동 설치·업데이트하지 않는다.
9. Core Dashboard/API/Demo는 Node.js 16.20 이상과 표준 라이브러리만으로 동작해야 한다.
10. Main Codex SDK는 별도 Node 18+ 런타임이 명시된 경우에만 선택적으로 실행한다.

## 2. 허용 범위와 안전

- Demo 또는 본인 소유/명시적으로 허가된 로컬 CTF 환경에서만 실행한다.
- CTFd Adapter는 localhost, `.local`, RFC1918 사설 IPv4만 허용한다.
- 공인 인터넷 호스트, 임의 shell 문자열, `shell: true`, Worker의 직접 CTFd 호출은 금지한다.
- Token, 원문 flag, 비공개 문제 원본, exploit 결과는 Git에 넣지 않는다.
- 공개 State API와 Event Log에는 원문 flag를 넣지 않는다.
- `_runtime/`은 실행 증거 저장소이며 Git에서 제외한다.

## 3. 작업 시작 절차

코드를 수정하기 전에 다음을 확인한다.

1. `PRD.md`, `AGENTS.md`, `plan.md`를 읽는다.
2. 현재 milestone과 완료 조건을 확인한다.
3. `git status --short`로 사용자 변경을 확인하고 보존한다.
4. 생산자와 소비자가 함께 쓰는 JSON 필드를 먼저 확인한다.
5. 시스템 런타임을 변경하지 않고 해결 가능한지 확인한다.
6. 정상 경로 하나와 실패/차단 경로 하나를 먼저 정한다.

## 4. 고정 파이프라인

```text
Connect -> Collect -> Decide -> Dispatch -> Execute -> Validate -> Submit -> Record
```

- Connect: 허가 확인, host allowlist, Token 메모리 보관
- Collect: CTFd 문제 조회 또는 내장 Demo fixture 로드
- Decide: Main Codex 또는 deterministic fallback이 action 최대 3개 생성
- Dispatch: Scheduler가 Job JSON을 쓰고 Worker 프로세스에 경로 전달
- Execute: Worker가 허용된 operation만 실행하고 Result JSON 생성
- Validate: Schema/ID 일치, 후보 형식, 중복 검사
- Submit: Broker만 CTFd Adapter 호출
- Record: Decision/Job/Result/Event/State를 Run 디렉터리에 보존

## 5. 컴포넌트 책임

### Dashboard

- 웹 Dashboard와 Windows WinForms Desktop은 같은 공개 API를 소비한다.
- 두 UI 모두 API의 공개 상태만 표시한다.
- Token 입력값은 연결 후 즉시 비운다.
- 실행, 중지, 초기화, 보고서 저장 버튼을 제공한다.
- Demo와 실제 CTFd 상태를 혼동시키지 않는다.
- Desktop은 Windows 기본 PowerShell/.NET만 사용하며 Python이나 GUI 패키지를 자동 설치하지 않는다.
- Desktop이 백엔드를 시작했다면 자신이 시작한 Node 프로세스만 종료한다.

### Main Coordinator

- 하나의 지속 프로세스와 하나의 재사용 가능한 Codex Thread를 사용한다.
- 문제 요약만 받아 Worker profile과 objective를 정한다.
- 한 Decision의 action은 최대 3개다.
- Worker 도구를 직접 실행하거나 플래그를 제출하지 않는다.

### Scheduler

- `workerLimit`을 1~3으로 clamp한다.
- `spawn(executable, args[])`만 사용하고 shell 문자열을 실행하지 않는다.
- Worker별 Job/Result 경로를 분리한다.
- 중지 시 자신의 자식 프로세스만 종료한다.

### Worker

- `pwn`, `rev`, `web` profile과 allowlist operation만 허용한다.
- Job 식별자를 Result에 그대로 돌려준다.
- 다른 Worker workspace에 접근하지 않는다.
- CTFd URL과 Token을 전달받지 않는다.

### CTFd Adapter / Submission Broker

- URL allowlist를 요청 직전에 다시 검사한다.
- `challengeId + SHA-256(flag)`로 중복 제출을 차단한다.
- 원문 flag를 이벤트 메시지나 API 응답에 넣지 않는다.
- `correct`, `incorrect`, `duplicate`, `held`를 구분한다.

## 6. 계약 변경 규칙

Decision, Job, Result를 바꾸면 다음을 한 변경에 함께 반영한다.

1. `contracts/*.schema.json`
2. 생산 코드
3. 소비 코드
4. 정상 fixture 또는 E2E 테스트
5. 잘못된 필드/ID를 거부하는 테스트
6. `PRD.md` 또는 `plan.md`의 해당 체크 항목

원시 `command` 문자열은 Schema에 추가하지 않는다. 실행은 `operation`과 검증된 인자 구조로 표현한다.

## 7. 오류 처리

| 상황 | 처리 |
|---|---|
| CTFd 접속 실패 | Run을 시작하지 않고 연결 오류 표시 |
| 공인 호스트 | 요청 전에 차단 |
| Codex Node 18+ 없음 | Core는 유지하고 SDK 스위치 비활성화 |
| Codex Decision 오류 | Worker에 전달하지 않고 Run 실패 근거 기록 |
| Worker 비정상 종료 | 해당 challenge만 실패, 다른 Worker 계속 실행 |
| Result ID 불일치 | Result 거부 및 보안 이벤트 기록 |
| 원문 flag 후보 | Result artifact 내부에만 보관, 공개 이벤트에는 결과만 표시 |
| 사용자 중지 | 활성 자식 Worker 종료, state와 event 보존 |

## 8. 완료 전 필수 검사

- `node --check`로 Core JS 문법 확인
- `npm test`로 Node 16 E2E 통과
- `npm run test:desktop`으로 WinForms→API 연동 통과
- PowerShell Parser로 `desktop/HarnessDesktop.ps1` 문법 오류 0건 확인
- Worker 최대 활성 수가 3 이하인지 측정
- 공개 state와 `events.jsonl`에 원문 flag가 없는지 확인
- Decision은 파일당 action 3개 이하인지 확인
- Demo 9개가 Decision→Job→Result→Broker를 모두 통과하는지 확인
- 실제 CTFd/Codex를 실행하지 않았다면 mock/미검증 범위를 명확히 보고

## 9. MVP 밖의 범위

- 무허가 공개 대상 자동 공격
- 다중 LLM/다중 Main Agent 경쟁
- Worker 내부 LLM 호출
- 임의 명령 실행기
- Kubernetes, Temporal, PostgreSQL, NATS의 조기 도입
- 실제 pwn/rev/web 도구 이미지가 없는 상태에서 “자동 solve 완성”이라고 주장하는 것
