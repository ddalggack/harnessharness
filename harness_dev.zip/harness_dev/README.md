# HarneHarness

버튼 한 번으로 로컬 CTF 문제를 가져오고, 하나의 Main Coordinator가 최대 3개의 **독립 Worker 프로그램**에 JSON 작업을 배정하는 데모/MVP입니다. 네이티브 Windows 프로그램과 웹 Dashboard를 모두 제공합니다.

핵심 앱은 수업 PC의 기존 Node.js `16.20.2`에서 외부 패키지 설치 없이 실행됩니다. 시스템 Node.js, PATH, 전역 패키지를 설치·업데이트하지 않습니다.

## 현재 구현 범위

| 기능 | 상태 | 비고 |
|---|---|---|
| Windows 네이티브 프로그램 | 구현 | PowerShell + .NET WinForms, 브라우저 불필요 |
| 버튼식 로컬 Dashboard | 구현 | 환경 확인, 실행, 중지, 초기화, JSON 보고서 저장 |
| 안전 Demo | 구현 | pwn/rev/web 각 3개, 총 9개 |
| JSON Decision/Job/Result | 구현 | `_runtime/runs/<run-id>/`에 실행별 보존 |
| 별도 Worker 프로세스 | 구현 | Worker가 `job.json`을 읽고 `result.json` 작성 |
| Worker 진행 추적 | 구현 | checkpoint/completed/failed 실행 기록과 문제별 상세 보기 |
| 동시 실행 상한 | 구현 | 1~3 선택, 코드에서 최대 3 강제 |
| Submission Broker | 구현 | 중복 후보 차단, 공개 상태/이벤트에서 원문 flag 마스킹 |
| 로컬 CTFd 문제 조회 | 구현 | localhost·사설망 주소만 허용 |
| CTFd 제출 | 구현 | 자동 제출을 켠 경우 Broker만 호출 |
| Main Codex SDK | 선택 구현 | 별도 Node 18+ 런타임이 이미 있을 때만 사용 |
| 실제 pwn/rev/web 도구 컨테이너 | 다음 단계 | 지금은 `needs_tooling`으로 명확히 표시 |
| Kubernetes/Temporal/PostgreSQL | Backlog | MVP 뒤 확장 |

## 권장 실행: 네이티브 푸시버튼 프로그램

1. [START_DESKTOP.cmd](./START_DESKTOP.cmd)를 더블클릭합니다.
2. 브라우저가 아닌 `HarneHarness · Desktop Console` 창이 열립니다.
3. `안전 Demo`를 선택하고 **환경 확인**을 누릅니다.
4. 큰 주황색 **자동 풀이 시작** 버튼을 누릅니다.

네이티브 프로그램은 기존 Node API가 꺼져 있으면 숨김으로 자동 실행하고, 자신이 시작한 서버만 창 종료 시 정리합니다. Windows 기본 PowerShell/.NET을 사용하므로 Python, PyQt, 추가 GUI 패키지가 필요 없습니다.

## 웹 Dashboard 실행

1. [START_HARNESS.cmd](./START_HARNESS.cmd)를 더블클릭합니다.
2. 브라우저에서 `http://127.0.0.1:8788`이 열립니다.
3. `안전 Demo` 상태에서 **환경 확인**을 누릅니다.
4. **자동 풀이 시작**을 누릅니다.

또는 터미널에서 다음만 실행합니다. `npm install`은 필요 없습니다.

```powershell
node server\index.cjs
```

## Demo에서 확인할 수 있는 것

```text
Dashboard
   -> Main Coordinator (결정 JSON, 한 번에 최대 action 3개)
      -> Scheduler (동시 Worker 최대 3)
         -> Worker 프로세스 #1 -- job.json -> result.json
         -> Worker 프로세스 #2 -- job.json -> result.json
         -> Worker 프로세스 #3 -- job.json -> result.json
      -> Submission Broker (형식/중복/마스킹)
   -> 공개 상태 API와 Event Log
```

Demo는 외부 CTF나 공격 대상에 연결하지 않습니다. 가짜 플래그 후보가 Broker를 통과하는 전체 파이프라인만 보여줍니다.

## 로컬 CTFd 연결

1. 화면에서 `로컬 CTFd`를 선택합니다.
2. `http://127.0.0.1:8000` 같은 로컬/사설망 URL과 CTFd API Token을 입력합니다.
3. 허가 확인란을 체크합니다.
4. 먼저 자동 제출을 끈 상태로 문제 조회를 시험하는 것을 권장합니다.

공인 인터넷 호스트는 서버의 host allowlist에서 거절됩니다. Token은 메모리에만 두며 `/api/state`, Event Log, Git 파일에 기록하지 않습니다.

## 선택 기능: Main Codex SDK

Core 앱은 Node 16에서 동작하지만 공식 Codex SDK는 Node 18+가 필요합니다. **수업용 시스템 Node를 업데이트하지 않습니다.** 이미 존재하는 별도 런타임이 있을 때만 다음처럼 경로를 지정합니다.

```powershell
$env:HARNESS_CODEX_NODE = "D:\tools\node18\node.exe"
```

그 별도 런타임 환경에서 `codex-sdk/`의 의존성을 준비한 뒤 앱을 실행하면 화면의 `Main Codex SDK` 스위치를 켤 수 있습니다. Main Codex는 지속되는 단일 프로세스/Thread로 계획만 만들고, Worker는 LLM을 호출하지 않습니다. 자세한 API 사용 방식은 [공식 Codex SDK 문서](https://developers.openai.com/codex/sdk/)를 따릅니다.

## 폴더 구조

```text
console/       설치 없는 HTML/CSS/JS Dashboard
desktop/       설치 없는 Windows WinForms 프로그램
server/        Node 16 로컬 API, scheduler, CTFd adapter, Worker program
codex-sdk/     Node 18+가 있을 때만 쓰는 선택 Coordinator service
contracts/     Decision/Job/WorkerEvent/Result JSON Schema
tests/         설치 없는 E2E/보안 회귀 테스트
_runtime/      실행 산출물(Git 제외)
AGENTS.md      구현 규칙
PRD.md         제품 요구사항
plan.md        단계별 실행 계획
```

## 검사

```powershell
npm run check
npm test
npm run test:desktop
```

테스트는 사설망 host allowlist, 동시 Worker 3개 상한, 9개 Demo E2E, 원문 flag 비노출, JSON 산출물과 데스크톱→API 연동을 확인합니다.

## 참고 UX

화면 흐름은 팀의 과거 PyQt 프로젝트인 [WHS_2nd_ANTIFRAGILE](https://github.com/swyoo1121/WHS_2nd_ANTIFRAGILE)의 파일 선택→실행→결과 테이블과 [Drovis_v3](https://github.com/JJeongsuu/Drovis_v3)의 큰 분석 버튼→진행 상태→이력 UX를 웹 콘솔 형태로 재해석했습니다. 소스 코드는 복사하지 않았습니다.
