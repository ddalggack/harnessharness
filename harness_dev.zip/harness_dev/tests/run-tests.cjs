const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { Harness } = require("../server/harness.cjs");
const { isPrivateHost, normalizeBaseUrl } = require("../server/ctfd.cjs");

const projectRoot = path.resolve(__dirname, "..");

function test(name, fn) {
  return Promise.resolve()
    .then(fn)
    .then(() => process.stdout.write(`PASS ${name}\n`));
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitFor(predicate, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await wait(40);
  }
  throw new Error(`timeout after ${timeoutMs}ms`);
}

async function main() {
  await test("CTFd host allowlist accepts local/private and blocks public hosts", () => {
    assert.strictEqual(isPrivateHost("127.0.0.1"), true);
    assert.strictEqual(isPrivateHost("192.168.10.4"), true);
    assert.strictEqual(isPrivateHost("172.20.0.5"), true);
    assert.strictEqual(isPrivateHost("8.8.8.8"), false);
    assert.throws(() => normalizeBaseUrl("https://example.com"), /사설망/);
  });

  await test("demo run uses at most three independent workers and masks flags", async () => {
    const harness = new Harness(projectRoot);
    try {
      await harness.connect({ mode: "demo", workerLimit: 3, categories: ["pwn", "rev", "web"] });
      const started = harness.startRun();
      const runId = started.run.id;
      let maxActive = 0;
      await waitFor(() => {
        const state = harness.publicState();
        maxActive = Math.max(maxActive, state.workers.filter((worker) => worker.status === "running").length);
        return state.run.status !== "running";
      }, 12000);

      const state = harness.publicState();
      assert.strictEqual(state.run.status, "completed");
      assert.strictEqual(state.run.solved, 9);
      assert.strictEqual(state.run.failed, 0);
      assert.ok(maxActive > 1, `expected parallel workers, saw ${maxActive}`);
      assert.ok(maxActive <= 3, `worker cap exceeded: ${maxActive}`);
      assert.ok(!JSON.stringify(state).includes("DEMO{"), "public state leaked a raw demo flag");

      const runDirectory = path.join(projectRoot, "_runtime", "runs", runId);
      assert.strictEqual(fs.readdirSync(path.join(runDirectory, "decisions")).length, 3);
      assert.strictEqual(fs.readdirSync(path.join(runDirectory, "jobs")).length, 9);
      assert.strictEqual(fs.readdirSync(path.join(runDirectory, "results")).length, 9);
      const eventLog = fs.readFileSync(path.join(runDirectory, "events.jsonl"), "utf8");
      assert.ok(!eventLog.includes("DEMO{"), "event log leaked a raw demo flag");
    } finally {
      harness.shutdown();
    }
  });

  await test("worker limit disables unused slots", async () => {
    const harness = new Harness(projectRoot);
    try {
      const state = await harness.connect({ mode: "demo", workerLimit: 1, categories: ["web"] });
      assert.strictEqual(state.workers.filter((worker) => worker.enabled).length, 1);
      assert.strictEqual(state.challenges.length, 3);
    } finally {
      harness.shutdown();
    }
  });

  process.stdout.write("\nAll harness tests passed.\n");
}

main().catch((error) => {
  process.stderr.write(`FAIL ${error.stack || error.message}\n`);
  process.exitCode = 1;
});
