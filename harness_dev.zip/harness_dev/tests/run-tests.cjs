const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { Harness } = require("../server/harness.cjs");
const { isPrivateHost, normalizeBaseUrl } = require("../server/ctfd.cjs");

const projectRoot = path.resolve(__dirname, "..");

function test(name, fn) {
  return Promise.resolve()
    .then(fn)
    .then(() => process.stdout.write(`PASS ${name}\n`));
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitFor(predicate, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await wait(40);
  }
  throw new Error(`timeout after ${timeoutMs}ms`);
}

async function main() {
  await test("worker event contract defines checkpoint, completed, and failed", () => {
    const schema = JSON.parse(fs.readFileSync(path.join(projectRoot, "contracts", "worker-event.schema.json"), "utf8"));
    assert.deepStrictEqual(schema.properties.kind.enum, ["checkpoint", "completed", "failed"]);
    assert.ok(schema.required.includes("challengeId"));
    assert.ok(schema.required.includes("workerId"));
    assert.ok(schema.required.includes("sequence"));
  });

  await test("desktop and web expose per-challenge progress views", () => {
    const desktop = fs.readFileSync(path.join(projectRoot, "desktop", "HarnessDesktop.ps1"), "utf8");
    const webHtml = fs.readFileSync(path.join(projectRoot, "console", "index.html"), "utf8");
    const webJs = fs.readFileSync(path.join(projectRoot, "console", "app.js"), "utf8");
    assert.ok(desktop.includes("Show-ChallengeProgress"));
    assert.ok(desktop.includes('HeaderText = "상세"'));
    assert.ok(webHtml.includes('id="challenge-dialog"'));
    assert.ok(webJs.includes("openChallengeDetail"));
  });

  await test("desktop worker cards open safe progress views with bounded gauges", () => {
    const desktop = fs.readFileSync(path.join(projectRoot, "desktop", "HarnessDesktop.ps1"), "utf8");
    assert.ok(desktop.includes("Show-WorkerProgress"));
    assert.ok(desktop.includes("Get-OptionalPropertyValue"));
    assert.ok(desktop.includes("$progressTrack = New-Object System.Windows.Forms.Panel"));
    assert.ok(desktop.includes("$progressFill = New-Object System.Windows.Forms.Panel"));
    assert.ok(desktop.includes("$cardClickHandler"));
  });

  await test("HarneHarness branding and right-aligned window controls are exposed", () => {
    const desktop = fs.readFileSync(path.join(projectRoot, "desktop", "HarnessDesktop.ps1"), "utf8");
    const webHtml = fs.readFileSync(path.join(projectRoot, "console", "index.html"), "utf8");
    assert.ok(desktop.includes('$form.Text = "HarneHarness · Desktop Console"'));
    assert.ok(desktop.includes('$windowTitle.Text = "HarneHarness"'));
    assert.ok(desktop.includes('$brandTitle.Text = "HarneHarness"'));
    assert.ok(desktop.includes("$positionWindowControls"));
    assert.ok(desktop.includes("$windowBar.ClientSize.Width - 40"));
    assert.ok(desktop.includes("function New-TitleFont"));
    assert.ok(desktop.includes('$windowBar.BackColor = $TitleColors.Canvas'));
    assert.ok(webHtml.includes("<title>HarneHarness</title>"));
    assert.ok(webHtml.includes("<h1>HarneHarness</h1>"));
  });

  await test("desktop and web use the Thumbprint theme with bundled Noto Sans KR", () => {
    const desktop = fs.readFileSync(path.join(projectRoot, "desktop", "HarnessDesktop.ps1"), "utf8");
    const css = fs.readFileSync(path.join(projectRoot, "console", "styles.css"), "utf8");
    assert.ok(desktop.includes('Primary = New-Color "#5055B1"'));
    assert.ok(desktop.includes('Accent = New-Color "#474C98"'));
    assert.ok(desktop.includes('Ink = New-Color "#595959"'));
    assert.ok(desktop.includes('Canvas = New-Color "#FFFFFF"'));
    assert.ok(desktop.includes('Line = New-Color "#D5D5D5"'));
    assert.ok(desktop.includes('LineStrong = New-Color "#CCCCCC"'));
    assert.ok(desktop.includes('$notoSansKrPath = Join-Path $ProjectRoot "console\\assets\\fonts\\NotoSansKR-Variable.ttf"'));
    assert.ok(desktop.includes('$script:FontSource = "bundled Noto Sans KR"'));
    assert.ok(desktop.includes('TitleAccent = New-Color "#5055B1"'));
    assert.ok(!desktop.includes("LOCAL CTF AUTOMATION"));
    assert.ok(!desktop.includes("$brandSub"));
    assert.ok(css.includes("--primary: #5055b1"));
    assert.ok(css.includes("--accent: #474c98"));
    assert.ok(css.includes("--ink: #595959"));
    assert.ok(css.includes("--canvas: #ffffff"));
    assert.ok(css.includes("--surface: #ffffff"));
    assert.ok(css.includes("--line: #d5d5d5"));
    assert.ok(css.includes("--line-strong: #cccccc"));
    assert.ok(css.includes('@font-face'));
    assert.ok(css.includes('url("/assets/fonts/NotoSansKR-Variable.ttf")'));
    assert.ok(css.includes('font-family: "Noto Sans KR"'));
    assert.ok(!css.includes('font-family: "Geist"'));
    assert.ok(css.includes("--shadow: none"));
    for (const fileName of ["NotoSansKR-Variable.ttf", "NotoSansKR-OFL.txt", "SOURCE.md"]) {
      assert.ok(fs.statSync(path.join(projectRoot, "console", "assets", "fonts", fileName)).size > 0, `${fileName} is missing`);
    }
    assert.match(fs.readFileSync(path.join(projectRoot, "console", "assets", "fonts", "NotoSansKR-OFL.txt"), "utf8"), /SIL OPEN FONT LICENSE Version 1\.1/);
  });

  await test("CTFd host allowlist accepts local/private and blocks public hosts", () => {
    assert.strictEqual(isPrivateHost("127.0.0.1"), true);
    assert.strictEqual(isPrivateHost("192.168.10.4"), true);
    assert.strictEqual(isPrivateHost("172.20.0.5"), true);
    assert.strictEqual(isPrivateHost("8.8.8.8"), false);
    assert.throws(() => normalizeBaseUrl("https://example.com"), /사설망/);
  });

  await test("demo run uses at most three independent workers and masks flags", async () => {
    const harness = new Harness(projectRoot);
    try {
      await harness.connect({ mode: "demo", workerLimit: 3, categories: ["pwn", "rev", "web"] });
      const started = harness.startRun();
      const runId = started.run.id;
      let maxActive = 0;
      await waitFor(() => {
        const state = harness.publicState();
        maxActive = Math.max(maxActive, state.workers.filter((worker) => worker.status === "running").length);
        return state.run.status !== "running";
      }, 12000);

      const state = harness.publicState();
      assert.strictEqual(state.run.status, "completed");
      assert.strictEqual(state.run.solved, 9);
      assert.strictEqual(state.run.failed, 0);
      assert.ok(maxActive > 1, `expected parallel workers, saw ${maxActive}`);
      assert.ok(maxActive <= 3, `worker cap exceeded: ${maxActive}`);
      assert.ok(!JSON.stringify(state).includes("DEMO{"), "public state leaked a raw demo flag");

      const checkpoints = state.events.filter((event) => event.type === "checkpoint");
      const completed = state.events.filter((event) => event.type === "completed");
      const failed = state.events.filter((event) => event.type === "failed");
      assert.ok(checkpoints.length >= 36, `expected checkpoint events, saw ${checkpoints.length}`);
      assert.strictEqual(completed.length, 9);
      assert.strictEqual(failed.length, 0);
      assert.ok(checkpoints.every((event) => event.challengeId && event.workerId && event.sequence));
      const firstChallengeEvents = state.events.filter((event) => event.challengeId === "pwn-01");
      assert.ok(firstChallengeEvents.some((event) => event.type === "checkpoint"));
      assert.ok(firstChallengeEvents.some((event) => event.type === "completed"));
      assert.ok(firstChallengeEvents.some((event) => event.type === "submission"));

      const runDirectory = path.join(projectRoot, "_runtime", "runs", runId);
      assert.strictEqual(fs.readdirSync(path.join(runDirectory, "decisions")).length, 3);
      assert.strictEqual(fs.readdirSync(path.join(runDirectory, "jobs")).length, 9);
      assert.strictEqual(fs.readdirSync(path.join(runDirectory, "results")).length, 9);
      const eventLog = fs.readFileSync(path.join(runDirectory, "events.jsonl"), "utf8");
      assert.ok(!eventLog.includes("DEMO{"), "event log leaked a raw demo flag");
      assert.ok(eventLog.includes('"type":"checkpoint"'));
      assert.ok(eventLog.includes('"type":"completed"'));
    } finally {
      harness.shutdown();
    }
  });

  await test("worker limit disables unused slots", async () => {
    const harness = new Harness(projectRoot);
    try {
      const state = await harness.connect({ mode: "demo", workerLimit: 1, categories: ["web"] });
      assert.strictEqual(state.workers.filter((worker) => worker.enabled).length, 1);
      assert.strictEqual(state.challenges.length, 3);
    } finally {
      harness.shutdown();
    }
  });

  process.stdout.write("\nAll harness tests passed.\n");
}

main().catch((error) => {
  process.stderr.write(`FAIL ${error.stack || error.message}\n`);
  process.exitCode = 1;
});
