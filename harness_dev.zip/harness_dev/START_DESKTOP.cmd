@echo off
setlocal
cd /d "%~dp0"

where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Windows PowerShell was not found.
  echo This launcher does not install or update software.
  pause
  exit /b 1
)

powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0desktop\HarnessDesktop.ps1"

if errorlevel 1 (
  echo.
  echo Desktop Harness ended with an error.
  pause
)
