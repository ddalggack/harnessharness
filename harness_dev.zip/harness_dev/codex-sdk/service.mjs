import { Codex } from "@openai/codex-sdk";
import readline from "node:readline";

const decisionSchema = {
  type: "object",
  properties: {
    summary: { type: "string" },
    actions: {
      type: "array",
      maxItems: 3,
      items: {
        type: "object",
        properties: {
          challengeId: { type: "string" },
          workerProfile: { type: "string", enum: ["pwn", "rev", "web"] },
          operation: { type: "string", enum: ["inspect"] },
          objective: { type: "string" },
          reason: { type: "string" }
        },
        required: ["challengeId", "workerProfile", "operation", "objective", "reason"],
        additionalProperties: false
      }
    }
  },
  required: ["summary", "actions"],
  additionalProperties: false
};

const codex = new Codex();
let thread = null;

async function handle(message) {
  if (message.type !== "plan") throw new Error("지원하지 않는 coordinator 요청입니다.");
  if (!thread) {
    thread = codex.startThread({
      workingDirectory: process.cwd(),
      skipGitRepoCheck: true,
      sandboxMode: "read-only",
      approvalPolicy: "never",
      networkAccessEnabled: false
    });
  }
  const prompt = [
    "You are the single Main Codex coordinator for an authorized local CTF harness.",
    "Do not solve, execute commands, access networks, or submit flags in this planning turn.",
    "Select at most three challenges and assign one matching non-LLM worker profile.",
    "Workers communicate only through JSON and support only the inspect operation.",
    `Challenges: ${JSON.stringify(message.challenges)}`
  ].join("\n");
  const turn = await thread.run(prompt, { outputSchema: decisionSchema });
  return { decision: JSON.parse(turn.finalResponse), threadId: thread.id, usage: turn.usage };
}

const input = readline.createInterface({ input: process.stdin });
input.on("line", async (line) => {
  let message;
  try {
    message = JSON.parse(line);
    const result = await handle(message);
    process.stdout.write(`${JSON.stringify({ id: message.id, ok: true, ...result })}\n`);
  } catch (error) {
    process.stdout.write(`${JSON.stringify({ id: message && message.id, ok: false, error: error.message })}\n`);
  }
});
