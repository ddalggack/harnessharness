# plan.md — CTF Run Harness 실행 계획

## M0. 범위 고정

- [x] Main Codex 하나만 사용
- [x] Worker는 별도 프로그램이며 LLM 미사용
- [x] Swarm/Racing 제외
- [x] 동시 Worker 최대 3
- [x] Demo와 허가된 로컬 CTFd만 지원
- [x] 시스템 Node.js 미변경
- [x] Kubernetes/Temporal은 Backlog

완료 근거: `AGENTS.md`, `PRD.md`, 팀 대화의 고정 조건.

## M1. 버튼형 실행 가능한 Prototype

- [x] Windows 네이티브 WinForms Dashboard
- [x] Desktop에서 API 자동 기동
- [x] Desktop 환경 확인/실행/중지/초기화/보고서 저장
- [x] Desktop Worker Rack/Challenge Queue/Event Log
- [x] Desktop 더블클릭 launcher
- [x] 설치 없는 HTML/CSS/JS Dashboard
- [x] Demo/CTFd 모드 선택
- [x] 분야 및 Worker 1~3 선택
- [x] 환경 확인 버튼
- [x] 자동 풀이 시작/중지/초기화 버튼
- [x] Worker Rack
- [x] Challenge Queue와 상태 필터
- [x] Event Log
- [x] checkpoint/completed/failed 실행 기록
- [x] Desktop/Web 문제별 Worker 진행상황 보기
- [x] 공개 상태 JSON 다운로드
- [x] 더블클릭 Windows launcher

Gate: 기존 Node 16.20.2로 API 기동, Windows PowerShell 5.1에서 네이티브 창 표시 완료.

## M2. JSON 계약과 별도 Worker

- [x] Decision Schema
- [x] Job Schema
- [x] Result Schema
- [x] Worker Event Schema와 JSONL 스트림
- [x] Run/Job/Challenge identity 검증
- [x] Worker Profile allowlist
- [x] operation allowlist
- [x] Worker를 별도 프로세스로 실행
- [x] Job/Result를 실행별 파일로 저장
- [x] 동시 실행 상한 3
- [x] 중지 시 자식 Worker만 종료

Gate: Demo 9개에서 Decision 3, Job 9, Result 9 파일 생성.

## M3. Submission과 안전 경계

- [x] Submission Broker 단일 제출 경로
- [x] 후보 SHA-256 중복 차단
- [x] 공개 state/Event Log 원문 flag 비노출
- [x] Token 메모리 보관
- [x] localhost/RFC1918 host allowlist
- [x] 허가 확인 없으면 CTFd 차단
- [x] CTFd 문제 목록 Adapter
- [x] CTFd flag 제출 Adapter
- [ ] 실제 로컬 CTFd known flag smoke test

Gate: 단위/E2E 테스트 통과 후 실제 CTFd 시험은 팀 환경 준비 시 수행.

## M4. Main Codex Coordinator

- [x] Core와 SDK 런타임 분리
- [x] SDK service 지속 프로세스
- [x] 같은 Main Thread 재사용
- [x] structured output Decision
- [x] action 최대 3 Schema
- [x] read-only/no-network planning 설정
- [x] Node 18+가 없으면 SDK만 비활성화
- [ ] 별도 Node 18+ 환경에서 패키지 설치 재현
- [ ] 실제 Codex 인증 및 Thread ID checkpoint 시험
- [ ] 실패 후 같은 Thread replan 시험

Gate: 수업 PC 시스템 Node를 변경하지 않은 별도 런타임으로 검증해야 완료.

## M5. 실제 분야별 Worker vertical slice

현재 Demo Worker는 파이프라인을 검증하며 실제 CTFd 모드에서는 `needs_tooling`을 반환한다.

### 공통

- [ ] Docker worker base image
- [ ] workspace mount와 read/write 경계
- [ ] timeout, CPU, memory, output limit
- [ ] challenge host network allowlist
- [ ] artifact SHA-256 index

### PWN

- [ ] `file`, `checksec`, `strings`, `readelf`, `objdump`
- [ ] pwntools script artifact 실행 경로
- [ ] 쉬운 fixture 1개 E2E

### REV

- [ ] `file`, `strings`, `readelf`, `objdump`
- [ ] radare2 headless adapter
- [ ] 쉬운 fixture 1개 E2E

### WEB

- [ ] method/host allowlist HTTP adapter
- [ ] timeout/response size 제한
- [ ] 쉬운 fixture 1개 E2E

Gate: 각 분야에서 Worker가 LLM 없이 Job을 수행하고 CTFd `correct`까지 도달.

## M6. 자동 테스트와 발표 준비

- [x] Node 문법 검사
- [x] host allowlist 테스트
- [x] Demo 9개 E2E
- [x] 최대 동시 Worker 측정
- [x] 원문 flag 비노출 검사
- [x] Run artifact 개수 검사
- [x] PowerShell WinForms 문법 검사
- [x] Desktop→API SelfTest
- [x] Worker 이벤트 식별자·순번·종류 회귀 테스트
- [x] 실제 Desktop 창 표시와 전체 레이아웃 확인
- [ ] 깨끗한 팀원 PC 재현
- [ ] 실제 로컬 CTFd 통합 시험
- [ ] Main Codex SDK 통합 시험
- [ ] 실패/중지 발표 시나리오 녹화
- [ ] Baseline vs Harness 비교 표

## M7. 발표 이후 Backlog

- [ ] Docker Scheduler 완성
- [ ] Kubernetes Job/Pod Scheduler
- [ ] Temporal durable workflow
- [ ] PostgreSQL run/checkpoint/event repository
- [ ] S3/MinIO artifact repository
- [ ] SSE 또는 WebSocket 이벤트 push
- [ ] rCTF/Custom Platform Adapter
- [ ] 9문제 평가 세트와 holdout

## 다음 팀 작업 순서

1. 팀원 PC에서 `START_HARNESS.cmd` Demo 재현
2. 로컬 CTFd URL/Token으로 조회 smoke test
3. 자동 제출을 끄고 실제 문제 metadata 확인
4. 별도 Node 18+ 환경이 이미 있는 팀원만 Main Codex SDK 검증
5. web 쉬운 문제 1개부터 Docker Worker vertical slice
6. pwn, rev 순으로 도구 profile 확장
