﻿param(
    [switch]$SelfTest,
    [switch]$UiSmokeTest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ApiBase = "http://127.0.0.1:8788"
$script:OwnedServer = $null
$script:CurrentState = $null
$script:Refreshing = $false

function Invoke-HarnessApi {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [ValidateSet("GET", "POST")][string]$Method = "GET",
        [object]$Body = $null,
        [int]$TimeoutSec = 6
    )

    $parameters = @{
        Uri = "$ApiBase$Path"
        Method = $Method
        TimeoutSec = $TimeoutSec
        UseBasicParsing = $true
    }
    if ($null -ne $Body) {
        $json = $Body | ConvertTo-Json -Depth 10 -Compress
        $parameters.ContentType = "application/json; charset=utf-8"
        $parameters.Body = [System.Text.Encoding]::UTF8.GetBytes($json)
    }
    try {
        return Invoke-RestMethod @parameters
    }
    catch {
        $errorRecord = $_
        $message = $errorRecord.Exception.Message
        $responseBody = $null

        if ($null -ne $errorRecord.ErrorDetails -and -not [string]::IsNullOrWhiteSpace($errorRecord.ErrorDetails.Message)) {
            $responseBody = $errorRecord.ErrorDetails.Message
        }

        if ([string]::IsNullOrWhiteSpace($responseBody) -and $null -ne $errorRecord.Exception.Response) {
            try {
                $responseStream = $errorRecord.Exception.Response.GetResponseStream()
                if ($null -ne $responseStream) {
                    $reader = New-Object System.IO.StreamReader($responseStream, [System.Text.Encoding]::UTF8)
                    try {
                        $responseBody = $reader.ReadToEnd()
                    }
                    finally {
                        $reader.Dispose()
                    }
                }
            }
            catch {
                # Keep the original transport error if the response body cannot be read.
            }
        }

        if (-not [string]::IsNullOrWhiteSpace($responseBody)) {
            try {
                $errorPayload = $responseBody | ConvertFrom-Json
                if ($null -ne $errorPayload.error -and -not [string]::IsNullOrWhiteSpace([string]$errorPayload.error)) {
                    $message = [string]$errorPayload.error
                }
                elseif ($null -ne $errorPayload.message -and -not [string]::IsNullOrWhiteSpace([string]$errorPayload.message)) {
                    $message = [string]$errorPayload.message
                }
            }
            catch {
                # A non-JSON response still falls back to the original HTTP error.
            }
        }

        throw (New-Object System.Exception($message, $errorRecord.Exception))
    }
}

function Test-HarnessApi {
    try {
        $health = Invoke-HarnessApi -Path "/api/health" -TimeoutSec 1
        return [bool]$health.ok
    }
    catch {
        return $false
    }
}

function Ensure-HarnessApi {
    if (Test-HarnessApi) {
        return
    }

    $nodeCommand = Get-Command "node.exe" -ErrorAction SilentlyContinue
    if ($null -eq $nodeCommand) {
        throw "기존 Node.js 실행 파일을 찾지 못했습니다. 이 프로그램은 Node.js를 설치하거나 업데이트하지 않습니다."
    }

    $script:OwnedServer = Start-Process `
        -FilePath $nodeCommand.Source `
        -ArgumentList @("server\index.cjs") `
        -WorkingDirectory $ProjectRoot `
        -WindowStyle Hidden `
        -PassThru

    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Milliseconds 150
        if (Test-HarnessApi) {
            return
        }
        if ($script:OwnedServer.HasExited) {
            break
        }
    }
    throw "Harness API를 시작하지 못했습니다. server/index.cjs 실행 상태를 확인하세요."
}

function Stop-OwnedServer {
    if ($null -eq $script:OwnedServer) {
        return
    }
    try {
        $process = Get-Process -Id $script:OwnedServer.Id -ErrorAction SilentlyContinue
        if ($null -ne $process -and $process.ProcessName -eq "node") {
            Stop-Process -Id $process.Id -Force
        }
    }
    catch {
        # The process may already be gone. Never stop a process we did not launch.
    }
    $script:OwnedServer = $null
}

if ($SelfTest) {
    try {
        Ensure-HarnessApi
        $payload = @{
            mode = "demo"
            workerLimit = 3
            categories = @("pwn", "rev", "web")
            autoSubmit = $true
            authorized = $true
        }
        $connected = Invoke-HarnessApi -Path "/api/connect" -Method "POST" -Body $payload

        $guardMessage = $null
        try {
            Invoke-HarnessApi -Path "/api/connect" -Method "POST" -Body @{
                mode = "ctfd"
                workerLimit = 3
                categories = @("pwn", "rev", "web")
                baseUrl = "http://127.0.0.1:8000"
                apiToken = ""
                autoSubmit = $false
                authorized = $false
            } | Out-Null
        }
        catch {
            $guardMessage = $_.Exception.Message
        }
        if ([string]::IsNullOrWhiteSpace($guardMessage) -or $guardMessage -notmatch "허가") {
            throw "Desktop이 API의 상세 오류 메시지를 표시하지 못했습니다."
        }

        $summary = [ordered]@{
            desktopApi = "ok"
            mode = $connected.connection.mode
            challenges = @($connected.challenges).Count
            workerLimit = $connected.config.workerLimit
            systemNode = $connected.environment.nodeVersion
            validationMessage = $guardMessage
        }
        $summary | ConvertTo-Json
        exit 0
    }
    catch {
        [Console]::Error.WriteLine($_.Exception.Message)
        exit 1
    }
    finally {
        Stop-OwnedServer
    }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:PrivateFonts = New-Object System.Drawing.Text.PrivateFontCollection
$notoSansKrPath = Join-Path $ProjectRoot "console\assets\fonts\NotoSansKR-Variable.ttf"
$notoSansKrFamily = $null
if (Test-Path -LiteralPath $notoSansKrPath) {
    try {
        $script:PrivateFonts.AddFontFile($notoSansKrPath)
        $notoSansKrFamily = @($script:PrivateFonts.Families | Where-Object { $_.Name -eq "Noto Sans KR" } | Select-Object -First 1)
        if ($notoSansKrFamily.Count -gt 0) { $notoSansKrFamily = $notoSansKrFamily[0] } else { $notoSansKrFamily = $null }
    }
    catch {
        $notoSansKrFamily = $null
    }
}
if ($null -ne $notoSansKrFamily) {
    $script:UiFontFamily = $notoSansKrFamily
    $script:FontSource = "bundled Noto Sans KR"
}
else {
    $script:UiFontFamily = New-Object System.Drawing.FontFamily("Segoe UI")
    $script:FontSource = "Segoe UI fallback"
}
$script:UiFontName = $script:UiFontFamily.Name
$script:DisplayFontName = $script:UiFontName

function New-UiFont {
    param([float]$Size = 9, [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular)
    return New-Object System.Drawing.Font($script:UiFontFamily, $Size, $Style)
}

function New-DisplayFont {
    param([float]$Size = 14, [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular)
    return New-Object System.Drawing.Font($script:UiFontFamily, $Size, $Style)
}

function New-TitleFont {
    param([float]$Size = 9, [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular)
    return New-Object System.Drawing.Font($script:UiFontFamily, $Size, $Style)
}

function New-Color {
    param([string]$Hex)
    return [System.Drawing.ColorTranslator]::FromHtml($Hex)
}

function Set-RoundedRegion {
    param(
        [Parameter(Mandatory = $true)][System.Windows.Forms.Control]$Control,
        [int]$Radius = 12
    )
    if ($Control.Width -le 1 -or $Control.Height -le 1) { return }
    $diameter = [Math]::Min($Radius * 2, [Math]::Min($Control.Width, $Control.Height))
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    if ($diameter -le 2) {
        $path.AddRectangle((New-Object System.Drawing.Rectangle(0, 0, $Control.Width, $Control.Height)))
    }
    else {
        $arc = New-Object System.Drawing.Rectangle(0, 0, $diameter, $diameter)
        $path.AddArc($arc, 180, 90)
        $arc.X = $Control.Width - $diameter
        $path.AddArc($arc, 270, 90)
        $arc.Y = $Control.Height - $diameter
        $path.AddArc($arc, 0, 90)
        $arc.X = 0
        $path.AddArc($arc, 90, 90)
        $path.CloseFigure()
    }
    $oldRegion = $Control.Region
    $Control.Region = New-Object System.Drawing.Region($path)
    if ($null -ne $oldRegion) { $oldRegion.Dispose() }
    $path.Dispose()
}

function Enable-RoundedControl {
    param(
        [Parameter(Mandatory = $true)][System.Windows.Forms.Control]$Control,
        [int]$Radius = 12
    )
    $controlRef = $Control
    $radiusValue = $Radius
    $applyRegion = { Set-RoundedRegion -Control $controlRef -Radius $radiusValue }.GetNewClosure()
    & $applyRegion
    $Control.Add_SizeChanged($applyRegion)
}

function New-TrafficButton {
    param([System.Drawing.Color]$Color, [int]$Left, [string]$AccessibleName)
    $button = New-Object System.Windows.Forms.Button
    $button.Location = New-Object System.Drawing.Point($Left, 8)
    $button.Size = New-Object System.Drawing.Size(26, 26)
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.FlatAppearance.BorderSize = 1
    $button.FlatAppearance.BorderColor = $TitleColors.Line
    $button.BackColor = $TitleColors.Paper
    $button.ForeColor = $Color
    $button.Text = $(if ($AccessibleName -match "닫기") { "×" } elseif ($AccessibleName -match "최소화") { "−" } else { "□" })
    $button.Font = New-TitleFont 9 ([System.Drawing.FontStyle]::Bold)
    $button.AccessibleName = $AccessibleName
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    Enable-RoundedControl $button 4
    return $button
}

$Colors = @{
    Primary = New-Color "#5055B1"
    Accent = New-Color "#474C98"
    Ink = New-Color "#595959"
    Muted = New-Color "#595959"
    Canvas = New-Color "#FFFFFF"
    Paper = New-Color "#FFFFFF"
    Navy = New-Color "#474C98"
    Navy2 = New-Color "#FFFFFF"
    ButtonDark = New-Color "#5055B1"
    ButtonText = New-Color "#FFFFFF"
    Green = New-Color "#2D8A63"
    Amber = New-Color "#C08532"
    Red = New-Color "#B23A3F"
    Line = New-Color "#D5D5D5"
    LineStrong = New-Color "#CCCCCC"
    Soft = New-Color "#F5F5F5"
    Emphasis = New-Color "#FFFFFF"
    Selected = New-Color "#F1F1F7"
    Log = New-Color "#474C98"
}

$TitleColors = @{
    Canvas = New-Color "#FFFFFF"
    Paper = New-Color "#FFFFFF"
    Line = New-Color "#D5D5D5"
    Text = New-Color "#595959"
    Close = New-Color "#B23A3F"
    Minimize = New-Color "#595959"
    TitleAccent = New-Color "#5055B1"
}

function Set-FlatButtonStyle {
    param(
        [System.Windows.Forms.Button]$Button,
        [System.Drawing.Color]$BackColor,
        [System.Drawing.Color]$ForeColor,
        [int]$Height = 42
    )
    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 0
    $Button.BackColor = $BackColor
    $Button.ForeColor = $ForeColor
    $Button.Font = New-UiFont 9.5 ([System.Drawing.FontStyle]::Regular)
    $Button.Height = $Height
    $Button.Cursor = [System.Windows.Forms.Cursors]::Hand
    Enable-RoundedControl $Button ([Math]::Floor($Height / 2))
}

function Show-AppError {
    param([string]$Message)
    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        "HarneHarness",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

try {
    Ensure-HarnessApi
    $script:CurrentState = Invoke-HarnessApi -Path "/api/state"
}
catch {
    Show-AppError $_.Exception.Message
    Stop-OwnedServer
    exit 1
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "HarneHarness · Desktop Console"
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$form.Size = New-Object System.Drawing.Size(1280, 860)
$form.MinimumSize = New-Object System.Drawing.Size(1100, 760)
$form.BackColor = $TitleColors.Line
$form.Font = New-UiFont 9
$form.KeyPreview = $true
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$form.Padding = New-Object System.Windows.Forms.Padding(1)

$windowBar = New-Object System.Windows.Forms.Panel
$windowBar.Dock = [System.Windows.Forms.DockStyle]::Top
$windowBar.Height = 42
$windowBar.BackColor = $TitleColors.Canvas

$closeButton = New-TrafficButton $TitleColors.Close 14 "창 닫기"
$minimizeButton = New-TrafficButton $TitleColors.Minimize 44 "창 최소화"
$maximizeButton = New-TrafficButton $TitleColors.TitleAccent 74 "창 크기 전환"
$windowBar.Controls.Add($closeButton)
$windowBar.Controls.Add($minimizeButton)
$windowBar.Controls.Add($maximizeButton)

foreach ($windowControl in @($closeButton, $minimizeButton, $maximizeButton)) {
    $windowControl.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
}
$positionWindowControls = {
    $closeButton.Left = [Math]::Max(0, $windowBar.ClientSize.Width - 40)
    $maximizeButton.Left = [Math]::Max(0, $windowBar.ClientSize.Width - 70)
    $minimizeButton.Left = [Math]::Max(0, $windowBar.ClientSize.Width - 100)
}
$windowBar.Add_SizeChanged($positionWindowControls)

$windowTitle = New-Object System.Windows.Forms.Label
$windowTitle.Text = "HarneHarness"
$windowTitle.Dock = [System.Windows.Forms.DockStyle]::Fill
$windowTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$windowTitle.ForeColor = $TitleColors.Text
$windowTitle.Font = New-TitleFont 8.5 ([System.Drawing.FontStyle]::Regular)
$windowBar.Controls.Add($windowTitle)
$windowTitle.SendToBack()

$header = New-Object System.Windows.Forms.Panel
$header.Dock = [System.Windows.Forms.DockStyle]::Top
$header.Height = 68
$header.BackColor = $Colors.Paper

$brandBox = New-Object System.Windows.Forms.Label
$brandBox.Text = "H"
$brandBox.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$brandBox.Location = New-Object System.Drawing.Point(24, 12)
$brandBox.Size = New-Object System.Drawing.Size(44, 44)
$brandBox.ForeColor = $Colors.ButtonText
$brandBox.BackColor = $Colors.ButtonDark
$brandBox.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$brandBox.Font = New-DisplayFont 14 ([System.Drawing.FontStyle]::Bold)
Enable-RoundedControl $brandBox 4
$header.Controls.Add($brandBox)

$brandTitle = New-Object System.Windows.Forms.Label
$brandTitle.Text = "HarneHarness"
$brandTitle.ForeColor = $Colors.Ink
$brandTitle.Location = New-Object System.Drawing.Point(82, 23)
$brandTitle.AutoSize = $true
$brandTitle.Font = New-DisplayFont 14 ([System.Drawing.FontStyle]::Bold)
$header.Controls.Add($brandTitle)

$apiStatus = New-Object System.Windows.Forms.Label
$apiStatus.Text = "●  LOCAL API ONLINE"
$apiStatus.ForeColor = $Colors.Green
$apiStatus.BackColor = $Colors.Emphasis
$apiStatus.Size = New-Object System.Drawing.Size(218, 30)
$apiStatus.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$apiStatus.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
$apiStatus.Location = New-Object System.Drawing.Point(1028, 19)
$apiStatus.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
Enable-RoundedControl $apiStatus 15
$header.Controls.Add($apiStatus)

$bodyPanel = New-Object System.Windows.Forms.Panel
$bodyPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$bodyPanel.BackColor = $Colors.Canvas

$sidebar = New-Object System.Windows.Forms.Panel
$sidebar.Dock = [System.Windows.Forms.DockStyle]::Left
$sidebar.Width = 300
$sidebar.Padding = New-Object System.Windows.Forms.Padding(20)
$sidebar.BackColor = $Colors.Canvas
$sidebar.AutoScroll = $true

$mainPanel = New-Object System.Windows.Forms.Panel
$mainPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$mainPanel.Padding = New-Object System.Windows.Forms.Padding(20)
$mainPanel.BackColor = $Colors.Canvas

$bodyPanel.Controls.Add($mainPanel)
$bodyPanel.Controls.Add($sidebar)
$form.Controls.Add($bodyPanel)
$form.Controls.Add($header)
$form.Controls.Add($windowBar)

$controlTitle = New-Object System.Windows.Forms.Label
$controlTitle.Text = "01   대상 연결"
$controlTitle.Location = New-Object System.Drawing.Point(20, 20)
$controlTitle.Size = New-Object System.Drawing.Size(235, 26)
$controlTitle.ForeColor = $Colors.Ink
$controlTitle.Font = New-UiFont 11 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($controlTitle)

$connectionLabel = New-Object System.Windows.Forms.Label
$connectionLabel.Text = "연결 전"
$connectionLabel.Location = New-Object System.Drawing.Point(20, 49)
$connectionLabel.Size = New-Object System.Drawing.Size(235, 22)
$connectionLabel.ForeColor = $Colors.Muted
$connectionLabel.Font = New-UiFont 8
$sidebar.Controls.Add($connectionLabel)

$modeLabel = New-Object System.Windows.Forms.Label
$modeLabel.Text = "실행 모드"
$modeLabel.Location = New-Object System.Drawing.Point(20, 82)
$modeLabel.AutoSize = $true
$modeLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($modeLabel)

$modeCombo = New-Object System.Windows.Forms.ComboBox
$modeCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$modeCombo.Items.AddRange(@("안전모드", "로컬 CTFd"))
$modeCombo.SelectedIndex = 0
$modeCombo.Location = New-Object System.Drawing.Point(20, 103)
$modeCombo.Size = New-Object System.Drawing.Size(235, 28)
$modeCombo.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$modeCombo.BackColor = $Colors.Paper
$modeCombo.ForeColor = $Colors.Ink
$sidebar.Controls.Add($modeCombo)

$urlLabel = New-Object System.Windows.Forms.Label
$urlLabel.Text = "CTFd URL"
$urlLabel.Location = New-Object System.Drawing.Point(20, 143)
$urlLabel.AutoSize = $true
$urlLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($urlLabel)

$urlText = New-Object System.Windows.Forms.TextBox
$urlText.Location = New-Object System.Drawing.Point(20, 164)
$urlText.Size = New-Object System.Drawing.Size(235, 24)
$urlText.Text = "http://127.0.0.1:8000"
$urlText.Enabled = $false
$urlText.BackColor = $Colors.Paper
$urlText.ForeColor = $Colors.Ink
$sidebar.Controls.Add($urlText)

$tokenLabel = New-Object System.Windows.Forms.Label
$tokenLabel.Text = "API Token · 메모리에만 보관"
$tokenLabel.Location = New-Object System.Drawing.Point(20, 199)
$tokenLabel.AutoSize = $true
$tokenLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($tokenLabel)

$tokenText = New-Object System.Windows.Forms.TextBox
$tokenText.Location = New-Object System.Drawing.Point(20, 220)
$tokenText.Size = New-Object System.Drawing.Size(235, 24)
$tokenText.UseSystemPasswordChar = $true
$tokenText.Enabled = $false
$tokenText.BackColor = $Colors.Paper
$tokenText.ForeColor = $Colors.Ink
$sidebar.Controls.Add($tokenText)

$categoryLabel = New-Object System.Windows.Forms.Label
$categoryLabel.Text = "문제 분야"
$categoryLabel.Location = New-Object System.Drawing.Point(20, 258)
$categoryLabel.AutoSize = $true
$categoryLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($categoryLabel)

$pwnCheck = New-Object System.Windows.Forms.CheckBox
$pwnCheck.Text = "PWN"
$pwnCheck.Checked = $true
$pwnCheck.Location = New-Object System.Drawing.Point(20, 280)
$pwnCheck.Size = New-Object System.Drawing.Size(67, 25)
$sidebar.Controls.Add($pwnCheck)

$revCheck = New-Object System.Windows.Forms.CheckBox
$revCheck.Text = "REV"
$revCheck.Checked = $true
$revCheck.Location = New-Object System.Drawing.Point(94, 280)
$revCheck.Size = New-Object System.Drawing.Size(67, 25)
$sidebar.Controls.Add($revCheck)

$webCheck = New-Object System.Windows.Forms.CheckBox
$webCheck.Text = "WEB"
$webCheck.Checked = $true
$webCheck.Location = New-Object System.Drawing.Point(171, 280)
$webCheck.Size = New-Object System.Drawing.Size(67, 25)
$sidebar.Controls.Add($webCheck)

$workerLabel = New-Object System.Windows.Forms.Label
$workerLabel.Text = "Worker · 최대 3"
$workerLabel.Location = New-Object System.Drawing.Point(20, 316)
$workerLabel.AutoSize = $true
$workerLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($workerLabel)

$workerCount = New-Object System.Windows.Forms.NumericUpDown
$workerCount.Location = New-Object System.Drawing.Point(20, 338)
$workerCount.Size = New-Object System.Drawing.Size(235, 25)
$workerCount.Minimum = 1
$workerCount.Maximum = 3
$workerCount.Value = 3
$workerCount.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center
$sidebar.Controls.Add($workerCount)

$codexCheck = New-Object System.Windows.Forms.CheckBox
$codexCheck.Text = "Main Codex SDK 사용"
$codexCheck.Location = New-Object System.Drawing.Point(20, 378)
$codexCheck.Size = New-Object System.Drawing.Size(235, 24)
$codexCheck.Enabled = $false
$sidebar.Controls.Add($codexCheck)

$autoSubmitCheck = New-Object System.Windows.Forms.CheckBox
$autoSubmitCheck.Text = "Flag 자동 제출"
$autoSubmitCheck.Checked = $true
$autoSubmitCheck.Location = New-Object System.Drawing.Point(20, 405)
$autoSubmitCheck.Size = New-Object System.Drawing.Size(235, 24)
$autoSubmitCheck.Enabled = $false
$sidebar.Controls.Add($autoSubmitCheck)

$authorizedCheck = New-Object System.Windows.Forms.CheckBox
$authorizedCheck.Text = "허가된 로컬 CTFd입니다"
$authorizedCheck.Location = New-Object System.Drawing.Point(20, 432)
$authorizedCheck.Size = New-Object System.Drawing.Size(235, 24)
$authorizedCheck.Enabled = $false
$sidebar.Controls.Add($authorizedCheck)

$connectButton = New-Object System.Windows.Forms.Button
$connectButton.Text = "문제 불러오기"
$connectButton.Location = New-Object System.Drawing.Point(20, 474)
$connectButton.Size = New-Object System.Drawing.Size(235, 44)
Set-FlatButtonStyle $connectButton $Colors.ButtonDark $Colors.ButtonText 48
$sidebar.Controls.Add($connectButton)

$safeBox = New-Object System.Windows.Forms.Panel
$safeBox.Location = New-Object System.Drawing.Point(20, 532)
$safeBox.Size = New-Object System.Drawing.Size(235, 74)
$safeBox.BackColor = $Colors.Soft
$safeBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
Enable-RoundedControl $safeBox 4
$sidebar.Controls.Add($safeBox)

$safeTitle = New-Object System.Windows.Forms.Label
$safeTitle.Text = "✓  로컬 전용 안전장치"
$safeTitle.Location = New-Object System.Drawing.Point(10, 9)
$safeTitle.AutoSize = $true
$safeTitle.ForeColor = $Colors.Green
$safeTitle.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$safeBox.Controls.Add($safeTitle)

$safeText = New-Object System.Windows.Forms.Label
$safeText.Text = "공인 인터넷 CTF 주소와 허가되지 않은`r`n대상은 API 단계에서 차단합니다."
$safeText.Location = New-Object System.Drawing.Point(10, 31)
$safeText.Size = New-Object System.Drawing.Size(210, 34)
$safeText.ForeColor = $Colors.Muted
$safeText.Font = New-UiFont 7.5
$safeBox.Controls.Add($safeText)

$mainLayout = New-Object System.Windows.Forms.TableLayoutPanel
$mainLayout.Dock = [System.Windows.Forms.DockStyle]::Fill
$mainLayout.ColumnCount = 1
$mainLayout.RowCount = 5
$mainLayout.BackColor = $Colors.Canvas
$mainLayout.Padding = New-Object System.Windows.Forms.Padding(0)
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 138)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 88)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 158)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 122)))
$mainPanel.Controls.Add($mainLayout)

$launchPanel = New-Object System.Windows.Forms.Panel
$launchPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$launchPanel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$launchPanel.BackColor = $Colors.Paper
$launchPanel.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
Enable-RoundedControl $launchPanel 4
$mainLayout.Controls.Add($launchPanel, 0, 0)

$runStateLabel = New-Object System.Windows.Forms.Label
$runStateLabel.Text = "READY FOR CHECK"
$runStateLabel.Location = New-Object System.Drawing.Point(22, 20)
$runStateLabel.AutoSize = $true
$runStateLabel.ForeColor = $Colors.Accent
$runStateLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$launchPanel.Controls.Add($runStateLabel)

$launchTitle = New-Object System.Windows.Forms.Label
$launchTitle.Text = "문제를 가져오고 Worker를 출발시키세요."
$launchTitle.Location = New-Object System.Drawing.Point(22, 42)
$launchTitle.Size = New-Object System.Drawing.Size(500, 30)
$launchTitle.ForeColor = $Colors.Ink
$launchTitle.Font = New-DisplayFont 15 ([System.Drawing.FontStyle]::Bold)
$launchPanel.Controls.Add($launchTitle)

$runMessage = New-Object System.Windows.Forms.Label
$runMessage.Text = "왼쪽에서 Demo 또는 로컬 CTFd 환경을 먼저 확인합니다."
$runMessage.Location = New-Object System.Drawing.Point(24, 78)
$runMessage.Size = New-Object System.Drawing.Size(550, 24)
$runMessage.ForeColor = $Colors.Muted
$runMessage.Font = New-UiFont 8.5
$launchPanel.Controls.Add($runMessage)

$runButton = New-Object System.Windows.Forms.Button
$runButton.Text = "▶  자동 풀이 시작"
$runButton.Size = New-Object System.Drawing.Size(176, 46)
$runButton.Location = New-Object System.Drawing.Point(610, 27)
$runButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $runButton $Colors.ButtonDark $Colors.ButtonText 48
$runButton.Enabled = $false
$launchPanel.Controls.Add($runButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "중지"
$stopButton.Size = New-Object System.Drawing.Size(72, 46)
$stopButton.Location = New-Object System.Drawing.Point(792, 27)
$stopButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $stopButton $Colors.Soft $Colors.Red 48
$stopButton.Enabled = $false
$launchPanel.Controls.Add($stopButton)

$resetButton = New-Object System.Windows.Forms.Button
$resetButton.Text = "초기화"
$resetButton.Size = New-Object System.Drawing.Size(72, 27)
$resetButton.Location = New-Object System.Drawing.Point(792, 80)
$resetButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $resetButton $Colors.Soft $Colors.Ink 27
$launchPanel.Controls.Add($resetButton)

$exportButton = New-Object System.Windows.Forms.Button
$exportButton.Text = "실행 기록 저장"
$exportButton.Size = New-Object System.Drawing.Size(98, 27)
$exportButton.Location = New-Object System.Drawing.Point(688, 80)
$exportButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $exportButton $Colors.Soft $Colors.Ink 27
$launchPanel.Controls.Add($exportButton)

$runProgressTrack = New-Object System.Windows.Forms.Panel
$runProgressTrack.Dock = [System.Windows.Forms.DockStyle]::Bottom
$runProgressTrack.Height = 6
$runProgressTrack.BackColor = $Colors.Soft
$runProgressTrack.Tag = 0

$runProgressFill = New-Object System.Windows.Forms.Panel
$runProgressFill.Dock = [System.Windows.Forms.DockStyle]::Left
$runProgressFill.Width = 0
$runProgressFill.BackColor = $Colors.Accent
$runProgressTrack.Controls.Add($runProgressFill)
$launchPanel.Controls.Add($runProgressTrack)
$runProgressTrack.Add_SizeChanged({
    $percent = [Math]::Max(0, [Math]::Min(100, [int]$runProgressTrack.Tag))
    $runProgressFill.Width = [Math]::Floor($runProgressTrack.ClientSize.Width * $percent / 100)
})

$metricLayout = New-Object System.Windows.Forms.TableLayoutPanel
$metricLayout.Dock = [System.Windows.Forms.DockStyle]::Fill
$metricLayout.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$metricLayout.ColumnCount = 4
$metricLayout.RowCount = 1
for ($i = 0; $i -lt 4; $i++) {
    $metricLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 25)))
}
$mainLayout.Controls.Add($metricLayout, 0, 1)

function New-MetricCard {
    param([string]$Title, [string]$Subtitle)
    $card = New-Object System.Windows.Forms.Panel
    $card.Dock = [System.Windows.Forms.DockStyle]::Fill
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 9, 0)
    $card.BackColor = $Colors.Paper
    $card.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    Enable-RoundedControl $card 4

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = $Title
    $titleLabel.Location = New-Object System.Drawing.Point(13, 8)
    $titleLabel.AutoSize = $true
    $titleLabel.ForeColor = $Colors.Muted
    $titleLabel.Font = New-UiFont 7.5 ([System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($titleLabel)

    $valueLabel = New-Object System.Windows.Forms.Label
    $valueLabel.Text = "0"
    $valueLabel.Location = New-Object System.Drawing.Point(12, 27)
    $valueLabel.Size = New-Object System.Drawing.Size(120, 28)
    $valueLabel.ForeColor = $Colors.Ink
    $valueLabel.Font = New-DisplayFont 17 ([System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($valueLabel)

    $subLabel = New-Object System.Windows.Forms.Label
    $subLabel.Text = $Subtitle
    $subLabel.Location = New-Object System.Drawing.Point(13, 56)
    $subLabel.AutoSize = $true
    $subLabel.ForeColor = $Colors.Muted
    $subLabel.Font = New-UiFont 7 ([System.Drawing.FontStyle]::Regular)
    $card.Controls.Add($subLabel)
    return [PSCustomObject]@{ Panel = $card; Value = $valueLabel; Subtitle = $subLabel }
}

$metricTotal = New-MetricCard "전체 문제" "선택된 문제"
$metricSolved = New-MetricCard "정답 확인" "정답 승인 기준"
$metricWorkers = New-MetricCard "작업 중인 Worker" "최대 3개"
$metricProgress = New-MetricCard "진행률" "IDLE"
$metricLayout.Controls.Add($metricTotal.Panel, 0, 0)
$metricLayout.Controls.Add($metricSolved.Panel, 1, 0)
$metricLayout.Controls.Add($metricWorkers.Panel, 2, 0)
$metricProgress.Panel.Margin = New-Object System.Windows.Forms.Padding(0)
$metricLayout.Controls.Add($metricProgress.Panel, 3, 0)

$workerGroup = New-Object System.Windows.Forms.GroupBox
$workerGroup.Text = "03   Worker 현황 · JSON I/O · 별도 프로세스"
$workerGroup.Dock = [System.Windows.Forms.DockStyle]::Fill
$workerGroup.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$workerGroup.BackColor = $Colors.Paper
$workerGroup.ForeColor = $Colors.Ink
$workerGroup.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Bold)
$workerGroup.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
Enable-RoundedControl $workerGroup 4
$mainLayout.Controls.Add($workerGroup, 0, 2)

$workerLayout = New-Object System.Windows.Forms.TableLayoutPanel
$workerLayout.Dock = [System.Windows.Forms.DockStyle]::Fill
$workerLayout.Padding = New-Object System.Windows.Forms.Padding(8, 7, 8, 8)
$workerLayout.ColumnCount = 3
$workerLayout.RowCount = 1
for ($i = 0; $i -lt 3; $i++) {
    $workerLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 33.333)))
}
$workerGroup.Controls.Add($workerLayout)

$workerViews = @()
for ($i = 1; $i -le 3; $i++) {
    $card = New-Object System.Windows.Forms.Panel
    $card.Dock = [System.Windows.Forms.DockStyle]::Fill
    $card.Margin = New-Object System.Windows.Forms.Padding(3)
    $card.BackColor = $Colors.Paper
    $card.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    Enable-RoundedControl $card 4

    $name = New-Object System.Windows.Forms.Label
    $name.Text = "●  Worker $($i.ToString('00'))"
    $name.Location = New-Object System.Drawing.Point(12, 10)
    $name.Size = New-Object System.Drawing.Size(135, 20)
    $name.ForeColor = $Colors.Ink
    $name.Font = New-UiFont 8.5 ([System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($name)

    $status = New-Object System.Windows.Forms.Label
    $status.Text = "IDLE"
    $status.Location = New-Object System.Drawing.Point(154, 10)
    $status.Size = New-Object System.Drawing.Size(82, 18)
    $status.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $status.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $status.ForeColor = $Colors.Muted
    $status.Font = New-UiFont 7.5 ([System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($status)

    $task = New-Object System.Windows.Forms.Label
    $task.Text = "Job 대기 중"
    $task.Location = New-Object System.Drawing.Point(12, 39)
    $task.Size = New-Object System.Drawing.Size(224, 20)
    $task.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $task.ForeColor = $Colors.Muted
    $task.Font = New-UiFont 7.5
    $card.Controls.Add($task)

    $phase = New-Object System.Windows.Forms.Label
    $phase.Text = "대기"
    $phase.Location = New-Object System.Drawing.Point(12, 63)
    $phase.Size = New-Object System.Drawing.Size(224, 18)
    $phase.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $phase.ForeColor = $Colors.Muted
    $phase.Font = New-UiFont 7 ([System.Drawing.FontStyle]::Regular)
    $card.Controls.Add($phase)

    $progressTrack = New-Object System.Windows.Forms.Panel
    $progressTrack.Location = New-Object System.Drawing.Point(12, 87)
    $progressTrack.Size = New-Object System.Drawing.Size(224, 7)
    $progressTrack.BackColor = $Colors.Soft
    $progressTrack.Tag = 0
    Enable-RoundedControl $progressTrack 4

    $progressFill = New-Object System.Windows.Forms.Panel
    $progressFill.Location = New-Object System.Drawing.Point(0, 0)
    $progressFill.Size = New-Object System.Drawing.Size(0, 7)
    $progressFill.BackColor = $Colors.Accent
    Enable-RoundedControl $progressFill 4
    $progressTrack.Controls.Add($progressFill)
    $card.Controls.Add($progressTrack)

    $cardRef = $card
    $statusRef = $status
    $taskRef = $task
    $phaseRef = $phase
    $trackRef = $progressTrack
    $fillRef = $progressFill
    $resizeWorkerCard = {
        $availableWidth = [Math]::Max(20, $cardRef.ClientSize.Width - 24)
        $statusRef.Left = [Math]::Max(145, $cardRef.ClientSize.Width - $statusRef.Width - 12)
        $taskRef.Width = $availableWidth
        $phaseRef.Width = $availableWidth
        $trackRef.Location = New-Object System.Drawing.Point(12, [Math]::Max(87, $cardRef.ClientSize.Height - 19))
        $trackRef.Width = $availableWidth
        $percent = [Math]::Max(0, [Math]::Min(100, [int]$trackRef.Tag))
        $fillRef.Width = [Math]::Floor($trackRef.ClientSize.Width * $percent / 100)
    }.GetNewClosure()
    $card.Add_SizeChanged($resizeWorkerCard)
    $progressTrack.Add_SizeChanged($resizeWorkerCard)

    $workerLayout.Controls.Add($card, $i - 1, 0)
    & $resizeWorkerCard
    $workerViews += [PSCustomObject]@{
        Id = "worker-$i"
        Card = $card
        Name = $name
        Status = $status
        Task = $task
        Phase = $phase
        ProgressTrack = $progressTrack
        ProgressFill = $progressFill
        ClickTargets = @($card, $name, $status, $task, $phase, $progressTrack, $progressFill)
    }
}

$challengeGroup = New-Object System.Windows.Forms.GroupBox
$challengeGroup.Text = "04   문제 목록"
$challengeGroup.Dock = [System.Windows.Forms.DockStyle]::Fill
$challengeGroup.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$challengeGroup.BackColor = $Colors.Paper
$challengeGroup.ForeColor = $Colors.Ink
$challengeGroup.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Bold)
$challengeGroup.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
Enable-RoundedControl $challengeGroup 4
$mainLayout.Controls.Add($challengeGroup, 0, 3)

$challengeGrid = New-Object System.Windows.Forms.DataGridView
$challengeGrid.Dock = [System.Windows.Forms.DockStyle]::Fill
$challengeGrid.BackgroundColor = $Colors.Paper
$challengeGrid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$challengeGrid.AllowUserToAddRows = $false
$challengeGrid.AllowUserToDeleteRows = $false
$challengeGrid.AllowUserToResizeRows = $false
$challengeGrid.ReadOnly = $true
$challengeGrid.RowHeadersVisible = $false
$challengeGrid.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill
$challengeGrid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
$challengeGrid.MultiSelect = $false
$challengeGrid.EnableHeadersVisualStyles = $false
$challengeGrid.ColumnHeadersDefaultCellStyle.BackColor = $Colors.Soft
$challengeGrid.ColumnHeadersDefaultCellStyle.ForeColor = $Colors.Muted
$challengeGrid.ColumnHeadersDefaultCellStyle.Font = New-UiFont 7.5 ([System.Drawing.FontStyle]::Bold)
$challengeGrid.DefaultCellStyle.Font = New-UiFont 8
$challengeGrid.DefaultCellStyle.SelectionBackColor = $Colors.Selected
$challengeGrid.DefaultCellStyle.SelectionForeColor = $Colors.Ink
$challengeGrid.DefaultCellStyle.BackColor = $Colors.Paper
$challengeGrid.DefaultCellStyle.ForeColor = $Colors.Ink
$challengeGrid.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(4)
$challengeGrid.RowTemplate.Height = 36
$challengeGrid.GridColor = $Colors.Soft
$challengeGrid.Columns.Add("Name", "문제") | Out-Null
$challengeGrid.Columns.Add("Category", "분야") | Out-Null
$challengeGrid.Columns.Add("Points", "점수") | Out-Null
$challengeGrid.Columns.Add("Worker", "Worker") | Out-Null
$challengeGrid.Columns.Add("Status", "상태") | Out-Null
$detailColumn = New-Object System.Windows.Forms.DataGridViewButtonColumn
$detailColumn.Name = "Detail"
$detailColumn.HeaderText = "상세"
$detailColumn.Text = "진행 보기"
$detailColumn.UseColumnTextForButtonValue = $true
$detailColumn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$detailColumn.DefaultCellStyle.BackColor = $Colors.Emphasis
$detailColumn.DefaultCellStyle.ForeColor = $Colors.Accent
$detailColumn.DefaultCellStyle.SelectionBackColor = $Colors.Selected
$challengeGrid.Columns.Add($detailColumn) | Out-Null
$challengeGrid.Columns[0].FillWeight = 220
$challengeGrid.Columns[1].FillWeight = 65
$challengeGrid.Columns[2].FillWeight = 55
$challengeGrid.Columns[3].FillWeight = 75
$challengeGrid.Columns[4].FillWeight = 130
$challengeGrid.Columns[5].FillWeight = 62
$challengeGroup.Controls.Add($challengeGrid)

$eventGroup = New-Object System.Windows.Forms.GroupBox
$eventGroup.Text = "05   실행 기록"
$eventGroup.Dock = [System.Windows.Forms.DockStyle]::Fill
$eventGroup.Margin = New-Object System.Windows.Forms.Padding(0)
$eventGroup.BackColor = $Colors.Paper
$eventGroup.ForeColor = $Colors.Ink
$eventGroup.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Bold)
$eventGroup.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
Enable-RoundedControl $eventGroup 4
$mainLayout.Controls.Add($eventGroup, 0, 4)

$eventLog = New-Object System.Windows.Forms.RichTextBox
$eventLog.Dock = [System.Windows.Forms.DockStyle]::Fill
$eventLog.ReadOnly = $true
$eventLog.BackColor = $Colors.Log
$eventLog.ForeColor = $Colors.ButtonText
$eventLog.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$eventLog.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Regular)
$eventLog.WordWrap = $false
$eventGroup.Controls.Add($eventLog)

function Get-OptionalPropertyValue {
    param(
        [object]$InputObject,
        [Parameter(Mandatory = $true)][string]$Name
    )
    if ($null -eq $InputObject) { return $null }
    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property) { return $null }
    return $property.Value
}

function Show-ChallengeProgress {
    param([Parameter(Mandatory = $true)][string]$ChallengeId)

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "문제별 Worker 진행상황"
    $dialog.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $dialog.Size = New-Object System.Drawing.Size(820, 560)
    $dialog.MinimumSize = New-Object System.Drawing.Size(680, 460)
    $dialog.BackColor = $Colors.Canvas
    $dialog.Font = New-UiFont 9

    $header = New-Object System.Windows.Forms.Label
    $header.Dock = [System.Windows.Forms.DockStyle]::Top
    $header.Height = 76
    $header.Padding = New-Object System.Windows.Forms.Padding(18, 13, 18, 8)
    $header.BackColor = $Colors.Paper
    $header.ForeColor = $Colors.Ink
    $header.Font = New-DisplayFont 10 ([System.Drawing.FontStyle]::Bold)
    $dialog.Controls.Add($header)

    $hint = New-Object System.Windows.Forms.Label
    $hint.Dock = [System.Windows.Forms.DockStyle]::Top
    $hint.Height = 31
    $hint.Padding = New-Object System.Windows.Forms.Padding(16, 7, 10, 4)
    $hint.BackColor = $Colors.Paper
    $hint.ForeColor = $Colors.Muted
    $hint.Text = "이 문제의 배정·CHECKPOINT·COMPLETED·FAILED·제출 기록만 표시합니다."
    $dialog.Controls.Add($hint)

    $detailLog = New-Object System.Windows.Forms.RichTextBox
    $detailLog.Dock = [System.Windows.Forms.DockStyle]::Fill
    $detailLog.ReadOnly = $true
    $detailLog.BackColor = $Colors.Log
    $detailLog.ForeColor = $Colors.ButtonText
    $detailLog.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $detailLog.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Regular)
    $detailLog.WordWrap = $false
    $dialog.Controls.Add($detailLog)
    $detailLog.BringToFront()

    $script:ChallengeDetailSignature = $null
    $refreshDetail = {
        try {
            $detailState = Invoke-HarnessApi -Path "/api/state" -TimeoutSec 2
            $challenge = @($detailState.challenges | Where-Object { [string]$_.id -eq $ChallengeId } | Select-Object -First 1)
            if ($challenge.Count -eq 0) {
                $header.Text = "문제를 찾을 수 없습니다."
                $detailLog.Text = "현재 문제 목록에서 $ChallengeId 항목을 찾지 못했습니다."
                return
            }

            $item = $challenge[0]
            $workerText = $(if ($item.workerId) { [string]$item.workerId } else { "배정 대기" })
            $header.Text = "$($item.name)  ·  $(([string]$item.category).ToUpperInvariant())`r`n$workerText  ·  $($item.status)  ·  $($item.progress)%  ·  $($item.phase)"

            $challengeEvents = @($detailState.events | Where-Object {
                [string](Get-OptionalPropertyValue -InputObject $_ -Name "challengeId") -eq $ChallengeId
            } | Sort-Object { [DateTime]$_.time })
            $signature = [string]::Join("|", @($challengeEvents | ForEach-Object { [string]$_.id }))
            if ($signature -eq $script:ChallengeDetailSignature) { return }
            $script:ChallengeDetailSignature = $signature

            $lines = New-Object System.Collections.Generic.List[string]
            if ($challengeEvents.Count -eq 0) {
                $lines.Add("아직 이 문제의 Worker 진행 기록이 없습니다.")
            }
            else {
                foreach ($event in $challengeEvents) {
                    $timestamp = ([DateTime]$event.time).ToLocalTime().ToString("HH:mm:ss")
                    $lines.Add("$timestamp  [$(([string]$event.type).ToUpperInvariant())]  $($event.message)")
                }
            }
            $detailLog.Lines = $lines.ToArray()
            $detailLog.SelectionStart = $detailLog.TextLength
            $detailLog.ScrollToCaret()
        }
        catch {
            $detailLog.Text = "진행상황을 불러오지 못했습니다.`r`n$($_.Exception.Message)"
        }
    }

    $detailTimer = New-Object System.Windows.Forms.Timer
    $detailTimer.Interval = 700
    $detailTimer.Add_Tick($refreshDetail)
    $dialog.Add_Shown({
        & $refreshDetail
        $detailTimer.Start()
    })
    $dialog.Add_FormClosed({
        $detailTimer.Stop()
        $detailTimer.Dispose()
        $script:ChallengeDetailSignature = $null
    })
    $dialog.ShowDialog($form) | Out-Null
}

function Show-WorkerProgress {
    param([Parameter(Mandatory = $true)][string]$WorkerId)

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "Worker 진행상황"
    $dialog.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $dialog.Size = New-Object System.Drawing.Size(820, 560)
    $dialog.MinimumSize = New-Object System.Drawing.Size(680, 460)
    $dialog.BackColor = $Colors.Canvas
    $dialog.Font = New-UiFont 9

    $header = New-Object System.Windows.Forms.Label
    $header.Dock = [System.Windows.Forms.DockStyle]::Top
    $header.Height = 76
    $header.Padding = New-Object System.Windows.Forms.Padding(18, 13, 18, 8)
    $header.BackColor = $Colors.Paper
    $header.ForeColor = $Colors.Ink
    $header.Font = New-DisplayFont 10 ([System.Drawing.FontStyle]::Bold)
    $dialog.Controls.Add($header)

    $hint = New-Object System.Windows.Forms.Label
    $hint.Dock = [System.Windows.Forms.DockStyle]::Top
    $hint.Height = 31
    $hint.Padding = New-Object System.Windows.Forms.Padding(16, 7, 10, 4)
    $hint.BackColor = $Colors.Paper
    $hint.ForeColor = $Colors.Muted
    $hint.Text = "이 Worker가 맡은 문제의 배정·CHECKPOINT·COMPLETED·FAILED·제출 기록을 표시합니다."
    $dialog.Controls.Add($hint)

    $detailLog = New-Object System.Windows.Forms.RichTextBox
    $detailLog.Dock = [System.Windows.Forms.DockStyle]::Fill
    $detailLog.ReadOnly = $true
    $detailLog.BackColor = $Colors.Log
    $detailLog.ForeColor = $Colors.ButtonText
    $detailLog.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $detailLog.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Regular)
    $detailLog.WordWrap = $false
    $dialog.Controls.Add($detailLog)
    $detailLog.BringToFront()

    $script:WorkerDetailSignature = $null
    $refreshWorkerDetail = {
        try {
            $detailState = Invoke-HarnessApi -Path "/api/state" -TimeoutSec 2
            $workers = @($detailState.workers | Where-Object { [string]$_.id -eq $WorkerId } | Select-Object -First 1)
            if ($workers.Count -eq 0) {
                $header.Text = "Worker를 찾을 수 없습니다."
                $detailLog.Text = "현재 Worker 목록에서 $WorkerId 항목을 찾지 못했습니다."
                return
            }

            $worker = $workers[0]
            $currentTask = $(if ($worker.challengeName) { [string]$worker.challengeName } else { "현재 배정된 문제 없음" })
            $header.Text = "$($worker.name)  ·  $(([string]$worker.status).ToUpperInvariant())`r`n$currentTask  ·  $($worker.phase)  ·  완료 $($worker.completed)개"

            $workerEvents = @($detailState.events | Where-Object {
                [string](Get-OptionalPropertyValue -InputObject $_ -Name "workerId") -eq $WorkerId
            } | Sort-Object { [DateTime]$_.time })
            $signature = [string]::Join("|", @($workerEvents | ForEach-Object { [string]$_.id }))
            if ($signature -eq $script:WorkerDetailSignature) { return }
            $script:WorkerDetailSignature = $signature

            $lines = New-Object System.Collections.Generic.List[string]
            if ($workerEvents.Count -eq 0) {
                $lines.Add("아직 이 Worker의 진행 기록이 없습니다.")
            }
            else {
                foreach ($event in $workerEvents) {
                    $timestamp = ([DateTime]$event.time).ToLocalTime().ToString("HH:mm:ss")
                    $eventChallengeId = [string](Get-OptionalPropertyValue -InputObject $event -Name "challengeId")
                    $challengePrefix = $(if ([string]::IsNullOrWhiteSpace($eventChallengeId)) { "" } else { "$eventChallengeId  " })
                    $lines.Add("$timestamp  [$(([string]$event.type).ToUpperInvariant())]  $challengePrefix$($event.message)")
                }
            }
            $detailLog.Lines = $lines.ToArray()
            $detailLog.SelectionStart = $detailLog.TextLength
            $detailLog.ScrollToCaret()
        }
        catch {
            $detailLog.Text = "진행상황을 불러오지 못했습니다.`r`n$($_.Exception.Message)"
        }
    }

    $detailTimer = New-Object System.Windows.Forms.Timer
    $detailTimer.Interval = 700
    $detailTimer.Add_Tick($refreshWorkerDetail)
    $dialog.Add_Shown({
        & $refreshWorkerDetail
        $detailTimer.Start()
    })
    $dialog.Add_FormClosed({
        $detailTimer.Stop()
        $detailTimer.Dispose()
        $script:WorkerDetailSignature = $null
    })
    $dialog.ShowDialog($form) | Out-Null
}

foreach ($view in $workerViews) {
    $workerIdForClick = [string]$view.Id
    $cardClickHandler = { Show-WorkerProgress -WorkerId $workerIdForClick }.GetNewClosure()
    foreach ($clickTarget in $view.ClickTargets) {
        $clickTarget.Cursor = [System.Windows.Forms.Cursors]::Hand
        $clickTarget.Add_Click($cardClickHandler)
    }
}

function Update-DesktopState {
    param([object]$State)
    if ($null -eq $State) { return }
    $script:CurrentState = $State

    $connected = [bool]$State.connection.connected
    $running = $State.run.status -eq "running"
    if ($connected) {
        $connectionLabel.Text = "●  $($State.connection.label) · 연결됨"
        $connectionLabel.ForeColor = $Colors.Green
    }
    else {
        $connectionLabel.Text = "연결 전"
        $connectionLabel.ForeColor = $Colors.Muted
    }

    $runStateLabel.Text = [string]$State.run.status.ToUpperInvariant()
    switch ([string]$State.run.status) {
        "completed" { $runStateLabel.ForeColor = $Colors.Green }
        "failed" { $runStateLabel.ForeColor = $Colors.Red }
        "stopped" { $runStateLabel.ForeColor = $Colors.Amber }
        default { $runStateLabel.ForeColor = $Colors.Accent }
    }
    $runMessage.Text = [string]$State.run.message
    $runProgressValue = [Math]::Max(0, [Math]::Min(100, [int]$State.run.progress))
    $runProgressTrack.Tag = $runProgressValue
    $runProgressFill.Width = [Math]::Floor($runProgressTrack.ClientSize.Width * $runProgressValue / 100)
    $runButton.Enabled = $connected -and -not $running
    $stopButton.Enabled = $running
    $connectButton.Enabled = -not $running

    $challenges = @($State.challenges)
    $workers = @($State.workers)
    $activeCount = @($workers | Where-Object { $_.status -eq "running" }).Count
    $metricTotal.Value.Text = [string]$(if ([int]$State.run.total -gt 0) { $State.run.total } else { $challenges.Count })
    $metricSolved.Value.Text = [string]$State.run.solved
    $metricWorkers.Value.Text = "$activeCount/$($State.config.workerLimit)"
    $metricProgress.Value.Text = "$($State.run.progress)%"
    $metricProgress.Subtitle.Text = [string]$State.run.status.ToUpperInvariant()

    for ($index = 0; $index -lt 3; $index++) {
        $view = $workerViews[$index]
        $worker = $workers[$index]
        $view.Status.Text = [string]$worker.status.ToUpperInvariant()
        $view.Task.Text = $(if ($worker.challengeName) { [string]$worker.challengeName } elseif ($worker.enabled) { "Job 대기 중" } else { "Concurrency 제한" })
        $profile = $(if ($worker.profile) { [string]$worker.profile.ToUpperInvariant() } else { "NONE" })
        $view.Phase.Text = "$profile · $($worker.phase) · DONE $($worker.completed)"
        $workerProgress = [Math]::Max(0, [Math]::Min(100, [int]$worker.progress))
        $view.ProgressTrack.Tag = $workerProgress
        $view.ProgressFill.Width = [Math]::Floor($view.ProgressTrack.ClientSize.Width * $workerProgress / 100)
        if ($worker.status -eq "running") {
            $view.Name.ForeColor = $Colors.Accent
            $view.Card.BackColor = $Colors.Emphasis
        }
        elseif (-not $worker.enabled) {
            $view.Name.ForeColor = $Colors.Muted
            $view.Card.BackColor = $Colors.Selected
        }
        else {
            $view.Name.ForeColor = $Colors.Ink
            $view.Card.BackColor = $Colors.Paper
        }
    }

    $challengeGrid.Rows.Clear()
    foreach ($challenge in $challenges) {
        $workerId = $(if ($challenge.workerId) { [string]$challenge.workerId } else { "—" })
        $statusText = "$($challenge.status) · $($challenge.phase)"
        $rowIndex = $challengeGrid.Rows.Add($challenge.name, ([string]$challenge.category).ToUpperInvariant(), $challenge.points, $workerId, $statusText)
        $row = $challengeGrid.Rows[$rowIndex]
        $row.Tag = [string]$challenge.id
        if ($challenge.status -eq "solved") {
            $row.Cells[4].Style.ForeColor = $Colors.Green
        }
        elseif ($challenge.status -eq "failed") {
            $row.Cells[4].Style.ForeColor = $Colors.Red
        }
        elseif ($challenge.status -eq "needs_tooling") {
            $row.Cells[4].Style.ForeColor = $Colors.Amber
        }
    }

    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($event in @($State.events) | Select-Object -First 80) {
        $timestamp = ([DateTime]$event.time).ToLocalTime().ToString("HH:mm:ss")
        $lines.Add("$timestamp  [$(([string]$event.type).ToUpperInvariant())]  $($event.message)")
    }
    $eventLog.Lines = $lines.ToArray()

    $codexAvailable = [bool]$State.environment.codexSdkAvailable
    if ($modeCombo.SelectedIndex -eq 1) {
        $codexCheck.Enabled = $codexAvailable
    }
    else {
        $codexCheck.Enabled = $false
    }
    $apiStatus.Text = "●  LOCAL API · NODE $($State.environment.nodeVersion)"
    $apiStatus.ForeColor = $Colors.Green
    $apiStatus.BackColor = $Colors.Soft
}

$challengeGrid.Add_CellContentClick({
    param($sender, $eventArgs)
    if ($eventArgs.RowIndex -lt 0 -or $eventArgs.ColumnIndex -lt 0) { return }
    if ($sender.Columns[$eventArgs.ColumnIndex].Name -ne "Detail") { return }
    $challengeId = [string]$sender.Rows[$eventArgs.RowIndex].Tag
    if (-not [string]::IsNullOrWhiteSpace($challengeId)) {
        Show-ChallengeProgress -ChallengeId $challengeId
    }
})

function Get-SelectedCategories {
    $categories = New-Object System.Collections.Generic.List[string]
    if ($pwnCheck.Checked) { $categories.Add("pwn") }
    if ($revCheck.Checked) { $categories.Add("rev") }
    if ($webCheck.Checked) { $categories.Add("web") }
    return $categories.ToArray()
}

$modeCombo.Add_SelectedIndexChanged({
    $ctfdMode = $modeCombo.SelectedIndex -eq 1
    $urlText.Enabled = $ctfdMode
    $tokenText.Enabled = $ctfdMode
    $autoSubmitCheck.Enabled = $ctfdMode
    $authorizedCheck.Enabled = $ctfdMode
    if ($ctfdMode -and $null -ne $script:CurrentState) {
        $codexCheck.Enabled = [bool]$script:CurrentState.environment.codexSdkAvailable
    }
    else {
        $codexCheck.Checked = $false
        $codexCheck.Enabled = $false
    }
})

$connectButton.Add_Click({
    try {
        $connectButton.Enabled = $false
        $connectButton.Text = "확인 중..."
        [System.Windows.Forms.Application]::DoEvents()
        $ctfdMode = $modeCombo.SelectedIndex -eq 1
        $payload = @{
            mode = $(if ($ctfdMode) { "ctfd" } else { "demo" })
            workerLimit = [int]$workerCount.Value
            categories = @(Get-SelectedCategories)
            baseUrl = $urlText.Text.Trim()
            apiToken = $tokenText.Text
            useCodex = [bool]$codexCheck.Checked
            autoSubmit = [bool]$autoSubmitCheck.Checked
            authorized = $(if ($ctfdMode) { [bool]$authorizedCheck.Checked } else { $true })
        }
        $state = Invoke-HarnessApi -Path "/api/connect" -Method "POST" -Body $payload -TimeoutSec 10
        $tokenText.Clear()
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
    finally {
        $connectButton.Text = "문제 불러오기"
        if ($null -ne $script:CurrentState -and $script:CurrentState.run.status -ne "running") {
            $connectButton.Enabled = $true
        }
    }
})

$runButton.Add_Click({
    try {
        $state = Invoke-HarnessApi -Path "/api/run" -Method "POST" -Body @{}
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
})

$stopButton.Add_Click({
    try {
        $state = Invoke-HarnessApi -Path "/api/stop" -Method "POST" -Body @{}
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
})

$resetButton.Add_Click({
    try {
        $state = Invoke-HarnessApi -Path "/api/reset" -Method "POST" -Body @{}
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
})

$exportButton.Add_Click({
    if ($null -eq $script:CurrentState) { return }
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title = "공개 Harness 상태 저장"
    $dialog.Filter = "JSON report (*.json)|*.json"
    $runId = $(if ($script:CurrentState.run.id) { $script:CurrentState.run.id } else { "idle" })
    $dialog.FileName = "harness-report-$runId.json"
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $script:CurrentState | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $dialog.FileName -Encoding UTF8
    }
})

$closeButton.Add_Click({ $form.Close() })
$minimizeButton.Add_Click({ $form.WindowState = [System.Windows.Forms.FormWindowState]::Minimized })
$toggleWindowState = {
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Maximized) {
        $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    }
    else {
        $form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
    }
}.GetNewClosure()
$maximizeButton.Add_Click($toggleWindowState)
$windowBar.Add_DoubleClick($toggleWindowState)
$windowTitle.Add_DoubleClick($toggleWindowState)

$script:WindowDragActive = $false
$script:WindowDragOffset = New-Object System.Drawing.Point(0, 0)
$beginWindowDrag = {
    param($sender, $eventArgs)
    if ($eventArgs.Button -ne [System.Windows.Forms.MouseButtons]::Left) { return }
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Maximized) { return }
    $script:WindowDragActive = $true
    $script:WindowDragOffset = New-Object System.Drawing.Point(
        ([System.Windows.Forms.Cursor]::Position.X - $form.Left),
        ([System.Windows.Forms.Cursor]::Position.Y - $form.Top)
    )
}
$moveWindow = {
    if (-not $script:WindowDragActive) { return }
    $form.Location = New-Object System.Drawing.Point(
        ([System.Windows.Forms.Cursor]::Position.X - $script:WindowDragOffset.X),
        ([System.Windows.Forms.Cursor]::Position.Y - $script:WindowDragOffset.Y)
    )
}
$endWindowDrag = { $script:WindowDragActive = $false }
foreach ($dragSurface in @($windowBar, $windowTitle)) {
    $dragSurface.Add_MouseDown($beginWindowDrag)
    $dragSurface.Add_MouseMove($moveWindow)
    $dragSurface.Add_MouseUp($endWindowDrag)
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 700
$timer.Add_Tick({
    if ($script:Refreshing) { return }
    $script:Refreshing = $true
    try {
        $state = Invoke-HarnessApi -Path "/api/state" -TimeoutSec 2
        Update-DesktopState $state
        $apiStatus.ForeColor = $Colors.Green
        $apiStatus.BackColor = $Colors.Soft
    }
    catch {
        $apiStatus.Text = "●  LOCAL API OFFLINE"
        $apiStatus.ForeColor = $Colors.Red
        $apiStatus.BackColor = $Colors.Soft
    }
    finally {
        $script:Refreshing = $false
    }
})

$form.Add_Resize({
    $apiStatus.Left = [Math]::Max(720, $header.ClientSize.Width - $apiStatus.Width - 24)
})

$form.Add_FormClosing({
    $timer.Stop()
    if ($null -ne $script:OwnedServer) {
        try { Invoke-HarnessApi -Path "/api/stop" -Method "POST" -Body @{} -TimeoutSec 1 | Out-Null } catch {}
        Stop-OwnedServer
    }
})

$form.Add_KeyDown({
    param($sender, $eventArgs)
    if ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::F5) {
        try { Update-DesktopState (Invoke-HarnessApi -Path "/api/state") } catch { Show-AppError $_.Exception.Message }
    }
})

Update-DesktopState $script:CurrentState
if ($UiSmokeTest) {
    try {
        $form.CreateControl()
        $form.PerformLayout()
        $bodyPanel.PerformLayout()
        $mainLayout.PerformLayout()
        & $positionWindowControls
        if (-not ($minimizeButton.Left -lt $maximizeButton.Left -and $maximizeButton.Left -lt $closeButton.Left)) {
            throw "창 제어 버튼의 오른쪽 정렬 순서가 올바르지 않습니다."
        }
        if ([Math]::Abs($windowBar.ClientSize.Width - $closeButton.Right - 14) -gt 1) {
            throw "닫기 버튼이 창 오른쪽 여백에 맞지 않습니다."
        }
        $eventWithoutChallenge = [PSCustomObject]@{ type = "system"; message = "startup" }
        if ($null -ne (Get-OptionalPropertyValue -InputObject $eventWithoutChallenge -Name "challengeId")) {
            throw "선택 속성 처리기가 challengeId 없는 이벤트를 안전하게 처리하지 못했습니다."
        }
        foreach ($view in $workerViews) {
            if ($view.ProgressFill.Width -lt 0 -or $view.ProgressFill.Width -gt $view.ProgressTrack.ClientSize.Width) {
                throw "$($view.Id) 게이지가 카드 경계를 벗어났습니다."
            }
        }
        [ordered]@{
            ui = "ok"
            font = $script:UiFontName
            fontSource = $script:FontSource
            displayFont = $script:DisplayFontName
            windowStyle = "Thumbprint + Indigo palette"
            programName = $windowTitle.Text
            windowControls = 3
            windowControlsAligned = "right"
            flatCards = 4
            clickableWorkers = $workerViews.Count
            boundedWorkerGauges = $workerViews.Count
        } | ConvertTo-Json
    }
    finally {
        $form.Dispose()
        $script:PrivateFonts.Dispose()
        Stop-OwnedServer
    }
    exit 0
}
$timer.Start()
try {
    [System.Windows.Forms.Application]::Run($form)
}
finally {
    $form.Dispose()
    $script:PrivateFonts.Dispose()
}
