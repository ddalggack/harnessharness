﻿param(
    [switch]$SelfTest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ApiBase = "http://127.0.0.1:8788"
$script:OwnedServer = $null
$script:CurrentState = $null
$script:Refreshing = $false

function Invoke-HarnessApi {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [ValidateSet("GET", "POST")][string]$Method = "GET",
        [object]$Body = $null,
        [int]$TimeoutSec = 6
    )

    $parameters = @{
        Uri = "$ApiBase$Path"
        Method = $Method
        TimeoutSec = $TimeoutSec
        UseBasicParsing = $true
    }
    if ($null -ne $Body) {
        $json = $Body | ConvertTo-Json -Depth 10 -Compress
        $parameters.ContentType = "application/json; charset=utf-8"
        $parameters.Body = [System.Text.Encoding]::UTF8.GetBytes($json)
    }
    return Invoke-RestMethod @parameters
}

function Test-HarnessApi {
    try {
        $health = Invoke-HarnessApi -Path "/api/health" -TimeoutSec 1
        return [bool]$health.ok
    }
    catch {
        return $false
    }
}

function Ensure-HarnessApi {
    if (Test-HarnessApi) {
        return
    }

    $nodeCommand = Get-Command "node.exe" -ErrorAction SilentlyContinue
    if ($null -eq $nodeCommand) {
        throw "기존 Node.js 실행 파일을 찾지 못했습니다. 이 프로그램은 Node.js를 설치하거나 업데이트하지 않습니다."
    }

    $script:OwnedServer = Start-Process `
        -FilePath $nodeCommand.Source `
        -ArgumentList @("server\index.cjs") `
        -WorkingDirectory $ProjectRoot `
        -WindowStyle Hidden `
        -PassThru

    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Milliseconds 150
        if (Test-HarnessApi) {
            return
        }
        if ($script:OwnedServer.HasExited) {
            break
        }
    }
    throw "Harness API를 시작하지 못했습니다. server/index.cjs 실행 상태를 확인하세요."
}

function Stop-OwnedServer {
    if ($null -eq $script:OwnedServer) {
        return
    }
    try {
        $process = Get-Process -Id $script:OwnedServer.Id -ErrorAction SilentlyContinue
        if ($null -ne $process -and $process.ProcessName -eq "node") {
            Stop-Process -Id $process.Id -Force
        }
    }
    catch {
        # The process may already be gone. Never stop a process we did not launch.
    }
    $script:OwnedServer = $null
}

if ($SelfTest) {
    try {
        Ensure-HarnessApi
        $payload = @{
            mode = "demo"
            workerLimit = 3
            categories = @("pwn", "rev", "web")
            autoSubmit = $true
            authorized = $true
        }
        $connected = Invoke-HarnessApi -Path "/api/connect" -Method "POST" -Body $payload
        $summary = [ordered]@{
            desktopApi = "ok"
            mode = $connected.connection.mode
            challenges = @($connected.challenges).Count
            workerLimit = $connected.config.workerLimit
            systemNode = $connected.environment.nodeVersion
        }
        $summary | ConvertTo-Json
        exit 0
    }
    catch {
        [Console]::Error.WriteLine($_.Exception.Message)
        exit 1
    }
    finally {
        Stop-OwnedServer
    }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

function New-UiFont {
    param([float]$Size = 9, [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular)
    return New-Object System.Drawing.Font("Segoe UI", $Size, $Style)
}

function New-Color {
    param([string]$Hex)
    return [System.Drawing.ColorTranslator]::FromHtml($Hex)
}

$Colors = @{
    Ink = New-Color "#10243D"
    Muted = New-Color "#68758A"
    Canvas = New-Color "#F1F4F2"
    Paper = New-Color "#FFFFFF"
    Navy = New-Color "#0C2038"
    Navy2 = New-Color "#15324F"
    Accent = New-Color "#FF6B3D"
    Green = New-Color "#19A773"
    Amber = New-Color "#D98D15"
    Red = New-Color "#D64D52"
    Line = New-Color "#DCE2DF"
    Soft = New-Color "#EBEFED"
    Log = New-Color "#0D1D2D"
}

function Set-FlatButtonStyle {
    param(
        [System.Windows.Forms.Button]$Button,
        [System.Drawing.Color]$BackColor,
        [System.Drawing.Color]$ForeColor,
        [int]$Height = 42
    )
    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 0
    $Button.BackColor = $BackColor
    $Button.ForeColor = $ForeColor
    $Button.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Bold)
    $Button.Height = $Height
    $Button.Cursor = [System.Windows.Forms.Cursors]::Hand
}

function Show-AppError {
    param([string]$Message)
    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        "CTF Run Harness",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

try {
    Ensure-HarnessApi
    $script:CurrentState = Invoke-HarnessApi -Path "/api/state"
}
catch {
    Show-AppError $_.Exception.Message
    Stop-OwnedServer
    exit 1
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "CTF Run Harness · Desktop Console"
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$form.Size = New-Object System.Drawing.Size(1220, 820)
$form.MinimumSize = New-Object System.Drawing.Size(1040, 720)
$form.BackColor = $Colors.Canvas
$form.Font = New-UiFont 9
$form.KeyPreview = $true

$header = New-Object System.Windows.Forms.Panel
$header.Dock = [System.Windows.Forms.DockStyle]::Top
$header.Height = 72
$header.BackColor = $Colors.Navy

$brandBox = New-Object System.Windows.Forms.Label
$brandBox.Text = "H"
$brandBox.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$brandBox.Location = New-Object System.Drawing.Point(24, 14)
$brandBox.Size = New-Object System.Drawing.Size(44, 44)
$brandBox.ForeColor = $Colors.Paper
$brandBox.BackColor = $Colors.Navy2
$brandBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$brandBox.Font = New-UiFont 14 ([System.Drawing.FontStyle]::Bold)
$header.Controls.Add($brandBox)

$brandTitle = New-Object System.Windows.Forms.Label
$brandTitle.Text = "CTF Run Harness"
$brandTitle.ForeColor = $Colors.Paper
$brandTitle.Location = New-Object System.Drawing.Point(82, 17)
$brandTitle.AutoSize = $true
$brandTitle.Font = New-UiFont 14 ([System.Drawing.FontStyle]::Bold)
$header.Controls.Add($brandTitle)

$brandSub = New-Object System.Windows.Forms.Label
$brandSub.Text = "AUTHORIZED LOCAL CTF · NATIVE DESKTOP CONSOLE"
$brandSub.ForeColor = New-Color "#9EB1C3"
$brandSub.Location = New-Object System.Drawing.Point(84, 43)
$brandSub.AutoSize = $true
$brandSub.Font = New-Object System.Drawing.Font("Consolas", 7.5, [System.Drawing.FontStyle]::Bold)
$header.Controls.Add($brandSub)

$apiStatus = New-Object System.Windows.Forms.Label
$apiStatus.Text = "●  LOCAL API ONLINE"
$apiStatus.ForeColor = New-Color "#5BD3A5"
$apiStatus.AutoSize = $true
$apiStatus.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
$apiStatus.Location = New-Object System.Drawing.Point(1010, 28)
$apiStatus.Font = New-Object System.Drawing.Font("Consolas", 8, [System.Drawing.FontStyle]::Bold)
$header.Controls.Add($apiStatus)

$bodyPanel = New-Object System.Windows.Forms.Panel
$bodyPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$bodyPanel.BackColor = $Colors.Canvas

$sidebar = New-Object System.Windows.Forms.Panel
$sidebar.Dock = [System.Windows.Forms.DockStyle]::Left
$sidebar.Width = 292
$sidebar.Padding = New-Object System.Windows.Forms.Padding(20)
$sidebar.BackColor = New-Color "#F8FAF9"
$sidebar.AutoScroll = $true

$mainPanel = New-Object System.Windows.Forms.Panel
$mainPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$mainPanel.Padding = New-Object System.Windows.Forms.Padding(18)
$mainPanel.BackColor = $Colors.Canvas

$bodyPanel.Controls.Add($mainPanel)
$bodyPanel.Controls.Add($sidebar)
$form.Controls.Add($bodyPanel)
$form.Controls.Add($header)

$controlTitle = New-Object System.Windows.Forms.Label
$controlTitle.Text = "01   대상 연결"
$controlTitle.Location = New-Object System.Drawing.Point(20, 20)
$controlTitle.Size = New-Object System.Drawing.Size(235, 26)
$controlTitle.ForeColor = $Colors.Ink
$controlTitle.Font = New-UiFont 11 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($controlTitle)

$connectionLabel = New-Object System.Windows.Forms.Label
$connectionLabel.Text = "연결 전"
$connectionLabel.Location = New-Object System.Drawing.Point(20, 49)
$connectionLabel.Size = New-Object System.Drawing.Size(235, 22)
$connectionLabel.ForeColor = $Colors.Muted
$connectionLabel.Font = New-UiFont 8
$sidebar.Controls.Add($connectionLabel)

$modeLabel = New-Object System.Windows.Forms.Label
$modeLabel.Text = "실행 모드"
$modeLabel.Location = New-Object System.Drawing.Point(20, 82)
$modeLabel.AutoSize = $true
$modeLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($modeLabel)

$modeCombo = New-Object System.Windows.Forms.ComboBox
$modeCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$modeCombo.Items.AddRange(@("안전 Demo", "로컬 CTFd"))
$modeCombo.SelectedIndex = 0
$modeCombo.Location = New-Object System.Drawing.Point(20, 103)
$modeCombo.Size = New-Object System.Drawing.Size(235, 28)
$sidebar.Controls.Add($modeCombo)

$urlLabel = New-Object System.Windows.Forms.Label
$urlLabel.Text = "CTFd URL"
$urlLabel.Location = New-Object System.Drawing.Point(20, 143)
$urlLabel.AutoSize = $true
$urlLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($urlLabel)

$urlText = New-Object System.Windows.Forms.TextBox
$urlText.Location = New-Object System.Drawing.Point(20, 164)
$urlText.Size = New-Object System.Drawing.Size(235, 24)
$urlText.Text = "http://127.0.0.1:8000"
$urlText.Enabled = $false
$sidebar.Controls.Add($urlText)

$tokenLabel = New-Object System.Windows.Forms.Label
$tokenLabel.Text = "API Token · 메모리에만 보관"
$tokenLabel.Location = New-Object System.Drawing.Point(20, 199)
$tokenLabel.AutoSize = $true
$tokenLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($tokenLabel)

$tokenText = New-Object System.Windows.Forms.TextBox
$tokenText.Location = New-Object System.Drawing.Point(20, 220)
$tokenText.Size = New-Object System.Drawing.Size(235, 24)
$tokenText.UseSystemPasswordChar = $true
$tokenText.Enabled = $false
$sidebar.Controls.Add($tokenText)

$categoryLabel = New-Object System.Windows.Forms.Label
$categoryLabel.Text = "문제 분야"
$categoryLabel.Location = New-Object System.Drawing.Point(20, 258)
$categoryLabel.AutoSize = $true
$categoryLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($categoryLabel)

$pwnCheck = New-Object System.Windows.Forms.CheckBox
$pwnCheck.Text = "PWN"
$pwnCheck.Checked = $true
$pwnCheck.Location = New-Object System.Drawing.Point(20, 280)
$pwnCheck.Size = New-Object System.Drawing.Size(67, 25)
$sidebar.Controls.Add($pwnCheck)

$revCheck = New-Object System.Windows.Forms.CheckBox
$revCheck.Text = "REV"
$revCheck.Checked = $true
$revCheck.Location = New-Object System.Drawing.Point(94, 280)
$revCheck.Size = New-Object System.Drawing.Size(67, 25)
$sidebar.Controls.Add($revCheck)

$webCheck = New-Object System.Windows.Forms.CheckBox
$webCheck.Text = "WEB"
$webCheck.Checked = $true
$webCheck.Location = New-Object System.Drawing.Point(171, 280)
$webCheck.Size = New-Object System.Drawing.Size(67, 25)
$sidebar.Controls.Add($webCheck)

$workerLabel = New-Object System.Windows.Forms.Label
$workerLabel.Text = "동시 Worker · 최대 3"
$workerLabel.Location = New-Object System.Drawing.Point(20, 316)
$workerLabel.AutoSize = $true
$workerLabel.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$sidebar.Controls.Add($workerLabel)

$workerCount = New-Object System.Windows.Forms.NumericUpDown
$workerCount.Location = New-Object System.Drawing.Point(20, 338)
$workerCount.Size = New-Object System.Drawing.Size(235, 25)
$workerCount.Minimum = 1
$workerCount.Maximum = 3
$workerCount.Value = 3
$workerCount.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center
$sidebar.Controls.Add($workerCount)

$codexCheck = New-Object System.Windows.Forms.CheckBox
$codexCheck.Text = "Main Codex SDK 사용"
$codexCheck.Location = New-Object System.Drawing.Point(20, 378)
$codexCheck.Size = New-Object System.Drawing.Size(235, 24)
$codexCheck.Enabled = $false
$sidebar.Controls.Add($codexCheck)

$autoSubmitCheck = New-Object System.Windows.Forms.CheckBox
$autoSubmitCheck.Text = "Submission Broker 자동 제출"
$autoSubmitCheck.Checked = $true
$autoSubmitCheck.Location = New-Object System.Drawing.Point(20, 405)
$autoSubmitCheck.Size = New-Object System.Drawing.Size(235, 24)
$autoSubmitCheck.Enabled = $false
$sidebar.Controls.Add($autoSubmitCheck)

$authorizedCheck = New-Object System.Windows.Forms.CheckBox
$authorizedCheck.Text = "허가된 로컬 CTFd입니다"
$authorizedCheck.Location = New-Object System.Drawing.Point(20, 432)
$authorizedCheck.Size = New-Object System.Drawing.Size(235, 24)
$authorizedCheck.Enabled = $false
$sidebar.Controls.Add($authorizedCheck)

$connectButton = New-Object System.Windows.Forms.Button
$connectButton.Text = "환경 확인"
$connectButton.Location = New-Object System.Drawing.Point(20, 474)
$connectButton.Size = New-Object System.Drawing.Size(235, 44)
Set-FlatButtonStyle $connectButton $Colors.Navy2 $Colors.Paper 44
$sidebar.Controls.Add($connectButton)

$safeBox = New-Object System.Windows.Forms.Panel
$safeBox.Location = New-Object System.Drawing.Point(20, 532)
$safeBox.Size = New-Object System.Drawing.Size(235, 74)
$safeBox.BackColor = $Colors.Paper
$safeBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$sidebar.Controls.Add($safeBox)

$safeTitle = New-Object System.Windows.Forms.Label
$safeTitle.Text = "✓  로컬 전용 안전장치"
$safeTitle.Location = New-Object System.Drawing.Point(10, 9)
$safeTitle.AutoSize = $true
$safeTitle.ForeColor = $Colors.Green
$safeTitle.Font = New-UiFont 8 ([System.Drawing.FontStyle]::Bold)
$safeBox.Controls.Add($safeTitle)

$safeText = New-Object System.Windows.Forms.Label
$safeText.Text = "공인 인터넷 CTF 주소와 허가되지 않은`r`n대상은 API 단계에서 차단합니다."
$safeText.Location = New-Object System.Drawing.Point(10, 31)
$safeText.Size = New-Object System.Drawing.Size(210, 34)
$safeText.ForeColor = $Colors.Muted
$safeText.Font = New-UiFont 7.5
$safeBox.Controls.Add($safeText)

$mainLayout = New-Object System.Windows.Forms.TableLayoutPanel
$mainLayout.Dock = [System.Windows.Forms.DockStyle]::Fill
$mainLayout.ColumnCount = 1
$mainLayout.RowCount = 5
$mainLayout.BackColor = $Colors.Canvas
$mainLayout.Padding = New-Object System.Windows.Forms.Padding(0)
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 138)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 88)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 158)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 122)))
$mainPanel.Controls.Add($mainLayout)

$launchPanel = New-Object System.Windows.Forms.Panel
$launchPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$launchPanel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$launchPanel.BackColor = $Colors.Navy2
$mainLayout.Controls.Add($launchPanel, 0, 0)

$runStateLabel = New-Object System.Windows.Forms.Label
$runStateLabel.Text = "READY FOR CHECK"
$runStateLabel.Location = New-Object System.Drawing.Point(22, 20)
$runStateLabel.AutoSize = $true
$runStateLabel.ForeColor = New-Color "#64D9AD"
$runStateLabel.Font = New-Object System.Drawing.Font("Consolas", 8, [System.Drawing.FontStyle]::Bold)
$launchPanel.Controls.Add($runStateLabel)

$launchTitle = New-Object System.Windows.Forms.Label
$launchTitle.Text = "문제를 가져오고 Worker를 출발시키세요."
$launchTitle.Location = New-Object System.Drawing.Point(22, 42)
$launchTitle.Size = New-Object System.Drawing.Size(500, 30)
$launchTitle.ForeColor = $Colors.Paper
$launchTitle.Font = New-UiFont 15 ([System.Drawing.FontStyle]::Bold)
$launchPanel.Controls.Add($launchTitle)

$runMessage = New-Object System.Windows.Forms.Label
$runMessage.Text = "왼쪽에서 Demo 또는 로컬 CTFd 환경을 먼저 확인합니다."
$runMessage.Location = New-Object System.Drawing.Point(24, 78)
$runMessage.Size = New-Object System.Drawing.Size(550, 24)
$runMessage.ForeColor = New-Color "#B8C7D3"
$runMessage.Font = New-UiFont 8.5
$launchPanel.Controls.Add($runMessage)

$runButton = New-Object System.Windows.Forms.Button
$runButton.Text = "▶  자동 풀이 시작"
$runButton.Size = New-Object System.Drawing.Size(176, 46)
$runButton.Location = New-Object System.Drawing.Point(610, 27)
$runButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $runButton $Colors.Accent $Colors.Paper 46
$runButton.Enabled = $false
$launchPanel.Controls.Add($runButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "중지"
$stopButton.Size = New-Object System.Drawing.Size(72, 46)
$stopButton.Location = New-Object System.Drawing.Point(792, 27)
$stopButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $stopButton $Colors.Red $Colors.Paper 46
$stopButton.Enabled = $false
$launchPanel.Controls.Add($stopButton)

$resetButton = New-Object System.Windows.Forms.Button
$resetButton.Text = "초기화"
$resetButton.Size = New-Object System.Drawing.Size(72, 27)
$resetButton.Location = New-Object System.Drawing.Point(792, 80)
$resetButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $resetButton $Colors.Navy $Colors.Paper 27
$launchPanel.Controls.Add($resetButton)

$exportButton = New-Object System.Windows.Forms.Button
$exportButton.Text = "보고서 저장"
$exportButton.Size = New-Object System.Drawing.Size(98, 27)
$exportButton.Location = New-Object System.Drawing.Point(688, 80)
$exportButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
Set-FlatButtonStyle $exportButton $Colors.Navy $Colors.Paper 27
$launchPanel.Controls.Add($exportButton)

$runProgress = New-Object System.Windows.Forms.ProgressBar
$runProgress.Dock = [System.Windows.Forms.DockStyle]::Bottom
$runProgress.Height = 6
$runProgress.Minimum = 0
$runProgress.Maximum = 100
$runProgress.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
$launchPanel.Controls.Add($runProgress)

$metricLayout = New-Object System.Windows.Forms.TableLayoutPanel
$metricLayout.Dock = [System.Windows.Forms.DockStyle]::Fill
$metricLayout.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$metricLayout.ColumnCount = 4
$metricLayout.RowCount = 1
for ($i = 0; $i -lt 4; $i++) {
    $metricLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 25)))
}
$mainLayout.Controls.Add($metricLayout, 0, 1)

function New-MetricCard {
    param([string]$Title, [string]$Subtitle)
    $card = New-Object System.Windows.Forms.Panel
    $card.Dock = [System.Windows.Forms.DockStyle]::Fill
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 9, 0)
    $card.BackColor = $Colors.Paper
    $card.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = $Title
    $titleLabel.Location = New-Object System.Drawing.Point(13, 8)
    $titleLabel.AutoSize = $true
    $titleLabel.ForeColor = $Colors.Muted
    $titleLabel.Font = New-UiFont 7.5 ([System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($titleLabel)

    $valueLabel = New-Object System.Windows.Forms.Label
    $valueLabel.Text = "0"
    $valueLabel.Location = New-Object System.Drawing.Point(12, 27)
    $valueLabel.Size = New-Object System.Drawing.Size(120, 28)
    $valueLabel.ForeColor = $Colors.Ink
    $valueLabel.Font = New-Object System.Drawing.Font("Consolas", 17, [System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($valueLabel)

    $subLabel = New-Object System.Windows.Forms.Label
    $subLabel.Text = $Subtitle
    $subLabel.Location = New-Object System.Drawing.Point(13, 56)
    $subLabel.AutoSize = $true
    $subLabel.ForeColor = New-Color "#9AA4AF"
    $subLabel.Font = New-Object System.Drawing.Font("Consolas", 6.8, [System.Drawing.FontStyle]::Regular)
    $card.Controls.Add($subLabel)
    return [PSCustomObject]@{ Panel = $card; Value = $valueLabel; Subtitle = $subLabel }
}

$metricTotal = New-MetricCard "불러온 문제" "SELECTED CHALLENGES"
$metricSolved = New-MetricCard "검증 완료" "CTFD CORRECT ONLY"
$metricWorkers = New-MetricCard "활성 Worker" "HARD CAP: THREE"
$metricProgress = New-MetricCard "진행률" "IDLE"
$metricLayout.Controls.Add($metricTotal.Panel, 0, 0)
$metricLayout.Controls.Add($metricSolved.Panel, 1, 0)
$metricLayout.Controls.Add($metricWorkers.Panel, 2, 0)
$metricProgress.Panel.Margin = New-Object System.Windows.Forms.Padding(0)
$metricLayout.Controls.Add($metricProgress.Panel, 3, 0)

$workerGroup = New-Object System.Windows.Forms.GroupBox
$workerGroup.Text = "03   Worker Rack · JSON I/O · 별도 프로세스"
$workerGroup.Dock = [System.Windows.Forms.DockStyle]::Fill
$workerGroup.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$workerGroup.BackColor = $Colors.Paper
$workerGroup.ForeColor = $Colors.Ink
$workerGroup.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Bold)
$mainLayout.Controls.Add($workerGroup, 0, 2)

$workerLayout = New-Object System.Windows.Forms.TableLayoutPanel
$workerLayout.Dock = [System.Windows.Forms.DockStyle]::Fill
$workerLayout.Padding = New-Object System.Windows.Forms.Padding(8, 7, 8, 8)
$workerLayout.ColumnCount = 3
$workerLayout.RowCount = 1
for ($i = 0; $i -lt 3; $i++) {
    $workerLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 33.333)))
}
$workerGroup.Controls.Add($workerLayout)

$workerViews = @()
for ($i = 1; $i -le 3; $i++) {
    $card = New-Object System.Windows.Forms.Panel
    $card.Dock = [System.Windows.Forms.DockStyle]::Fill
    $card.Margin = New-Object System.Windows.Forms.Padding(3)
    $card.BackColor = New-Color "#FBFCFB"
    $card.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle

    $name = New-Object System.Windows.Forms.Label
    $name.Text = "●  Worker $($i.ToString('00'))"
    $name.Location = New-Object System.Drawing.Point(12, 10)
    $name.Size = New-Object System.Drawing.Size(135, 20)
    $name.ForeColor = $Colors.Ink
    $name.Font = New-UiFont 8.5 ([System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($name)

    $status = New-Object System.Windows.Forms.Label
    $status.Text = "IDLE"
    $status.Location = New-Object System.Drawing.Point(154, 10)
    $status.Size = New-Object System.Drawing.Size(82, 18)
    $status.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $status.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $status.ForeColor = $Colors.Muted
    $status.Font = New-Object System.Drawing.Font("Consolas", 7.5, [System.Drawing.FontStyle]::Bold)
    $card.Controls.Add($status)

    $task = New-Object System.Windows.Forms.Label
    $task.Text = "Job 대기 중"
    $task.Location = New-Object System.Drawing.Point(12, 39)
    $task.Size = New-Object System.Drawing.Size(224, 20)
    $task.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $task.ForeColor = $Colors.Muted
    $task.Font = New-UiFont 7.5
    $card.Controls.Add($task)

    $phase = New-Object System.Windows.Forms.Label
    $phase.Text = "대기"
    $phase.Location = New-Object System.Drawing.Point(12, 63)
    $phase.Size = New-Object System.Drawing.Size(224, 18)
    $phase.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $phase.ForeColor = $Colors.Muted
    $phase.Font = New-Object System.Drawing.Font("Consolas", 7, [System.Drawing.FontStyle]::Regular)
    $card.Controls.Add($phase)

    $progress = New-Object System.Windows.Forms.ProgressBar
    $progress.Location = New-Object System.Drawing.Point(12, 87)
    $progress.Size = New-Object System.Drawing.Size(224, 7)
    $progress.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $progress.Maximum = 100
    $card.Controls.Add($progress)

    $workerLayout.Controls.Add($card, $i - 1, 0)
    $workerViews += [PSCustomObject]@{ Card = $card; Name = $name; Status = $status; Task = $task; Phase = $phase; Progress = $progress }
}

$challengeGroup = New-Object System.Windows.Forms.GroupBox
$challengeGroup.Text = "04   Challenge Queue"
$challengeGroup.Dock = [System.Windows.Forms.DockStyle]::Fill
$challengeGroup.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$challengeGroup.BackColor = $Colors.Paper
$challengeGroup.ForeColor = $Colors.Ink
$challengeGroup.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Bold)
$mainLayout.Controls.Add($challengeGroup, 0, 3)

$challengeGrid = New-Object System.Windows.Forms.DataGridView
$challengeGrid.Dock = [System.Windows.Forms.DockStyle]::Fill
$challengeGrid.BackgroundColor = $Colors.Paper
$challengeGrid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$challengeGrid.AllowUserToAddRows = $false
$challengeGrid.AllowUserToDeleteRows = $false
$challengeGrid.AllowUserToResizeRows = $false
$challengeGrid.ReadOnly = $true
$challengeGrid.RowHeadersVisible = $false
$challengeGrid.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill
$challengeGrid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
$challengeGrid.MultiSelect = $false
$challengeGrid.EnableHeadersVisualStyles = $false
$challengeGrid.ColumnHeadersDefaultCellStyle.BackColor = New-Color "#F5F7F6"
$challengeGrid.ColumnHeadersDefaultCellStyle.ForeColor = $Colors.Muted
$challengeGrid.ColumnHeadersDefaultCellStyle.Font = New-UiFont 7.5 ([System.Drawing.FontStyle]::Bold)
$challengeGrid.DefaultCellStyle.Font = New-UiFont 8
$challengeGrid.DefaultCellStyle.SelectionBackColor = New-Color "#E5EEFC"
$challengeGrid.DefaultCellStyle.SelectionForeColor = $Colors.Ink
$challengeGrid.GridColor = $Colors.Soft
$challengeGrid.Columns.Add("Name", "문제") | Out-Null
$challengeGrid.Columns.Add("Category", "분야") | Out-Null
$challengeGrid.Columns.Add("Points", "점수") | Out-Null
$challengeGrid.Columns.Add("Worker", "Worker") | Out-Null
$challengeGrid.Columns.Add("Status", "상태") | Out-Null
$challengeGrid.Columns[0].FillWeight = 220
$challengeGrid.Columns[1].FillWeight = 65
$challengeGrid.Columns[2].FillWeight = 55
$challengeGrid.Columns[3].FillWeight = 75
$challengeGrid.Columns[4].FillWeight = 130
$challengeGroup.Controls.Add($challengeGrid)

$eventGroup = New-Object System.Windows.Forms.GroupBox
$eventGroup.Text = "05   Live Event Log"
$eventGroup.Dock = [System.Windows.Forms.DockStyle]::Fill
$eventGroup.Margin = New-Object System.Windows.Forms.Padding(0)
$eventGroup.BackColor = $Colors.Paper
$eventGroup.ForeColor = $Colors.Ink
$eventGroup.Font = New-UiFont 9 ([System.Drawing.FontStyle]::Bold)
$mainLayout.Controls.Add($eventGroup, 0, 4)

$eventLog = New-Object System.Windows.Forms.RichTextBox
$eventLog.Dock = [System.Windows.Forms.DockStyle]::Fill
$eventLog.ReadOnly = $true
$eventLog.BackColor = $Colors.Log
$eventLog.ForeColor = New-Color "#B8C5D1"
$eventLog.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$eventLog.Font = New-Object System.Drawing.Font("Consolas", 8, [System.Drawing.FontStyle]::Regular)
$eventLog.WordWrap = $false
$eventGroup.Controls.Add($eventLog)

function Update-DesktopState {
    param([object]$State)
    if ($null -eq $State) { return }
    $script:CurrentState = $State

    $connected = [bool]$State.connection.connected
    $running = $State.run.status -eq "running"
    if ($connected) {
        $connectionLabel.Text = "●  $($State.connection.label) · 연결됨"
        $connectionLabel.ForeColor = $Colors.Green
    }
    else {
        $connectionLabel.Text = "연결 전"
        $connectionLabel.ForeColor = $Colors.Muted
    }

    $runStateLabel.Text = [string]$State.run.status.ToUpperInvariant()
    $runMessage.Text = [string]$State.run.message
    $runProgress.Value = [Math]::Max(0, [Math]::Min(100, [int]$State.run.progress))
    $runButton.Enabled = $connected -and -not $running
    $stopButton.Enabled = $running
    $connectButton.Enabled = -not $running

    $challenges = @($State.challenges)
    $workers = @($State.workers)
    $activeCount = @($workers | Where-Object { $_.status -eq "running" }).Count
    $metricTotal.Value.Text = [string]$(if ([int]$State.run.total -gt 0) { $State.run.total } else { $challenges.Count })
    $metricSolved.Value.Text = [string]$State.run.solved
    $metricWorkers.Value.Text = "$activeCount/$($State.config.workerLimit)"
    $metricProgress.Value.Text = "$($State.run.progress)%"
    $metricProgress.Subtitle.Text = [string]$State.run.status.ToUpperInvariant()

    for ($index = 0; $index -lt 3; $index++) {
        $view = $workerViews[$index]
        $worker = $workers[$index]
        $view.Status.Text = [string]$worker.status.ToUpperInvariant()
        $view.Task.Text = $(if ($worker.challengeName) { [string]$worker.challengeName } elseif ($worker.enabled) { "Job 대기 중" } else { "Concurrency 제한" })
        $profile = $(if ($worker.profile) { [string]$worker.profile.ToUpperInvariant() } else { "NONE" })
        $view.Phase.Text = "$profile · $($worker.phase) · DONE $($worker.completed)"
        $view.Progress.Value = [Math]::Max(0, [Math]::Min(100, [int]$worker.progress))
        if ($worker.status -eq "running") {
            $view.Name.ForeColor = $Colors.Green
            $view.Card.BackColor = New-Color "#F2FBF7"
        }
        elseif (-not $worker.enabled) {
            $view.Name.ForeColor = New-Color "#A7B0AB"
            $view.Card.BackColor = New-Color "#F4F5F4"
        }
        else {
            $view.Name.ForeColor = $Colors.Ink
            $view.Card.BackColor = New-Color "#FBFCFB"
        }
    }

    $challengeGrid.Rows.Clear()
    foreach ($challenge in $challenges) {
        $workerId = $(if ($challenge.workerId) { [string]$challenge.workerId } else { "—" })
        $statusText = "$($challenge.status) · $($challenge.phase)"
        $rowIndex = $challengeGrid.Rows.Add($challenge.name, ([string]$challenge.category).ToUpperInvariant(), $challenge.points, $workerId, $statusText)
        $row = $challengeGrid.Rows[$rowIndex]
        if ($challenge.status -eq "solved") {
            $row.Cells[4].Style.ForeColor = $Colors.Green
        }
        elseif ($challenge.status -eq "failed") {
            $row.Cells[4].Style.ForeColor = $Colors.Red
        }
        elseif ($challenge.status -eq "needs_tooling") {
            $row.Cells[4].Style.ForeColor = $Colors.Amber
        }
    }

    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($event in @($State.events) | Select-Object -First 80) {
        $timestamp = ([DateTime]$event.time).ToLocalTime().ToString("HH:mm:ss")
        $lines.Add("$timestamp  [$(([string]$event.type).ToUpperInvariant())]  $($event.message)")
    }
    $eventLog.Lines = $lines.ToArray()

    $codexAvailable = [bool]$State.environment.codexSdkAvailable
    if ($modeCombo.SelectedIndex -eq 1) {
        $codexCheck.Enabled = $codexAvailable
    }
    else {
        $codexCheck.Enabled = $false
    }
    $apiStatus.Text = "●  LOCAL API · NODE $($State.environment.nodeVersion)"
}

function Get-SelectedCategories {
    $categories = New-Object System.Collections.Generic.List[string]
    if ($pwnCheck.Checked) { $categories.Add("pwn") }
    if ($revCheck.Checked) { $categories.Add("rev") }
    if ($webCheck.Checked) { $categories.Add("web") }
    return $categories.ToArray()
}

$modeCombo.Add_SelectedIndexChanged({
    $ctfdMode = $modeCombo.SelectedIndex -eq 1
    $urlText.Enabled = $ctfdMode
    $tokenText.Enabled = $ctfdMode
    $autoSubmitCheck.Enabled = $ctfdMode
    $authorizedCheck.Enabled = $ctfdMode
    if ($ctfdMode -and $null -ne $script:CurrentState) {
        $codexCheck.Enabled = [bool]$script:CurrentState.environment.codexSdkAvailable
    }
    else {
        $codexCheck.Checked = $false
        $codexCheck.Enabled = $false
    }
})

$connectButton.Add_Click({
    try {
        $connectButton.Enabled = $false
        $connectButton.Text = "확인 중..."
        [System.Windows.Forms.Application]::DoEvents()
        $ctfdMode = $modeCombo.SelectedIndex -eq 1
        $payload = @{
            mode = $(if ($ctfdMode) { "ctfd" } else { "demo" })
            workerLimit = [int]$workerCount.Value
            categories = @(Get-SelectedCategories)
            baseUrl = $urlText.Text.Trim()
            apiToken = $tokenText.Text
            useCodex = [bool]$codexCheck.Checked
            autoSubmit = [bool]$autoSubmitCheck.Checked
            authorized = $(if ($ctfdMode) { [bool]$authorizedCheck.Checked } else { $true })
        }
        $state = Invoke-HarnessApi -Path "/api/connect" -Method "POST" -Body $payload -TimeoutSec 10
        $tokenText.Clear()
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
    finally {
        $connectButton.Text = "환경 확인"
        if ($null -ne $script:CurrentState -and $script:CurrentState.run.status -ne "running") {
            $connectButton.Enabled = $true
        }
    }
})

$runButton.Add_Click({
    try {
        $state = Invoke-HarnessApi -Path "/api/run" -Method "POST" -Body @{}
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
})

$stopButton.Add_Click({
    try {
        $state = Invoke-HarnessApi -Path "/api/stop" -Method "POST" -Body @{}
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
})

$resetButton.Add_Click({
    try {
        $state = Invoke-HarnessApi -Path "/api/reset" -Method "POST" -Body @{}
        Update-DesktopState $state
    }
    catch {
        Show-AppError $_.Exception.Message
    }
})

$exportButton.Add_Click({
    if ($null -eq $script:CurrentState) { return }
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title = "공개 Harness 상태 저장"
    $dialog.Filter = "JSON report (*.json)|*.json"
    $runId = $(if ($script:CurrentState.run.id) { $script:CurrentState.run.id } else { "idle" })
    $dialog.FileName = "harness-report-$runId.json"
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $script:CurrentState | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $dialog.FileName -Encoding UTF8
    }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 700
$timer.Add_Tick({
    if ($script:Refreshing) { return }
    $script:Refreshing = $true
    try {
        $state = Invoke-HarnessApi -Path "/api/state" -TimeoutSec 2
        Update-DesktopState $state
        $apiStatus.ForeColor = New-Color "#5BD3A5"
    }
    catch {
        $apiStatus.Text = "●  LOCAL API OFFLINE"
        $apiStatus.ForeColor = New-Color "#FF8589"
    }
    finally {
        $script:Refreshing = $false
    }
})

$form.Add_Resize({
    $apiStatus.Left = [Math]::Max(780, $header.ClientSize.Width - $apiStatus.Width - 28)
})

$form.Add_FormClosing({
    $timer.Stop()
    if ($null -ne $script:OwnedServer) {
        try { Invoke-HarnessApi -Path "/api/stop" -Method "POST" -Body @{} -TimeoutSec 1 | Out-Null } catch {}
        Stop-OwnedServer
    }
})

$form.Add_KeyDown({
    param($sender, $eventArgs)
    if ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::F5) {
        try { Update-DesktopState (Invoke-HarnessApi -Path "/api/state") } catch { Show-AppError $_.Exception.Message }
    }
})

Update-DesktopState $script:CurrentState
$timer.Start()
[System.Windows.Forms.Application]::Run($form)
