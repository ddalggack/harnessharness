@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js was not found. This launcher does not install or update Node.js.
  echo Ask the instructor which existing runtime should be used.
  pause
  exit /b 1
)

for /f %%V in ('node -p "process.versions.node"') do set HARNESS_NODE_VERSION=%%V
echo Starting CTF Run Harness with existing Node %HARNESS_NODE_VERSION%...
start "" "http://127.0.0.1:8788"
node server\index.cjs

echo.
echo Harness stopped.
pause
