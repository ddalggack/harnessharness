# AGENTS.md — CTF Run Harness 개발 규칙

## 1. 이 파일의 목적

이 문서는 이 저장소에서 작업하는 Codex와 개발자가 따라야 할 운영 계약이다. 구현 방법이 불명확할 때는 다음 우선순위를 따른다.

1. 안전과 명시적 사용자 범위
2. 이 `AGENTS.md`의 불변 조건
3. `PRD.md`의 P0 요구사항
4. `plan.md`의 현재 milestone
5. 기존 코드와 테스트의 공개 계약

문서가 서로 충돌하면 추측으로 구현하지 말고 충돌을 기록한 뒤 가장 작은 안전한 변경만 수행한다.

## 2. 프로젝트 불변 조건

1. 추론을 담당하는 AI는 Main Codex 하나뿐이다.
2. Worker는 Codex 서브에이전트나 별도 LLM이 아니다.
3. Worker는 허용된 도구와 artifact를 실행하는 독립 프로그램이다.
4. 여러 모델이 같은 문제를 푸는 Swarm/Racing은 구현하지 않는다.
5. 동시에 활성화되는 Worker Run은 최대 3개다.
6. Main과 Worker는 버전이 명시된 JSON으로만 통신한다.
7. Worker는 플래그를 직접 제출하지 않는다.
8. 모델이나 Worker의 성공 주장은 solve 근거가 아니다.
9. CTFd의 `correct` 응답만 최종 성공 근거다.
10. MVP는 허가된 로컬 CTFd만 대상으로 한다.

`Swarm`이라는 표현 대신 `Worker Run` 또는 `Challenge Runner`를 사용한다.

## 3. 채택한 하네스 패턴

[revfactory/harness의 아키텍처 패턴](https://github.com/revfactory/harness/blob/main/skills/harness/references/agent-design-patterns.md) 중 세 가지를 결합한다.

### Supervisor

Main Codex가 현재 문제, checkpoint, Worker 상태를 보고 작업을 동적으로 배정한다. Supervisor가 병목이 되지 않도록 한 Job은 독립적으로 의미 있는 분석 단위를 포함해야 한다.

### Expert Pool

문제 카테고리에 맞는 Worker Profile만 선택한다.

```text
pwn -> pwn tool profile
rev -> rev tool profile
web -> web tool profile
```

Worker Profile은 AI 전문가가 아니라 도구·실행 정책 묶음이다.

### Pipeline

다음 단계를 건너뛰거나 결합하지 않는다.

```text
Collect -> Decide -> Dispatch -> Execute -> Validate -> Submit -> Record
```

## 4. 세션 시작 절차: Phase 0 Audit

작업을 시작할 때 다음을 먼저 확인한다.

1. `PRD.md`, `AGENTS.md`, `plan.md`를 모두 읽는다.
2. 현재 milestone과 완료 조건을 확인한다.
3. 기존 코드, 계약, 테스트, 미완료 변경을 확인한다.
4. 사용자 변경과 현재 작업이 겹치는지 확인한다.
5. 새 역할·모듈을 만들기 전에 기존 구현으로 해결 가능한지 확인한다.
6. 실행할 수 없는 외부 서비스와 미검증 영역을 구분한다.

감사 결과를 바탕으로 현재 milestone에 필요한 가장 작은 수직 변경을 선택한다.

## 5. 컴포넌트별 책임

### Poller

- CTFd 문제 목록을 기본 5초마다 조회한다.
- 신규·변경·미해결 문제만 전달한다.
- 중복 Run을 만들지 않는다.
- LLM을 호출하거나 문제를 풀지 않는다.

### Main Codex Coordinator

- 하나의 Run에서 하나의 Codex thread만 사용한다.
- 문제를 분류하고 Worker Profile을 선택한다.
- JSON Schema를 만족하는 Decision만 생성한다.
- 동시에 최대 3개의 Job만 활성화한다.
- Worker 결과와 실패 로그를 기반으로 다음 action을 결정한다.
- raw command 대신 `operation`, `tool`, `args[]`를 생성한다.

### Worker Scheduler

- Job Schema와 tool allowlist를 검증한다.
- 최대 동시성 3을 강제한다.
- Worker별 독립 workspace를 할당한다.
- timeout, 취소, 종료 상태를 관리한다.
- 로컬, Docker, Kubernetes 차이를 Core에서 숨긴다.

### Worker Program

- 선택된 Profile의 도구만 실행한다.
- 다른 Worker workspace에 접근하지 않는다.
- 결과를 Result JSON으로만 반환한다.
- 플래그를 직접 제출하거나 모델 API를 호출하지 않는다.
- 큰 파일과 로그는 artifact로 저장하고 reference만 반환한다.

### Submission Broker

- 플래그 형식과 중복을 검사한다.
- CTFd Platform Adapter로만 제출한다.
- 원문 플래그를 일반 로그와 API 응답에 남기지 않는다.
- CTFd 응답을 accepted/rejected 이벤트로 기록한다.

### Platform Adapter

- MVP에서는 CTFd만 구현한다.
- 문제 조회, 상세 정보, 파일 참조, 플래그 제출 인터페이스를 제공한다.
- 설정된 host allowlist 밖으로 요청하지 않는다.

## 6. 디렉터리 경계

권장 구조는 다음과 같다.

```text
contracts/       JSON Schema
src/core/        유스케이스와 상태 전이
src/agent/       Main Codex Adapter
src/platform/    CTFd Adapter
src/poller/      문제 변경 감지
src/scheduler/   Local/Docker/Kubernetes 실행 Adapter
src/workers/     Worker Profile과 프로그램
src/submission/  검증·중복 방지·제출
src/events/      이벤트 기록·전달
src/storage/     checkpoint와 artifact 저장소
infra/           로컬·배포 인프라
test/            계약·경계·수직 실행 테스트
_workspace/      실행 및 평가 iteration 기록
```

Core는 Codex SDK, CTFd, Docker, Kubernetes, PostgreSQL, S3를 직접 import하지 않는다. 외부 SDK는 해당 Adapter에서만 사용한다.

## 7. 입력·출력 프로토콜

### Decision

필수 항목:

- `schemaVersion`, `decisionId`, `runId`
- 최대 3개의 `actions[]`
- `challengeId`, `workerProfile`, `operation`
- `toolCalls[]`, `artifactRefs[]`, `reason`

### Worker Job

필수 항목:

- `schemaVersion`, `jobId`, `runId`, `challengeId`
- `workerProfile`, `operation`, `toolCalls[]`
- 입력 artifact key와 SHA-256
- timeout, 최대 출력 크기, 생성 시각

### Worker Result

필수 항목:

- 원본 Job과 동일한 `jobId`, `runId`, `challengeId`
- `workerId`
- `succeeded`, `failed`, `timed_out` 중 하나의 상태
- `observations[]`, `flagCandidates[]`, `artifactRefs[]`
- 구조화된 error, 시작·종료 시각

생산자가 출력한 JSON과 소비자가 기대하는 Schema를 반드시 함께 읽고 비교한다. 한쪽만 검사해서는 경계 검증을 완료한 것으로 보지 않는다.

## 8. Context와 artifact 관리

참고 저장소의 Progressive Disclosure 원칙을 다음처럼 적용한다.

- Main Codex에는 현재 결정에 필요한 문제 요약, 최근 실패, artifact index만 전달한다.
- 원본 바이너리, 전체 로그, workspace snapshot은 artifact 저장소에 둔다.
- Main은 필요할 때만 특정 artifact를 읽는다.
- JSON에는 대용량 데이터나 base64 바이너리를 직접 넣지 않는다.
- 각 artifact는 상대 key, SHA-256, 생성 주체, 생성 시각을 가진다.

실행 결과는 iteration별로 보존한다.

```text
_workspace/
  iteration-001/
    input/
    decisions/
    jobs/
    results/
    artifacts/
    events.jsonl
    metrics.json
```

이전 iteration을 덮어쓰지 않는다. 하네스 변경 전·후 감사와 비교에 필요하다.

## 9. 실행 및 보안 규칙

- JSON의 `command` 문자열을 실행하지 않는다.
- `shell`, `bash -c`, `sh -c`, `powershell -Command` 우회를 허용하지 않는다.
- 실행 요청은 허용된 `operation`, `tool`, `args[]`로 표현한다.
- Profile allowlist에 없는 도구는 dispatch 전에 차단한다.
- 상대 artifact key가 workspace 밖으로 나가는지 검사한다.
- Worker network는 로컬 CTF challenge allowlist로 제한한다.
- 토큰, 원문 플래그, 비공개 원본 문제, exploit 산출물을 Git에 커밋하지 않는다.
- 공개 인터넷 또는 허가되지 않은 대상에 실행하지 않는다.
- 자동 제출은 로컬 CTFd 또는 명시적으로 허용된 환경에서만 활성화한다.

## 10. 오류 처리 계약

| 상황 | 처리 |
|---|---|
| CTFd 일시 오류 | 제한된 지수 backoff, 기존 Run 유지 |
| Decision Schema 실패 | Worker에 전달 금지, 원문 마스킹 후 오류 기록, 1회 교정 요청 |
| 알 수 없는 challenge/profile/tool | dispatch 거부, validation event 기록 |
| Worker timeout | 프로세스 종료, 부분 artifact 보존, `timed_out` 결과 생성 |
| Worker 비정상 종료 | 다른 Run과 격리, 제한된 횟수만 재시도 |
| Result ID 불일치 | 결과 폐기, 보안 이벤트 기록 |
| 중복 flag | 제출하지 않고 deduplicated event 기록 |
| 과반 Worker 실패 | 현재 결과 보존, 자동 확장 중지, 사용자에게 보고 |

무한 재시도는 금지한다. retry 횟수와 시간 예산은 Job에 명시한다.

## 11. 구현 절차

1. 현재 milestone의 인수 조건을 확인한다.
2. 정상 흐름 1개와 오류 흐름 1개를 먼저 정의한다.
3. 변경할 생산자와 소비자 경계를 함께 식별한다.
4. 계약 또는 정책 변경이면 실패 테스트를 먼저 추가한다.
5. 가장 작은 구현을 수행한다.
6. 모듈 테스트 직후 경계 통합 테스트를 수행한다.
7. 전체 테스트와 demo 수직 경로를 실행한다.
8. 검증 근거를 iteration 디렉터리에 보존한다.
9. 실제로 완료된 항목만 `plan.md`에서 체크한다.

MVP 밖의 대시보드·범용 플랫폼·운영 인프라보다 다음 수직 경로를 우선한다.

```text
CTFd 문제 1개 -> Main Decision -> Worker 실행 -> Result -> Flag 제출
```

## 12. Incremental QA

[revfactory/harness의 QA 가이드](https://github.com/revfactory/harness/blob/main/skills/harness/references/qa-agent-guide.md)에서 제안하는 “양쪽 동시 읽기” 원칙을 적용한다.

| 경계 | 생산자 | 소비자 | 필수 확인 |
|---|---|---|---|
| CTFd 응답 | CTFd Adapter | Poller/Core | field·status mapping |
| Decision | Main Codex | Scheduler | Schema·최대 action 수 |
| Job | Scheduler | Worker | profile·tool·artifact·timeout |
| Result | Worker | Main/Core | ID·status·artifact 일치 |
| Flag candidate | Worker Result | Submission Broker | masking·dedup·형식 |
| Submission | Broker | CTFd | 요청 payload·응답 판정 |

각 모듈 완성 직후 대응 경계를 검사한다. 전체 구현 후 한 번만 QA하지 않는다.

## 13. 테스트 규칙

다음 테스트는 필수다.

- 유효한 Decision/Job/Result/Event 계약 통과
- unexpected field와 raw command 차단
- 분야별 비허용 tool 차단
- workspace path traversal 차단
- Worker 최대 동시성 3 준수
- Result identity mismatch 차단
- CTFd host allowlist 적용
- 중복 flag 제출 차단
- CTFd `correct`만 solve 처리
- 로그와 API의 원문 flag 마스킹
- Main과 외부 Worker 사이 JSON 왕복
- 정상 흐름 1개와 실패·timeout 흐름 1개

빌드가 성공했다는 이유만으로 통합 검증을 생략하지 않는다.

## 14. 하네스 평가와 진화

[revfactory/harness의 테스트 가이드](https://github.com/revfactory/harness/blob/main/skills/harness/references/skill-testing-guide.md)의 비교 원칙을 다음처럼 적용한다.

1. 동일 문제와 동일 예산으로 Baseline과 With-Harness를 실행한다.
2. 객관적으로 참/거짓을 판단할 수 있는 assertion을 사용한다.
3. 두 조건이 항상 통과하는 검사는 제거한다.
4. solve rate, 시간, token, retry, invalid action을 즉시 기록한다.
5. holdout 문제로 변경 사항의 과적합을 확인한다.
6. 하네스 변경 이유와 결과 delta를 iteration 기록에 남긴다.
7. 새 버전이 악화되면 승격하지 않는다.

하네스 규칙은 고정물이 아니지만, 테스트 근거 없이 자동 수정하거나 승격하지 않는다.

## 15. 완료 보고 형식

작업 완료 보고에는 다음을 포함한다.

- 변경된 동작
- 변경 파일
- 실행한 테스트와 결과
- 실제 서비스로 검증한 범위
- mock으로만 검증한 범위
- 남은 위험과 다음 작업

성공, 실패, 미검증을 섞어서 보고하지 않는다.

## 16. MVP 비목표 재확인

- 다중 모델 Agent Team
- Swarm 내부 모델 경쟁
- Worker의 LLM 호출
- 범용 CTF 스크래핑
- 운영 규모 Kubernetes/NATS/Dashboard
- 무제한 자동 재시도
- 허가되지 않은 대상 공격

## 17. 참고 및 적용 범위

이 문서는 Apache-2.0 라이선스의 [revfactory/harness](https://github.com/revfactory/harness)에서 다음 원칙을 참고해 프로젝트에 맞게 재작성했다.

- Supervisor, Expert Pool, Pipeline 패턴
- 명시적인 입력·출력·오류 처리 계약
- Progressive Disclosure와 iteration 기록 보존
- Incremental QA와 경계 양쪽 동시 검증
- Baseline 대비 With-Harness 평가

원 저장소의 Claude Agent Teams, Opus 고정, 다중 Agent 통신 규칙은 “Main Codex 하나만 사용”한다는 본 프로젝트의 불변 조건과 충돌하므로 적용하지 않는다.
