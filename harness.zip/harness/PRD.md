# PRD — CTF Run Harness

## 1. 문서 정보

- 제품명: CTF Run Harness
- 문서 상태: MVP 초안
- 대상 발표: 바이브 엔지니어링 하네스 팀 프로젝트
- 우선 플랫폼: 로컬 CTFd
- 대상 분야: `pwn`, `rev`, `web`

## 2. 한 문장 정의

로컬 CTFd의 신규 문제를 Poller가 감지하면, 하나의 Main Codex가 문제를 분석해 최대 3개의 독립 Worker 프로그램에 구조화된 작업을 배정하고, 결과를 검토해 유효한 플래그를 CTFd에 자동 제출하는 장기 실행 하네스다.

## 3. 문제 정의

CTF 문제를 AI에게 한 번에 맡기는 방식에는 다음 문제가 있다.

- 여러 문제를 동시에 관리하기 어렵다.
- 긴 실행 중 현재 상태와 실패 원인이 사라진다.
- AI의 추론과 위험한 도구 실행이 같은 환경에 섞인다.
- 임의 명령, 중복 제출, 잘못된 성공 판정이 발생할 수 있다.
- 같은 문제 세트로 하네스 변경 전·후 성능을 비교하기 어렵다.

이 프로젝트는 추론, 실행, 검증, 제출을 명시적인 계약으로 분리해 이러한 문제를 줄인다.

## 4. 목표

### P0 — 발표 가능한 수직 경로

1. 로컬 CTFd의 문제 목록을 5초 주기로 조회한다.
2. Main Codex가 문제를 분석하고 유효한 Worker Job JSON을 생성한다.
3. Worker 프로그램이 격리된 workspace에서 허용된 도구를 실행한다.
4. Worker가 관찰 결과와 플래그 후보를 Result JSON으로 반환한다.
5. Submission Broker가 중복·형식을 검사한 뒤 CTFd에 제출한다.
6. CTFd의 `correct` 응답을 받은 경우에만 문제 해결로 기록한다.
7. 전체 흐름을 이벤트와 산출물로 재현할 수 있다.

### P1 — 평가 가능한 하네스

1. `pwn`, `rev`, `web`을 각각 지원한다.
2. 동시에 최대 3개의 Worker Run을 안정적으로 관리한다.
3. 프로세스 재시작 후 Main Codex thread와 run 상태를 복구한다.
4. 동일 평가 세트에서 Baseline과 With-Harness를 비교한다.
5. 실패 결과를 다음 Main Codex 판단에 피드백한다.

### P2 — 발표 이후 확장

- Kubernetes Job/Pod 기반 Worker Scheduler
- PostgreSQL 기반 durable state
- S3/MinIO 기반 artifact 저장
- Temporal 기반 retry·timeout·resume
- rCTF 또는 Custom Platform Adapter
- Dashboard 또는 TUI

## 5. 비목표

- 여러 LLM이 같은 문제를 경쟁하는 Swarm/Racing
- Worker 내부의 별도 LLM 또는 Codex 서브에이전트
- 공개 인터넷의 임의 CTF 사이트 스크래핑
- 허가되지 않은 시스템에 대한 자동 공격
- MVP 단계의 운영용 Kubernetes 구축
- Main이 Worker 하네스 자체를 자동 생성·승격하는 메타 하네스
- CTF 플랫폼 응답 없이 모델 판단만으로 성공 처리

## 6. 사용자와 사용 시나리오

### 주요 사용자

- 로컬 CTF 평가 환경을 운영하는 팀원
- 하네스 변경 전·후 성능을 비교하는 개발자
- 발표 시 전체 실행과 실패 회복 과정을 시연하는 발표자

### 대표 시나리오

1. 사용자가 로컬 CTFd 주소와 인증 토큰을 설정한다.
2. Poller가 미해결 문제를 발견한다.
3. Main Codex가 문제 메타데이터와 기존 checkpoint를 읽는다.
4. Main Codex가 분야와 도구를 선택해 최대 3개의 Job JSON을 생성한다.
5. Scheduler가 문제별 독립 Worker Run을 시작한다.
6. Worker는 파일 분석, HTTP 요청 또는 Main이 작성한 artifact 실행을 수행한다.
7. Main Codex가 결과·실패 로그를 보고 후속 Job을 생성하거나 제출을 결정한다.
8. Submission Broker가 후보 플래그를 CTFd에 제출한다.
9. Event Log에서 모든 결정과 결과를 다시 확인한다.

## 7. 제품 아키텍처

참고한 하네스 패턴을 우리 조건에 맞춰 다음과 같이 결합한다.

- Supervisor: Main Codex가 상태를 보고 작업을 동적으로 배정한다.
- Expert Pool: 문제 카테고리에 따라 `pwn`, `rev`, `web` Worker Profile을 선택한다.
- Pipeline: 수집 → 계획 → 실행 → 결과 → 제출 단계를 명확히 분리한다.

```text
CTFd Platform
      │
      ▼
Poller (5 seconds)
      │
      ▼
Main Coordinator (single Codex thread)
      │ Worker Job JSON, max 3 active runs
      ▼
Worker Scheduler
 ├─ pwn Worker Run
 ├─ rev Worker Run
 └─ web Worker Run
      │ Worker Result JSON
      ▼
Main Coordinator
      │ verified flag candidate
      ▼
Submission Broker ──> CTFd Platform
```

Kubernetes 사용 여부는 Core와 무관해야 한다.

```text
MVP:        Local/Docker Scheduler -> isolated workspace/container
Extension:  Kubernetes Scheduler   -> isolated Job/Pod
```

## 8. 기능 요구사항

### FR-01 CTFd Poller

- 기본 5초 주기로 문제 목록을 조회한다.
- 신규, 변경, 미해결 문제만 이벤트로 생성한다.
- 동일 문제에 중복 Run을 생성하지 않는다.
- API 오류 시 지수 backoff하고 기존 Run을 중단하지 않는다.

### FR-02 Main Codex Coordinator

- 하나의 CTF Run에는 하나의 Codex thread를 사용한다.
- 첫 turn 후 thread ID를 checkpoint에 저장한다.
- 재시작 시 기존 thread를 재개한다.
- 출력은 Decision JSON Schema로 검증한다.
- 한 번에 최대 3개의 Worker Job만 활성화한다.
- 큰 로그·바이너리 대신 요약과 artifact reference를 입력으로 사용한다.

### FR-03 Worker Job

- `schemaVersion`, `jobId`, `runId`, `challengeId`를 포함한다.
- `workerProfile`, `operation`, `toolCalls[]`를 포함한다.
- 임의 `command` 문자열을 허용하지 않는다.
- 입력 artifact의 key와 SHA-256을 포함한다.
- timeout과 최대 출력 크기를 포함한다.

### FR-04 Worker Program

- Worker Profile의 allowlist 도구만 실행한다.
- 다른 Worker workspace에 접근하지 않는다.
- timeout과 취소 요청을 준수한다.
- stdout 전체 대신 구조화된 observations와 artifact를 반환한다.
- 플래그를 직접 제출하지 않는다.

### FR-05 Worker Result

- Job과 일치하는 ID를 포함한다.
- 상태는 `succeeded`, `failed`, `timed_out` 중 하나다.
- `observations[]`, `flagCandidates[]`, `artifactRefs[]`를 포함한다.
- 오류 코드, 메시지, 시작·종료 시각을 포함한다.

### FR-06 Submission Broker

- 플래그 형식 검사를 수행한다.
- `challengeId + flag hash` 기준 중복 제출을 차단한다.
- CTFd host allowlist 밖으로 요청하지 않는다.
- CTFd 응답을 accepted/rejected 이벤트로 기록한다.
- 일반 로그와 API 응답에서 원문 플래그를 마스킹한다.

### FR-07 Event와 감사 추적

- run, decision, job, result, submission에 고유 ID를 부여한다.
- 최소 이벤트: run 시작/종료, decision 생성, job 배정, result 수신, 제출 결과.
- 실행마다 독립 iteration 디렉터리를 만들고 이전 결과를 덮어쓰지 않는다.
- 실패·미검증·성공 상태를 구분한다.

## 9. 비기능 요구사항

### 안전성

- 본인 소유 또는 명시적으로 허가된 로컬 CTF 환경에서만 실행한다.
- Worker network는 허용된 challenge host로 제한한다.
- 토큰, 원문 플래그, 원본 비공개 문제, exploit 결과를 Git에 커밋하지 않는다.
- 자동 제출은 해당 CTF 규칙에서 허용될 때만 활성화한다.

### 신뢰성

- Worker 최대 동시성 3을 항상 유지한다.
- 한 Worker 실패가 다른 Worker Run을 중단시키지 않는다.
- 일시 오류는 제한된 횟수만 재시도한다.
- 재시도 예산 소진 시 실패 근거를 보존하고 종료한다.

### 관찰 가능성

- 로그만으로 어떤 문제를 왜 배정했는지 설명할 수 있어야 한다.
- 생산자 JSON과 소비자 기대 형식을 함께 검증한다.
- 빌드 성공과 실제 통합 동작을 별개로 검증한다.

## 10. 평가 설계

### 평가 세트

- `pwn`: 조정용 2문제 + holdout 1문제
- `rev`: 조정용 2문제 + holdout 1문제
- `web`: 조정용 2문제 + holdout 1문제

초기 수직 경로에서는 분야별 쉬운 문제 1개씩 총 3개를 사용한다. 통합이 안정된 후 총 9문제로 확장한다.

### 비교 조건

- Baseline: 구조화된 Job·checkpoint·profile 정책 없이 Main Codex에 직접 풀이 요청
- With-Harness: 동일 모델과 동일 문제를 본 문서의 Coordinator/Worker 계약으로 실행
- 두 조건은 같은 문제, 시간 예산, 제출 정책을 사용한다.

### 측정 지표

| 지표 | 정의 |
|---|---|
| Solve rate | 제한 시간 내 CTFd `correct` 비율 |
| Time to solve | 문제 발견부터 `correct`까지 시간 |
| Invalid execution rate | 차단된 raw command·비허용 tool 요청 비율 |
| Duplicate submissions | 중복 제출 횟수 |
| Recovery rate | Worker 실패 후 정상 재시도·복구 비율 |
| Token usage | Main Codex 총 사용량 |
| Stability | 동일 조건 반복 실행의 결과 분산 |

단순히 “출력 파일이 존재한다”처럼 두 조건이 모두 쉽게 통과하는 검사는 평가 지표로 사용하지 않는다.

## 11. MVP 인수 조건

- [ ] 로컬 CTFd에서 문제 목록 조회 성공
- [ ] Main Codex가 Schema-valid Decision 생성
- [ ] 최소 한 분야의 실제 Worker 도구 실행 성공
- [ ] Main과 외부 Worker 사이 JSON 왕복 성공
- [ ] 플래그 후보가 Submission Broker를 거쳐 CTFd에서 `correct` 처리
- [ ] Worker 동시 실행 수가 3을 넘지 않음
- [ ] raw command, 비허용 tool, 경로 탈출, 비허용 host 차단 테스트 통과
- [ ] API와 일반 이벤트에서 원문 플래그가 노출되지 않음
- [ ] 실패 결과와 미검증 범위가 기록됨
- [ ] 전체 자동 테스트 통과
- [ ] Baseline과 With-Harness 비교 결과 1회 이상 생성

## 12. 결정이 필요한 항목

| 항목 | MVP 기본안 | 최종 결정 |
|---|---|---|
| Worker 실행 환경 | 로컬 Docker, 불가하면 독립 workspace | 팀 회의 필요 |
| Kubernetes | 발표용 확장 아키텍처 | 팀 회의 필요 |
| 자동 제출 | 로컬 CTFd에서만 활성화 | 팀 회의 필요 |
| CTF 문제 반입 | 라이선스·재배포 조건 확인 후 사용 | 담당자 확인 필요 |
| 평가 제한 시간 | 문제별 고정 예산 | 팀 회의 필요 |

## 13. 참고 자료

이 문서는 [revfactory/harness](https://github.com/revfactory/harness)의 Supervisor·Expert Pool·Pipeline 패턴, 명시적 orchestration 계약, incremental QA, With-Harness/Baseline 비교 원칙을 우리 프로젝트 조건에 맞춰 재구성했다. 해당 프로젝트는 Apache-2.0 라이선스이며, 본 프로젝트는 다중 LLM Agent Team 구성은 채택하지 않는다.
