# plan.md — CTF Run Harness 실행 계획

## 1. 운영 규칙

- 체크박스는 실행 근거가 있을 때만 완료 처리한다.
- 각 milestone은 정상 흐름과 오류 흐름을 모두 통과해야 종료한다.
- 의존 milestone이 끝나기 전에 후속 기능을 통합하지 않는다.
- 세 사람은 Lane을 나눠 병렬 작업하되 JSON 계약을 먼저 고정한다.
- 매일 통합 가능한 작은 변경을 유지한다.
- 현재 발표 범위에서는 로컬 CTFd 수직 경로가 최우선이다.

## 2. 역할과 작업 Lane

| Lane | 범위 | 담당 | 주 산출물 |
|---|---|---|---|
| A — CTF Environment | 로컬 CTFd, 문제 등록, known flag smoke test | 김태우 | CTFd compose, pwn/rev/web fixture |
| B — Coordinator | Poller, Codex SDK, Decision/Job 계약, checkpoint | 미정 | Main Coordinator |
| C — Worker Runtime | Worker Profile, tool runner, workspace 격리, Result 계약 | 미정 | 분야별 Worker Program |
| Shared — Integration | Submission, event, E2E, 평가, 발표 | 전원 | demo, metrics, 발표 근거 |

담당자가 정해지면 `미정`을 실제 이름으로 교체한다. 문서·계약 변경은 전원이 확인한다.

## 3. 의존 관계

```text
M0 범위 고정
 ├─> M1 계약/골격 ─> M3 Main Coordinator ─┐
 ├─> M2 로컬 CTFd ────────────────────────┼─> M6 E2E
 └─> M4 Worker Runtime ───────────────────┤
                    M5 Submission/Event ──┘
                                             └─> M7 평가
                                                  └─> M8 발표/빌드
```

## 4. Milestone

### M0 — 범위와 성공 조건 고정

목표: 팀원이 같은 프로젝트를 설명하도록 한다.

- [ ] `PRD.md`, `AGENTS.md`, `plan.md` 전원 검토
- [ ] Main AI는 Codex 하나라는 조건 확인
- [ ] Worker는 LLM이 아닌 프로그램이라는 조건 확인
- [ ] Swarm/Racing 제외 확인
- [ ] 동시 Worker 최대 3 확인
- [ ] MVP는 로컬 CTFd만 지원한다고 확인
- [ ] Worker 실행 환경 결정: Docker 또는 독립 workspace
- [ ] Kubernetes는 MVP/확장 중 어디에 둘지 결정
- [ ] 자동 제출 정책과 평가 제한 시간 결정

완료 근거:

- 팀원 3명이 같은 한 문장 정의에 동의
- 미결정 항목이 PRD의 결정 표에 기록됨

### M1 — 저장소 골격과 JSON 계약

목표: 세 Lane이 충돌 없이 병렬 구현할 계약을 만든다.

- [ ] 기본 디렉터리와 실행 스크립트 생성
- [ ] `decision.schema.json` 작성
- [ ] `job.schema.json` 작성
- [ ] `result.schema.json` 작성
- [ ] `event.schema.json` 작성
- [ ] category → Worker Profile mapping 정의
- [ ] profile별 tool allowlist 정의
- [ ] sample Decision/Job/Result fixture 작성
- [ ] 유효 fixture 통과 테스트
- [ ] unexpected field와 raw command 실패 테스트

Gate:

- Main 없이도 sample Job을 Worker가 읽을 수 있음
- Worker 없이도 sample Result를 Core가 검증할 수 있음
- action 수가 3을 넘으면 차단됨

### M2 — 로컬 CTFd와 평가 문제

목표: 실제 조회와 제출이 가능한 재현 환경을 만든다.

- [ ] 로컬 CTFd 실행 방법 작성
- [ ] 관리자·팀·사용자 초기화 절차 작성
- [ ] CTFd API token 발급 절차 작성
- [ ] pwn 쉬운 문제 1개 등록
- [ ] rev 쉬운 문제 1개 등록
- [ ] web 쉬운 문제 1개 등록
- [ ] known flag를 수동 제출해 `correct` 확인
- [ ] API로 문제 목록 조회 확인
- [ ] API로 known flag 제출 확인
- [ ] 문제 원본·flag·token Git 제외 확인
- [ ] 문제 재배포 가능 여부 확인

확장 평가 세트:

- [ ] pwn 총 3문제
- [ ] rev 총 3문제
- [ ] web 총 3문제
- [ ] 각 분야 2개 조정용, 1개 holdout 구분

Gate:

- 새 환경에서 문서만 보고 CTFd를 재현할 수 있음
- 세 분야 각각 known flag smoke test 성공

### M3 — Poller와 Main Codex Coordinator

목표: CTFd 문제를 구조화된 Worker Job으로 바꾼다.

- [ ] CTFd Platform Adapter 구현
- [ ] host allowlist 적용
- [ ] 5초 Poller 구현
- [ ] 신규·변경·미해결 문제 판별
- [ ] 중복 Run 방지
- [ ] Codex SDK Adapter 구현
- [ ] Decision Schema를 structured output으로 연결
- [ ] 첫 turn 후 thread ID checkpoint 저장
- [ ] 프로세스 재시작 후 thread resume
- [ ] Main prompt에 허용 profile/tool만 제공
- [ ] 최대 3개 action 강제
- [ ] Schema-invalid Decision 차단 및 제한된 교정 재시도

Gate:

- 실제 CTFd 문제 하나로 Schema-valid Job 생성
- Codex를 재시작한 뒤 같은 thread ID로 후속 판단
- 잘못된 profile/tool/action 수를 Worker에 전달하지 않음

### M4 — 독립 Worker Runtime

목표: Worker가 Main과 분리된 환경에서 JSON 작업을 수행한다.

공통:

- [ ] Worker Job reader 구현
- [ ] Result writer 구현
- [ ] Worker별 독립 workspace 생성
- [ ] path traversal 차단
- [ ] tool allowlist dispatcher 구현
- [ ] timeout과 프로세스 종료 구현
- [ ] stdout/stderr 크기 제한
- [ ] artifact key와 SHA-256 생성
- [ ] Worker가 CTFd에 직접 제출하지 못하도록 분리

pwn vertical slice:

- [ ] `file`, `checksec`, `strings`, `readelf`, `objdump` adapter
- [ ] Main이 생성한 Python artifact의 제한된 실행 경로
- [ ] pwn fixture Job → Result 통합 테스트

rev vertical slice:

- [ ] `file`, `strings`, `readelf`, `objdump` adapter
- [ ] headless analysis 도구 지원 여부 결정
- [ ] rev fixture Job → Result 통합 테스트

web vertical slice:

- [ ] method·host allowlist 기반 HTTP adapter
- [ ] 응답 크기·timeout 제한
- [ ] web fixture Job → Result 통합 테스트

Gate:

- Worker는 별도 프로세스/컨테이너에서 실행됨
- 비허용 tool, host, path가 모두 차단됨
- timeout 후 부분 artifact와 구조화된 결과가 남음

### M5 — Scheduler, Submission, Event

목표: 최대 3개 실행과 안전한 자동 제출을 완성한다.

- [ ] Local 또는 Docker Scheduler 구현
- [ ] 최대 동시성 3 강제
- [ ] Worker 실패가 다른 Run에 영향 없는지 확인
- [ ] Job/Result ID 일치 검증
- [ ] flag format validator 구현
- [ ] `challengeId + flag hash` 중복 차단
- [ ] CTFd submission adapter 구현
- [ ] CTFd `correct`만 solve 처리
- [ ] 원문 flag 로그·API 마스킹
- [ ] run/decision/job/result/submission event 기록
- [ ] iteration별 artifact·metrics 디렉터리 생성

Gate:

- 네 개 이상의 Job을 넣어도 활성 Worker는 3 이하
- 같은 flag 두 번 제출 시 CTFd 요청은 한 번
- incorrect 결과가 solve로 기록되지 않음

### M6 — End-to-End 수직 통합

목표: 실제 로컬 CTFd 문제를 자동으로 제출한다.

- [ ] pwn 1문제 E2E
- [ ] rev 1문제 E2E
- [ ] web 1문제 E2E
- [ ] Worker 실패 후 제한된 후속 Job E2E
- [ ] Codex thread resume E2E
- [ ] Poller 중복 감지 E2E
- [ ] concurrent 3 Worker E2E
- [ ] 로그만으로 배정 이유와 제출 결과 추적

정상 시나리오:

```text
CTFd problem -> Poller -> Main Decision -> Worker -> Result
-> Submission Broker -> CTFd correct -> run completed
```

오류 시나리오:

```text
Worker timeout -> partial result/artifact -> Main replan
-> retry budget 안에서 후속 Job -> 성공 또는 근거 있는 실패 종료
```

Gate:

- 세 분야 중 최소 한 분야는 무인 수직 경로 완주
- 나머지 분야의 실패는 “미검증”이 아니라 원인과 증거가 기록됨

### M7 — 하네스 평가와 반복 개선

목표: “하네스를 사용했다”가 아니라 “하네스가 어떤 차이를 만들었는지” 보여준다.

- [ ] Baseline 실행 조건 고정
- [ ] With-Harness 실행 조건 고정
- [ ] 동일 문제·동일 모델·동일 시간 예산 확인
- [ ] solve rate 기록
- [ ] time to solve 기록
- [ ] token usage 기록
- [ ] retry 횟수 기록
- [ ] invalid action 및 중복 제출 기록
- [ ] iteration-001 결과 보존
- [ ] 로그 기반 하네스 개선 1회
- [ ] iteration-002 재실행
- [ ] 이전 iteration과 delta 비교
- [ ] holdout 문제로 과적합 확인
- [ ] 악화된 변경 미승격

필수 assertion 예:

- [ ] Worker 최대 동시성은 항상 3 이하
- [ ] CTFd `correct` 없는 문제는 solved가 아님
- [ ] 비허용 tool은 실행되지 않음
- [ ] 중복 flag는 두 번째 네트워크 요청을 만들지 않음
- [ ] API와 일반 이벤트에 원문 flag가 없음

Gate:

- Baseline/With-Harness 표와 해석 생성
- 모든 수치에 실행 로그 또는 metrics 근거 존재
- 단일 성공 사례를 일반 성능으로 과장하지 않음

### M8 — 빌드, 배포, 발표 준비

목표: 새 노트북에서도 재현되고 15분 발표가 가능하도록 한다.

- [ ] 환경 변수 예제 작성
- [ ] 설치·실행·중지·초기화 절차 작성
- [ ] 전체 테스트 명령 한 개로 정리
- [ ] 로컬 demo 명령 한 개로 정리
- [ ] clean environment 재현 테스트
- [ ] 발표용 실패 없는 고정 demo 준비
- [ ] 예비 녹화 또는 로그 replay 준비
- [ ] 비밀정보·flag·문제 원본 Git 검사
- [ ] Kubernetes 확장 아키텍처 그림 정리
- [ ] 잘된 점/잘못된 점/회고 작성

15분 발표 권장 구성:

| 시간 | 내용 |
|---|---|
| 0–2분 | 문제와 목표 |
| 2–5분 | PRD, AGENTS, plan으로 만든 개발 하네스 |
| 5–8분 | Main/Worker JSON 아키텍처 |
| 8–11분 | 실제 CTFd demo 또는 replay |
| 11–13분 | Baseline 대비 평가 결과 |
| 13–15분 | 실패·회고·Kubernetes 고도화 |

Gate:

- 새 환경 재현 성공
- 발표용 demo와 fallback 모두 준비
- 팀원 3명이 질문에 같은 용어로 답함

## 5. 통합 QA 체크리스트

각 milestone 종료 시 생산자와 소비자를 함께 확인한다.

- [ ] CTFd 응답 shape ↔ Platform Adapter mapping
- [ ] Poller event ↔ Core 입력
- [ ] Codex Decision ↔ Decision Schema ↔ Scheduler 입력
- [ ] Scheduler Job ↔ Worker Job reader
- [ ] Worker Result ↔ Result Schema ↔ Main 입력
- [ ] flag candidate ↔ Submission Broker masking/dedup
- [ ] Broker request ↔ CTFd response mapping
- [ ] run state transition ↔ 실제 event 순서

## 6. 매일 공유할 진행 보고 형식

```text
[Lane]
- 완료: 실제 동작과 근거
- 진행 중: 현재 파일/모듈
- 막힘: 필요한 결정 또는 외부 의존성
- 검증: 실행한 테스트와 결과
- 다음: 가장 작은 후속 작업
```

“코드 작성 완료” 대신 “어떤 입력으로 어떤 출력이 확인됐는지”를 보고한다.

## 7. 발표 전 Stop 조건

다음 중 하나라도 해당하면 새 기능을 추가하지 않고 안정화한다.

- 세 분야 중 어느 것도 E2E로 제출되지 않음
- Worker 동시성 제한이 검증되지 않음
- 원문 flag 또는 token이 로그/Git에 노출됨
- known flag smoke test가 불안정함
- clean environment 재현이 되지 않음
- demo 시간이 5분을 초과함

## 8. 발표 이후 Backlog

- [ ] Kubernetes Job/Pod Scheduler
- [ ] Temporal durable workflow
- [ ] PostgreSQL run/checkpoint/event repository
- [ ] S3/MinIO artifact repository
- [ ] Dashboard/TUI와 SSE
- [ ] rCTF/Custom Platform Adapter
- [ ] category tool image 고도화
- [ ] 안전한 하네스 개선 후보 생성과 승인 절차
